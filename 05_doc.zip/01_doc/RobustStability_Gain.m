function [K_star,gamma_star]=RobustStability_Gain(A,C)
    n_x=size(A,1);
    n_y=size(C,1);
    setlmis([])
        gamma=lmivar(1,[1,1]);
%         gamma=0.99
        [K,nK,sK]=lmivar(2,[n_x,n_y]);
        % 1st LMI
        lmiterm([1 1 1 gamma],1,-1);
        lmiterm([1 1 2 0],-A);
        lmiterm([1 1 2 K],1,C);
        
        lmiterm([1 2 2 0],-1);
        
        % 2nd LMI
        lmiterm([2 1 1 gamma],1,1);
        lmiterm([2 1 1 0],-1);
        
        % 3rd LMI
        lmiterm([3 1 1 gamma],-1,1);
        lmiterm([3 1 1 0],0);
        
        % 4th LMI
        lmiterm([4 1 1 0],-1);
        lmiterm([4 1 2 K],1,1);
        lmiterm([4 2 2 0],-1);
    lmisys=getlmis;
    %LMI ���
    n_LMI=decnbr(lmisys);
    c_LMI=zeros(1,n_LMI);
    for j=1:n_LMI
        [gamma_j,K_j]=defcx(lmisys,j,gamma,K);
%         c_LMI(j)=trace(K_j'*K_j);
        c_LMI(j)=gamma_j;
    end
    [copt,xopt]=mincx(lmisys,c_LMI); % ����н�
    K_star=dec2mat(lmisys,xopt,K); % ��ȡ�����
    gamma_star=dec2mat(lmisys,xopt,gamma); % ��ȡ�����
end