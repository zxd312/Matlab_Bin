clc
clear
close all;
z1=zonotope([0;0],diag([1,2])); z1=computeHRep(z1);
%% Original zonotopes
n=2;r1=4;r2=4;
R1=2*rand(n,r1)-1;
c1=2*rand(n,1)-1;
R2=2*rand(n,r2)-1;
c2=2*rand(n,1)-1;
z1=zonotope(c1,R1); z1=computeHRep(z1);
z2=zonotope(c2,R2); z2=computeHRep(z2);
z3=Polyhedron('H',[[z1.A;z2.A] [z1.b;z2.b]]); z3=computeVRep(z3); % The common region by H-representation and V-representation
% z3.A的维数不是z1.A和z2.A的和，因为在构成胞型时算法自动简约了。
%% Zonotopic estimate 1      （应该是找到紧的超平面）
for i=1:size(z3.A,1)
    for j=1:size(z3.V,1)
        b0(i,j)=z3.A(i,:)*z3.V(j,:)';
    end
    b0_diff1(i,:)=b0(i,:)-z3.b(i);
    b0_diff(i,:)=abs(b0(i,:)-z3.b(i));
    [~,I(i,:)]=max(b0_diff(i,:)); % The maximum distance for the hyperplane with normal vector z3.A(i,:)
    A(2*i-1,:)=z3.A(i,:)./((z3.b(i,:)-b0(i,I(i,:)))/2);
    A(2*i,:)=z3.A(i,:)./((z3.b(i,:)-b0(i,I(i,:)))/2);
    b(2*i-1,:)=z3.b(i,:)./((z3.b(i,:)-b0(i,I(i,:)))/2);
    b(2*i,:)=b0(i,I(i,:))./((z3.b(i,:)-b0(i,I(i,:)))/2);
    C(i,:)=(b(2*i-1,:)+b(2*i,:))/2; 
    P(i,:)=A(2*i,:); % Strip representation for these parallel hyperplanes
end
P_set=nchoosek(1:1:size(P,1),n);
for i=1:size(P_set,1)
    P_volumn(i)=norm(inv(P(P_set(i,:)',:)),'F');
end
[~,I1]=find(P_volumn>=0);
[~,I2]=min(P_volumn(I1)); % Find the minimum volumn of combinaed 2-order zonotopes
P_s=P(P_set(I1(I2),:),:);
C_s=C(P_set(I1(I2),:));
Pss=inv(P_s);
z4=zonotope(Pss*C_s,Pss);

%% Zonotopic estimate 2           box的融合准则
c5=(max(z3.V)'+min(z3.V)')/2;
R5=diag(abs(max(z3.V)'-min(z3.V)')/2);
z5=zonotope(c5,R5);

Options1.shade=0.2;
Options1.color='blue';
Options1.edgecolor='none';
Options2.shade=0.2;
Options2.color='green';
Options2.edgecolor='none';
figure(1)
hold on
plot(z3,'color','r','alpha',0.2);
plot(z3.V(:,1),z3.V(:,2),'ro');
plot(z4,'color','b','alpha',0.3);

figure(2)
hold on
plot(z3,'color','r','alpha',0.2);
plot(z3.V(:,1),z3.V(:,2),'ro');
plot(z5,'color','b','alpha',0.3);

figure(3)
plot(z1,'edgecolor','r','color','w','alpha',0.2);
hold on
plot(z2,'color','w','alpha',0.2);
plot(z3,'color','r','alpha',0.2);
plot(z3.V(:,1),z3.V(:,2),'ro');
plot(z4,'color','b','alpha',0.3);

figure(4)
plot(z1,'edgecolor','r','color','w','alpha',0.2);
hold on
plot(z2,'color','w','alpha',0.2);
plot(z3,'color','r','alpha',0.2);
plot(z3.V(:,1),z3.V(:,2),'ro');
plot(z5,'color','b','alpha',0.3);



