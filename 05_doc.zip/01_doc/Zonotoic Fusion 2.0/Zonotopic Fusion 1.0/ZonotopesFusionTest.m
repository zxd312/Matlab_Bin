clc
clear
close all;

% c(:,1)=[0.5;0.5];
% c(:,2)=[1;0.5];
% c(:,3)=[1;1];
% R{1}=[1 0.5;1 0];
% R{2}=[0.4 0;1 0.5];
% R{3}=[0.5 1;0.1 0.5];

% c(:,1)=[0.5;0.5];
% c(:,2)=[1;0.5];
% c(:,3)=[1;1];
% R{1}=[1 0.5;1 0];
% R{2}=[0.4 0;1 0.5];
R{3}=[1 1 1;2 1 1];

c(:,1)=[0.5;0.5];
c(:,2)=[1;0.5];
c(:,3)=[1;1];
R{1}=[1 0.5;1 0];
R{2}=[0.4 0;1 0.5];
% R{3}=[-0.2 0.2 0.4;0.3 -0.2 -0.3];
R0{1}=[R{1} [0;0]];
R0{2}=[R{2} [0;0]];
R0{3}=R{3};
for i=1:3
     R_sign=sign(R{i});
     R_s=R_sign(1,:).*R_sign(2,:)
     R_s(find(R_s==0))=1;
     R{i}=abs(R{i}).*[ones(1,size(R{i},2));R_s];
     aa=find(R{i}(2,:)>=0);
     bb=find(R{i}(2,:)<0);
     [M1,N1]=sort(R{i}(1,bb)./R{i}(2,bb),'descend');
     [M2,N2]=sort(R{i}(1,aa)./R{i}(2,aa),'descend');
     N{i}=[bb(N1) aa(N2)];
end
[c_f R_f] = ZonotopesFusion(c,R0);
R_f_sign=sign(R_f);
R_f=abs(R_f).*[ones(1,size(R_f,2));R_f_sign(1,:).*R_f_sign(2,:)]
aa=find(R_f(2,:)>=0)
bb=find(R_f(2,:)<0)
[M1,N1]=sort(R_f(1,bb)./R_f(2,bb),'descend');
[M2,N2]=sort(R_f(1,aa)./R_f(2,aa),'descend');
N_f=[bb(N1) aa(N2)]
for i=1:800
    r1(i)=2*rand-1;
    r2(i)=2*rand-1;
    r3(i)=2*rand-1;
    x1(:,i)=c(:,1)+R{1}*[r1(i);r2(i)];
    x2(:,i)=c(:,2)+R{2}*[r1(i);r2(i)];
    x3(:,i)=c(:,3)+R{3}*[r1(i);r2(i);r3(i)];
    x4(:,i)=c_f+R_f*[r1(i);r2(i);r3(i)];
end
figure(1)
hold on
fill([sum(R{1}(1,:)),sum(R{1}(1,:))-2*sum(R{1}(1,N{1}(1))),sum(R{1}(1,:))-2*sum(R{1}(1,N{1}(1:2))),sum(R{1}(1,:))-2*sum(R{1}(1,N{1}(2)))]+c(1,1),...
     [sum(R{1}(2,:)),sum(R{1}(2,:))-2*sum(R{1}(2,N{1}(1))),sum(R{1}(2,:))-2*sum(R{1}(2,N{1}(1:2))),sum(R{1}(2,:))-2*sum(R{1}(2,N{1}(2)))]+c(2,1),'r');
fill([sum(R{2}(1,:)),sum(R{2}(1,:))-2*sum(R{2}(1,N{2}(1))),sum(R{2}(1,:))-2*sum(R{2}(1,N{2}(1:2))),sum(R{2}(1,:))-2*sum(R{2}(1,N{2}(2)))]+c(1,2),...
     [sum(R{2}(2,:)),sum(R{2}(2,:))-2*sum(R{2}(2,N{2}(1))),sum(R{2}(2,:))-2*sum(R{2}(2,N{2}(1:2))),sum(R{2}(2,:))-2*sum(R{2}(2,N{2}(2)))]+c(2,2),'b');
fill([sum(R{3}(1,:)),sum(R{3}(1,:))-2*sum(R{3}(1,N{3}(1))),sum(R{3}(1,:))-2*sum(R{3}(1,N{3}(1:2))),sum(R{3}(1,:))-2*sum(R{3}(1,N{3}(1:3))),sum(R{3}(1,:))-2*sum(R{3}(1,N{3}(2:3))),sum(R{3}(1,:))-2*sum(R{3}(1,N{3}(3)))]+c(1,3),...
     [sum(R{3}(2,:)),sum(R{3}(2,:))-2*sum(R{3}(2,N{3}(1))),sum(R{3}(2,:))-2*sum(R{3}(2,N{3}(1:2))),sum(R{3}(2,:))-2*sum(R{3}(2,N{3}(1:3))),sum(R{3}(2,:))-2*sum(R{3}(2,N{3}(2:3))),sum(R{3}(2,:))-2*sum(R{3}(2,N{3}(3)))]+c(2,3),'g');
fill([sum(R_f(1,:)),sum(R_f(1,:))-2*sum(R_f(1,N_f(1))),sum(R_f(1,:))-2*sum(R_f(1,N_f(1:2))),sum(R_f(1,:))-2*sum(R_f(1,N_f(1:3))),sum(R_f(1,:))-2*sum(R_f(1,N_f(2:3))),sum(R_f(1,:))-2*sum(R_f(1,N_f(3)))]+c_f(1),...
     [sum(R_f(2,:)),sum(R_f(2,:))-2*sum(R_f(2,N_f(1))),sum(R_f(2,:))-2*sum(R_f(2,N_f(1:2))),sum(R_f(2,:))-2*sum(R_f(2,N_f(1:3))),sum(R_f(2,:))-2*sum(R_f(2,N_f(2:3))),sum(R_f(2,:))-2*sum(R_f(2,N_f(3)))]+c_f(2),'y');

figure(2)
for i=1:800
    hold on
    plot(x1(1,i),x1(2,i),'ro','MarkerFaceColor','r');
    plot(x2(1,i),x2(2,i),'go','MarkerFaceColor','g');
    plot(x3(1,i),x3(2,i),'bo','MarkerFaceColor','b');
    plot(x4(1,i),x4(2,i),'yo','MarkerFaceColor','y');
end


