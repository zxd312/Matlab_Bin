%% Overall System
L=3;
part_x=[1,3,3,5,5,7]; % Partion of a large system
n_x=part_x(2:2:end)-part_x(1:2:end)+1; % Dimension of each subsystem
n_y=[2 3 2]; % Dimension of the measurements of each subsystem
for k=1:N
    A{k,1,1}=[0.2            0.2+0.2*cos(k) 0;
              0.2+0.1*sin(k) 0.1            0.2;
              0              0.1            0.3];
    A{k,2,2}=[0.3            0              0;
              0.2+0.1*sin(k) 0.2            0.3+0.1*cos(k);
              0              0              0.3];
    A{k,3,3}=[0.3            0.1+0.2*sin(k)   0;
              0.1+0.1*cos(k) 0.2              0.1;
              0               0.1+0.1*cos(k)  0.2];
    A{k,2,1}=[0 0   0;
              0 0   0;
              0 0.2 0];
    A{k,2,3}=[0 0.2*sin(k) 0;
              0 0              0;
              0 0              0];
    B{k,1}=eye(n_x(1));
    B{k,2}=eye(n_x(2));
    B{k,3}=eye(n_x(3));
    C{k,1}=[3+1*cos(k) 1 2;
            1          2 1];
    C{k,2}=[2+1*cos(k) 3             1;
            2          sin(k)    2;
            1          2             3];
    C{k,3}=[5+1*cos(k) 3            2;
            1          7+1*cos(k)   1];
    D{k,1}=eye(n_y(1));
    D{k,2}=eye(n_y(2));
    D{k,3}=eye(n_y(3));
    % A0����Ҫ��С��1����֤�ȶ��Դ����ı������ܱ����̡�
    A0(:,:,k)=[0.2            0.2+0.2*cos(k) 0              0              0              0                0;
               0.2+0.1*sin(k) 0.2            0.2            0              0              0                0;
               0              0.3            0.3            0              0              0                0;
               0              0              0.2+0.2*sin(k) 0.2            0.3+0.1*cos(k) 0                0;
               0              0              0              0              0.3            0.1+0.2*sin(k)   0;
               0              0              0              0              0.1+0.1*cos(k) 0.2              0.1;
               0              0              0              0              0               0.1+0.1*cos(k)  0.2];
    B0(:,:,k)=eye(7);
end