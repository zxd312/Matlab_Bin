%% Several Simulation Problems
%% 1. Reduction q largely influence the performance (weight F-norm). No reordering.
%% 2. If R_i has better performance, then if A_j*R_j obtained from neighbors has better performance
%%    does not guaranteed.
%%    Therefore, the stable gain can not be chosen to minimized the norm of (A_i-K_iC_i).

clc
clear
close all;
N=20; % Time steps
%% Overall System
System_7D;
w0=2*rand(part_x(end),N)-1;
for i=1:L
    w{i}=w0(part_x(2*i-1):part_x(2*i),:);
    v{i}=2*rand(n_y(i),N)-1;
end
%% State Iterating
x0(:,1)=ones(part_x(end),1)*1;
for k=2:N
    x0(:,k)=A0(:,:,k-1)*x0(:,k-1)+B0(:,:,k-1)*w0(:,k-1);
end
for k=1:N
    for i=1:L   
        x{k,i}=x0(part_x(2*i-1):part_x(2*i),k);
        y{k,i}=C{k,i}*x{k,i}+D{k,i}*v{i}(:,k);
    end
end
%% Estimator Initial
q=10;
for i=1:L
    i=1;
    c{1,i}=x0(1:3,1);
    R{1,i}=mdiag(0.01,0.01,0.01);
    c_e{1,i}=c{1,i};
    R_e{1,i}=R{1,i};
    b_e{1,i}=sum(abs(R_e{1,i})')';
end
Out_neibor{1}=[];
Out_neibor{2}=[1 3];
Out_neibor{3}=[];
%% Zonotopic Estimation without Fusion
for k=2:N
    for i=1:L
        bar_c_e1{k-1,i}=c_e{k-1,i};
        bar_R_e1{k-1,i}=R_e{k-1,i};
        m1(k,i)=trace(bar_R_e1{k-1,i}'*bar_R_e1{k-1,i});
%         n_e1(k,i)=sum(sum(abs(bar_R_e1{k-1,i})));
        K1{k,i}=A{k-1,i,i}*bar_R_e1{k-1,i}*bar_R_e1{k-1,i}'*C{k,i}'*inv(C{k,i}*bar_R_e1{k-1,i}*bar_R_e1{k-1,i}'*C{k,i}'+D{k,i}*D{k,i}');
        c_e{k,i}=A{k-1,i,i}*bar_c_e1{k-1,i};
        for j=1:size(Out_neibor{i})
            c_e{k,i}=c_e{k,i}+A{k-1,i,Out_neibor{i}(j)}*c_e{k-1,Out_neibor{i}(j)};
        end
        c_e{k,i}=c_e{k,i}+K1{k,i}*(y{k,i}-C{k,i}*bar_c_e1{k-1,i});
        tilde_R_e{k,i}=(A{k-1,i,i}-K1{k,i}*C{k,i})*bar_R_e1{k-1,i};
        for j=1:size(Out_neibor{i})
            tilde_R_e{k,i}=[tilde_R_e{k,i} A{k-1,i,Out_neibor{i}(j)}*R_e{k-1,Out_neibor{i}(j)}];
        end
        tilde_R_e{k,i}=[tilde_R_e{k,i} B{k-1,i} -K1{k,i}*D{k-1,i}];        
        R_e{k,i}=tilde_R_e{k,i};
        R_e{k,i}=Reduction(R_e{k,i},q);
        b_e{k,i}=sum(abs(R_e{k,i})')';
    end
end
%% Zonotopic Fusion Estimation
Coupling{1}{2}=3;
Coupling{2}{1}=1;
Coupling{2}{3}=3;
Coupling{3}{2}=1;
for i=1:L
    c_e2{1,i}=c{1,i};
    R_e2{1,i}=R{1,i};
    b_e2{1,i}=sum(abs(R_e2{1,i})')';
end
for k=2:N
    for i=1:L
        % It's too difficult to code
        c_in_1=c_e2{k-1,i};
        c_in=[c_in_1];
        R_in_1=R_e2{k-1,i};
        R_in{1}=R_in_1;
        size_R(1)=size(R_in{1},2);
        for j=1:size(Out_neibor{i},2)
            c_in_2=c_in_1;
            c_in_3=c_e2{k-1,Out_neibor{i}(j)};
            c_in_2(Coupling{i}{Out_neibor{i}(j)},:)=c_in_3(Coupling{Out_neibor{i}(j)}{i},:);
            c_in=[c_in c_in_2];
            R_in_2=R_in_1;
            R_in_2(Coupling{i}{Out_neibor{i}(j)},:)=zeros(1,size(R_in_1,2));
            R_in_3=R_e2{k-1,Out_neibor{i}(j)}; R_in_4=zeros(size(R_in_3));
            R_in_4(Coupling{i}{Out_neibor{i}(j)},:)=R_in_3(Coupling{Out_neibor{i}(j)}{i},:);
            R_in{j+1}=[R_in_2 R_in_4];
            size_R(j+1)=size(R_in{j+1},2);
        end
        R_in{1}=[R_in{1} zeros(n_x(i),max(size_R)-size_R(1))];
        for j=1:size(Out_neibor{i},2)
            R_in{j+1}=[R_in{j+1} zeros(n_x(i),max(size_R)-size_R(j+1))];
        end
        [bar_c_e2{k-1,i}, bar_R_e2{k-1,i}]=ZonotopesFusion( c_in,R_in );
        m2(k,i)=trace(bar_R_e2{k-1,i}'*bar_R_e2{k-1,i});
        n_e2(k,i)=sum(sum(abs(bar_R_e2{k-1,i})));
%         bar_c_e2{k-1,i}=c_e2{k-1,i};
%         bar_R_e2{k-1,i}=R_e2{k-1,i};
        K2{k,i}=A{k-1,i,i}*bar_R_e2{k-1,i}*bar_R_e2{k-1,i}'*C{k,i}'*inv(C{k,i}*bar_R_e2{k-1,i}*bar_R_e2{k-1,i}'*C{k,i}'+D{k,i}*D{k,i}');
        c_e2{k,i}=A{k-1,i,i}*bar_c_e2{k-1,i};
        for j=1:size(Out_neibor{i})
            c_e2{k,i}=c_e2{k,i}+A{k-1,i,Out_neibor{i}(j)}*c_e2{k-1,Out_neibor{i}(j)};
        end
        c_e2{k,i}=c_e2{k,i}+K2{k,i}*(y{k,i}-C{k,i}*bar_c_e2{k-1,i});
        tilde_R_e2{k,i}=(A{k-1,i,i}-K2{k,i}*C{k,i})*bar_R_e2{k-1,i};
        for j=1:size(Out_neibor{i})
            tilde_R_e2{k,i}=[tilde_R_e2{k,i} A{k-1,i,Out_neibor{i}(j)}*R_e2{k-1,Out_neibor{i}(j)}];
        end
        tilde_R_e2{k,i}=[tilde_R_e2{k,i} B{k-1,i} -K2{k,i}*D{k-1,i}];
        R_e2{k,i}=tilde_R_e2{k,i};
        R_e2{k,i}=Reduction(R_e2{k,i},q);
        b_e2{k,i}=sum(abs(R_e2{k,i})')';
    end
end

%% RobustStability_Gain
for i=1:L
    c_e3{1,i}=c{1,i};
    R_e3{1,i}=R{1,i};
    b_e3{1,i}=sum(abs(R_e3{1,i})')';
end
for k=2:N
    for i=1:L
        c_in_1=c_e3{k-1,i};
        c_in=[c_in_1];
        R_in_1=R_e3{k-1,i};
        R_in{1}=R_in_1;
        size_R(1)=size(R_in{1},2);
        for j=1:size(Out_neibor{i},2)
            c_in_2=c_in_1;
            c_in_3=c_e3{k-1,Out_neibor{i}(j)};
            c_in_2(Coupling{i}{Out_neibor{i}(j)},:)=c_in_3(Coupling{Out_neibor{i}(j)}{i},:);
            c_in=[c_in c_in_2];
            R_in_2=R_in_1;
            R_in_2(Coupling{i}{Out_neibor{i}(j)},:)=zeros(1,size(R_in_1,2));
            R_in_3=R_e3{k-1,Out_neibor{i}(j)}; R_in_4=zeros(size(R_in_3));
            R_in_4(Coupling{i}{Out_neibor{i}(j)},:)=R_in_3(Coupling{Out_neibor{i}(j)}{i},:);
            R_in{j+1}=[R_in_2 R_in_4];
            size_R(j+1)=size(R_in{j+1},2);
        end
        R_in{1}=[R_in{1} zeros(n_x(i),max(size_R)-size_R(1))];
        for j=1:size(Out_neibor{i},2)
            R_in{j+1}=[R_in{j+1} zeros(n_x(i),max(size_R)-size_R(j+1))];
        end
        [bar_c_e3{k-1,i}, bar_R_e3{k-1,i}]=ZonotopesFusion( c_in,R_in );
        m3(k,i)=trace(bar_R_e3{k-1,i}'*bar_R_e3{k-1,i});
%         bar_c_e3{k-1,i}=c_e3{k-1,i};
%         bar_R_e3{k-1,i}=R_e3{k-1,i};
        [K3{k,i}, gamma_star(k,i)]=RobustStability_Gain(A{k-1,i,i},C{k,i});
        c_e3{k,i}=A{k-1,i,i}*bar_c_e3{k-1,i};
        for j=1:size(Out_neibor{i})
            c_e3{k,i}=c_e3{k,i}+A{k-1,i,Out_neibor{i}(j)}*c_e3{k-1,Out_neibor{i}(j)};
        end
        c_e3{k,i}=c_e3{k,i}+K3{k,i}*(y{k,i}-C{k,i}*bar_c_e3{k-1,i});
        tilde_R_e3{k,i}=(A{k-1,i,i}-K3{k,i}*C{k,i})*bar_R_e3{k-1,i};
        for j=1:size(Out_neibor{i})
            tilde_R_e3{k,i}=[tilde_R_e3{k,i} A{k-1,i,Out_neibor{i}(j)}*R_e3{k-1,Out_neibor{i}(j)}];
        end
        tilde_R_e3{k,i}=[tilde_R_e3{k,i} B{k-1,i} -K3{k,i}*D{k-1,i}];
        R_e3{k,i}=tilde_R_e3{k,i};
        R_e3{k,i}=Reduction(R_e3{k,i},q);
        b_e3{k,i}=sum(abs(R_e3{k,i})')';
    end
end

%% Plot
start=1;
figure(1)
for i=1:L
    for j=1:n_x(i)
        subplot(L,n_x(i),sum(n_x(1:i-1))+j)
        hold on;
        plot(start:N,x0(part_x(2*i-1)+j-1,start:N),'k-','LineWidth',2);
%         x_eT=cell2mat({c_e{start:N,i}});
%         b_eT=cell2mat({b_e{start:N,i}});
%         plot(start:N,x_eT(j:n_x(i):end),'y-.','LineWidth',2);
%         plot(start:N,x_eT(j:n_x(i):end)+b_eT(j:n_x(i):end),'r-.','LineWidth',2);
%         plot(start:N,x_eT(j:n_x(i):end)-b_eT(j:n_x(i):end),'r-.','LineWidth',2);
        
        x_e2T=cell2mat({c_e2{start:N,i}});
        b_e2T=cell2mat({b_e2{start:N,i}});
%       plot(start:N,x_e2T(j:n_x(i):end),'y-','LineWidth',2);
        plot(start:N,x_e2T(j:n_x(i):end)+b_e2T(j:n_x(i):end),'b-.','LineWidth',2);
        plot(start:N,x_e2T(j:n_x(i):end)-b_e2T(j:n_x(i):end),'b-.','LineWidth',2);
        legend({['x_',num2str(j),'^',num2str(i)],['xe_',num2str(j),'^',num2str(i)]},'FontSize',12,'Orientation','horizontal');
        
        x_e3T=cell2mat({c_e3{start:N,i}});
        b_e3T=cell2mat({b_e3{start:N,i}});
%         plot(start:N,x_e3T(j:n_x(i):end),'y-.','LineWidth',2);
        plot(start:N,x_e3T(j:n_x(i):end)+b_e3T(j:n_x(i):end),'g-.','LineWidth',2);
        plot(start:N,x_e3T(j:n_x(i):end)-b_e3T(j:n_x(i):end),'g-.','LineWidth',2);
        legend({['x_',num2str(j),'^',num2str(i)],['xe_',num2str(j),'^',num2str(i)]},'FontSize',12,'Orientation','horizontal');
    end
end

start=4;
figure(2)
plot(start:N,m1(start:N,2),'r-*','LineWidth',2);
hold on;
plot(start:N,m2(start:N,2),'b-*','LineWidth',2);
plot(start:N,m3(start:N,2),'b-*','LineWidth',2);

figure(2)
for i=2:2
    for j=1:n_x(i)
        subplot(n_x(i),1,j)
        hold on;
        plot(start:N,x0(part_x(2*i-1)+j-1,start:N),'k-*','LineWidth',2);
        
        x_eT=cell2mat({c_e{start:N,i}});
        b_eT=cell2mat({b_e{start:N,i}});
%         plot(start:N,x_eT(j:n_x(i):end),'y-.','LineWidth',2);
        plot(start:N,x_eT(j:n_x(i):end)+b_eT(j:n_x(i):end),'g-.','LineWidth',2);
        plot(start:N,x_eT(j:n_x(i):end)-b_eT(j:n_x(i):end),'g-.','LineWidth',2,'HandleVisibility','off');
        
        x_e2T=cell2mat({c_e2{start:N,i}});
        b_e2T=cell2mat({b_e2{start:N,i}});
%         plot(start:N,x_e2T(j:n_x(i):end),'b-','LineWidth',2);
        plot(start:N,x_e2T(j:n_x(i):end)+b_e2T(j:n_x(i):end),'b-.','LineWidth',2);
        plot(start:N,x_e2T(j:n_x(i):end)-b_e2T(j:n_x(i):end),'b-.','LineWidth',2,'HandleVisibility','off');
        
%         x_e3T=cell2mat({c_e3{start:N,i}});
%         b_e3T=cell2mat({b_e3{start:N,i}});
%         plot(start:N,x_e3T(j:n_x(i):end),'r-.','LineWidth',2);
%         plot(start:N,x_e3T(j:n_x(i):end)+b_e3T(j:n_x(i):end),'r-.','LineWidth',2);
%         plot(start:N,x_e3T(j:n_x(i):end)-b_e3T(j:n_x(i):end),'r-.','LineWidth',2,'HandleVisibility','off');
%         ['Estimate of s',num2str(j),' with stable gain'],
        legend({['s_',num2str(j)],['Estimate of s',num2str(j),' without fusion'],['Estimate of s',num2str(j),' with optimal gain']},'FontSize',12,'Orientation','horizontal');
    end
end

figure(3)
for i=2
    subplot(1,1,1)
    plot(start:N,m1(start:N,i),'r-.','LineWidth',2);
    hold on;
    plot(start:N,m2(start:N,i),'b-.','LineWidth',2);
    plot(start:N,m3(start:N,i),'k-.','LineWidth',2);
%     plot(start:N,m3(start:N,i),'b-.','LineWidth',2);
end

figure(4)
for i=1:L
    plot(start:N,gamma_star(start:N,i),'r-.','LineWidth',2);
    hold on;
%     plot(start:N,m2(start:N,i),'b-.','LineWidth',2);
%     plot(start:N,m3(start:N,i),'b-.','LineWidth',2);
end