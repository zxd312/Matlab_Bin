function [ c_f,R_f ] = ZonotopesFusion( c,R )
n=size(c,1);
L=size(c,2);
r=size(R{1},2);

S=[];
for i=1:L
    S=[S;R{i}'*inv(R{i}*R{i}')];
end
f=@(eta)( trace( pinv(kron(ones(1,L),eye(r))*diag(eta)*S)'*pinv(kron(ones(1,L),eye(r))*diag(eta)*S) ) );
% f=@(eta)( sum(sum( abs( pinv(kron(ones(1,L),eye(r))*diag(eta)*S) ) )) );
[enta(1:r*L,1),f1]=fmincon(f,ones(r*L,1)./L,[],[],kron(ones(1,L),eye(r)),ones(r,1),zeros(r*L,1),ones(r*L,1));
R_f=pinv( kron(ones(1,L),eye(r))*diag(enta)*S );
S1=[];
for i=1:L
    S1=[S1;R{i}'*inv(R{i}*R{i}')*c(:,i)];
end
c_f=R_f*( kron(ones(1,L),eye(r))*diag(enta)*S1 );
end
% O=[];
% for i=1:L
%     O=[O R{i}'*inv(R{i}*R{i}')];
% end
% f=@(eta)( trace( pinv(O*kron(eta(1:L,1),eye(r)))'*pinv(O*kron(eta(1:L,1),eye(r))) ) );
% O1=[];
% for i=1:L
%     O1=[O1 enta(i,1)*R{i}'*inv(R{i}*R{i}')];
% end
