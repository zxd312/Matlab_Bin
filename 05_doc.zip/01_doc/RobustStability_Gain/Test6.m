clc
clear
close all;
N=50; % Time steps
%% Overall System
n_x=3;
n_y=3;
A=[0.2  0.4  0;
   0.3  0.2  0.2;
   0    0.3  0.3];
B=1*eye(n_x);
C=[6  4  2;
   1  1  1;
   3  7  6];
D=1*eye(n_y);
x{1}(:)=[0;0;0];
c{1}(:)=[0;0;0];
R{1}(:,:)=mdiag(0.1,0.1,0.1);
w = 2*rand(n_x,N)-1;
v = 2*rand(n_y,N)-1;
%% Interval Estimator Initialization
c_e1{1}(:)=c{1}(:);
R_e1{1}(:,:)=R{1}(:,:);
b_e1{1}(:)=sum(abs(R_e1{1}(:,:))')';

c_e2{1}(:)=c{1}(:);
R_e2{1}(:,:)=R{1}(:,:);
b_e2{1}(:)=sum(abs(R_e2{1}(:,:))')';

c_e3{1}(:)=c{1}(:);
R_e3{1}(:,:)=R{1}(:,:);
b_e3{1}(:)=sum(abs(R_e3{1}(:,:))')';
q=3;
for k=2:N
    x{k}(:) = A*x{k-1}(:)+B*w(:,k);
    y{k}(:) = C*x{k}(:)+D*v(:,k);
    %% Interval Estimator without Reduction
    K1{k}(:,:)=(A*R_e1{k-1}(:,:)*R_e1{k-1}(:,:)'*A'+B*B')*C'*inv(C*R_e1{k-1}(:,:)*R_e1{k-1}(:,:)'*C'+D*D');
    c_e1{k}(:)=A*c_e1{k-1}(:)+K1{k}(:,:)*(y{k}(:)-C*c_e1{k-1}(:));
    R_e1{k}(:,:)=[(A-K1{k}(:,:)*C)*R_e1{k-1}(:,:) B -K1{k}(:,:)*D];
    b_e1{k}(:)=sum(abs(R_e1{k}(:,:))')';
    m1(k)=trace(R_e1{k}(:,:)*R_e1{k}(:,:)');
    %% Interval Estimator with Reduction
    barR_e2{k-1}(:,:)=Reduction(R_e2{k-1}(:,:),q);
    K2{k}(:,:)=(A*barR_e2{k-1}(:,:)*barR_e2{k-1}(:,:)'*A'+B*B')*C'*inv(C*barR_e2{k-1}(:,:)*barR_e2{k-1}(:,:)'*C'+D*D');
    c_e2{k}(:)=A*c_e2{k-1}(:)+K2{k}(:,:)*(y{k}(:)-C*c_e2{k-1}(:));
    R_e2{k}(:,:)=[(A-K2{k}(:,:)*C)*barR_e2{k-1}(:,:) B -K2{k}(:,:)*D];
    b_e2{k}(:)=sum(abs(R_e2{k}(:,:))')';
    m2(k)=trace(R_e2{k}(:,:)*R_e2{k}(:,:)');
    %% Stable Gain
    [K3{k}(:,:),gamma_star(k)]=RobustStability_Gain(A,C);
    c_e3{k}(:)=A*c_e3{k-1}(:)+K3{k}(:,:)*(y{k}(:)-C*c_e3{k-1}(:));
    bar_R_e3{k}(:,:)=[(A-K3{k}(:,:)*C)*R_e3{k-1}(:,:) B -K3{k}(:,:)*D];
    b_e3{k}(:)=sum(abs(bar_R_e3{k}(:,:))')';
    m3(k)=trace(bar_R_e3{k}(:,:)*bar_R_e3{k}(:,:)');
    R_e3{k}(:,:)=Reduction(bar_R_e3{k}(:,:),q);
end

x_T=cell2mat({x{1:N}});
c_e1T=cell2mat({c_e1{1:N}});
c_e2T=cell2mat({c_e2{1:N}});
c_e3T=cell2mat({c_e3{1:N}});
b_e1T=cell2mat({b_e1{1:N}});
b_e2T=cell2mat({b_e2{1:N}});
b_e3T=cell2mat({b_e3{1:N}});

figure(1)
subplot(2,1,1)
plot(1:N,x_T(1:n_x:end),'k-','LineWidth',2);
hold on;
plot(1:N,c_e1T(1:n_x:end)+b_e1T(1:n_x:end),'r-','LineWidth',2);
plot(1:N,c_e1T(1:n_x:end)-b_e1T(1:n_x:end),'r-','LineWidth',2);
plot(1:N,c_e2T(1:n_x:end)+b_e2T(1:n_x:end),'g-','LineWidth',2);
plot(1:N,c_e2T(1:n_x:end)-b_e2T(1:n_x:end),'g-','LineWidth',2);
plot(1:N,c_e3T(1:n_x:end)+b_e3T(1:n_x:end),'b-','LineWidth',2);
plot(1:N,c_e3T(1:n_x:end)-b_e3T(1:n_x:end),'b-','LineWidth',2);

subplot(2,1,2)
plot(1:N,x_T(2:n_x:end),'k-','LineWidth',2);
hold on;
plot(1:N,c_e1T(2:n_x:end)+b_e1T(2:n_x:end),'r-','LineWidth',2);
plot(1:N,c_e1T(2:n_x:end)-b_e1T(2:n_x:end),'r-','LineWidth',2);
plot(1:N,c_e2T(2:n_x:end)+b_e2T(2:n_x:end),'g-','LineWidth',2);
plot(1:N,c_e2T(2:n_x:end)-b_e2T(2:n_x:end),'g-','LineWidth',2);
plot(1:N,c_e3T(2:n_x:end)+b_e3T(2:n_x:end),'b-','LineWidth',2);
plot(1:N,c_e3T(2:n_x:end)-b_e3T(2:n_x:end),'b-','LineWidth',2);

figure(2)
hold on;
plot(1:N,m1,'r-','LineWidth',2);
plot(1:N,m2,'g-','LineWidth',2);
plot(1:N,m3,'b-','LineWidth',2);
