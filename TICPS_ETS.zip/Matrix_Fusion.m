function [y, P] = Matrix_Fusion(varargin)
  
     % 1. 检查输入参数个数
    numInputs = length(varargin);
    % 如果输入参数个数不是偶数，或者没有输入，抛出错误
    if mod(numInputs, 2) ~= 0 || numInputs == 0
        error('输入参数的数量必须是偶数，且遵循 (yi, Pi) 成对出现的格式。');
    end
%% 第一步计算其逆
  Q=0;
 for i = 2:2:numInputs
        % varargin 是元胞数组，使用 {} 提取内容
        P_curr{i} = inv(varargin{i}*varargin{i}');   % 当前的 Pi (对应的协方差) 
        Q = Q + P_curr{i};
 end
%% 第三步计算权重矩阵
 for i = 2:2:numInputs
     P_curr{i}=inv(Q)*P_curr{i};
 end
%% 第四步输出计算结果
y=0; 
 for i = 1:2:numInputs-1
     y=y+P_curr{i+1}*varargin{i};

    if(i==1)
        % 错误1修正：删除末尾多余的]
        P=P_curr{i+1}*varargin{i+1};
    else
        % 水平拼接，确保维度匹配
        P=[P,P_curr{i+1}*varargin{i+1}];
    end  % 错误2修正：确保if语句块完整闭合

 end
    
end