function D = Box(G)
    delta = sum(abs(G), 2);
    D = diag(delta);
end