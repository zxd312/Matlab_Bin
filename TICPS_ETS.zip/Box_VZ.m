function [c_box, R_box, J] = Box_VZ(Ve_1)
% ============================================================
% Box_VZ
%
% 功能：
%   根据多胞体顶点集合构造原坐标系下的 box zonotope 外包
%
% 输入：
%   Ve_1 : 顶点矩阵，支持 Nv×n 或 n×Nv
%
% 输出：
%   c_box : box 包裹中心，n×1
%   R_box : box 包裹生成矩阵，n×n
%   J     : box 体积指标，J = prod(2*rho)
%
% 得到：
%   Z_box = zonotope(c_box, R_box)
% ============================================================

%% 1. 整理顶点格式
Vtx = Ve_1;

% 目标格式：Nv × n，每一行是一个顶点
if size(Vtx,1) < size(Vtx,2)
    Vtx = Vtx';
end

% 去掉重复顶点
Vtx = unique(round(Vtx*1e10)/1e10, 'rows');

Nv = size(Vtx,1);
n  = size(Vtx,2);

if Nv < 2
    error('有效顶点数量不足，无法构造 box 包裹。');
end

%% 2. 每个维度求最大值和最小值
Vmax = max(Vtx,[],1)';
Vmin = min(Vtx,[],1)';

%% 3. 构造 box zonotope
c_box = (Vmax + Vmin)/2;
rho = abs(Vmax - Vmin)/2;
R_box = diag(rho);
%% 4. 体积指标
J = prod(2*rho);
end