%% 小车的画图
%% 性能指标图
figure('Color','w','Position',[140 80 780 800]);
tiledlayout(3,1,'TileSpacing','loose','Padding','compact'); % 稍微拉开一点子图间距，给中间的 xlabel 留出空间
% ==================== 颜色定义 ====================
clr_local = [0.20 0.55 0.90];   % 亮蓝色：local estimator
clr_theo2 = [0.85 0.20 0.18];   % 红色：DZFE in Theorem 2
clr_theo3 = [0.95 0.55 0.10];   % 橙色：DZFE in Theorem 3
Ja = {J_1a, J_2a, J_3a};
Jr = {J_1r, J_2r, J_3r};
Jf = {J_1f, J_2f, J_3f};

for i = 1:3
    ax = nexttile;
    hold(ax,'on');
    box(ax,'on');
    grid(ax,'off');  % 已关闭方格
    
    y1 = Ja{i}(1,:);
    y2 = Jr{i}(1,:);
    y3 = Jf{i}(1,:);
    
    % 局部估计 - 亮蓝色实线
    plot(1:N, y1, '-', ...
        'Color', clr_local, ...
        'LineWidth', 1.8);
        
    % Theorem 2 对应的 DZFE - 红色虚线
    plot(1:N, y2, '--', ...
        'Color', clr_theo2, ...
        'LineWidth', 1.9);
        
    % Theorem 3 对应的 DZFE - 橙色点划线
    plot(1:N, y3, '-.', ...
        'Color', clr_theo3, ...
        'LineWidth', 1.9);
        
    set(ax, ...
        'FontName','Times New Roman', ...
        'FontSize',13, ...
        'LineWidth',0.9, ...
        'XColor',[0.20 0.20 0.20], ...
        'YColor',[0.20 0.20 0.20], ...
        'Layer','top');
        
    xlim([1 N]);
    
    % ==================== y 轴动态留白与特殊限制 ====================
    y_all = [y1(:); y2(:); y3(:)];
    y_min = min(y_all);
    y_max = max(y_all);
    y_pad = 0.08 * (y_max - y_min + eps);
    
    % 使用 if-elseif 结构，防止范围被后面的 else 覆盖
    if i == 1
        % 第一张图上限固定到 0.58
        ylim([y_min - y_pad, 0.58]);
    elseif i == 2
        % 第二张图上限固定到 0.42
        ylim([y_min - y_pad, 0.42]);
    elseif i == 3
        % 第三张图上限固定到 0.4
        ylim([y_min - y_pad, 0.4]);
    else
        ylim([y_min - y_pad, y_max + y_pad]);
    end
    
    ylabel('$AR_{2,k}$', ...
        'Interpreter','latex', ...
        'FontName','Times New Roman', ...
        'FontSize',13);
        
    % 【修改部分】在名称与数字 num2str(i) 之间强行补入空格
    legend({ ...
        ['LE ', num2str(i)], ...
        ['DZFE ', num2str(i), ' in (38)'], ...
        ['DZFE ', num2str(i), ' in (43)']}, ...
        'Location','northeast', ...
        'Box','on', ...
        'FontName','Times New Roman', ...
        'FontSize',10);
        
    % 显式强制当前子图的 X 轴刻度标签可见
    ax.XAxis.Visible = 'on'; 
    
    % 每个子图下面都添加指定格式的横坐标标签（Step为正体，k为数学斜体）
    xlabel(ax, '$\textrm{Step}/k$', ...
        'Interpreter','latex', ...
        'FontName','Times New Roman', ...
        'FontSize',14);
end
exportgraphics(gcf, 'AR_Comparsion.pdf', 'Resolution', 330);

%% 画估计图
%% 估计图（纯平铺版，精准匹配参考图橙色系，增加上下留白）
t = 1:N;
figure('Color','w','Position',[80 60 1000 780]);
T = tiledlayout(3,2,'TileSpacing','loose','Padding','compact');
% ==================== 提取自参考图的精准配色 ====================
clr_true     = [0.80 0.36 0.12];   % 铁锈深橙色：True state (主实线)
clr_fusion   = [0.98 0.75 0.42];   % 浅桃橙色：DZFE 边界虚线与内部阴影
alpha_fusion = 0.35;               % 阴影透明度
%% ===== Row 1, Col 1 (子图 1) =====
ax1 = nexttile(1);
hold(ax1,'on'); box(ax1,'on'); grid(ax1,'off');
h1_fusion = fill(ax1, [t fliplr(t)], [c_1f_up(1,:) fliplr(c_1f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax1, t, c_1f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax1, t, c_1f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h1_true = plot(ax1, t, x(1,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max1 = max([max(c_1f_up(1,:)), max(x(1,:))]);
y_min1 = min([min(c_1f_down(1,:)), min(x(1,:))]);
y_pad1 = 0.10 * (y_max1 - y_min1 + eps);
ylim(ax1, [y_min1 - y_pad1, y_max1 + y_pad1]);
xlim(ax1, [1 N]);
set(ax1, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax1, 'Position (m)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax1, [h1_true, h1_fusion], {'$x_d$', 'DZFE 1 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax1.XAxis.Visible = 'on'; 
xlabel(ax1, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
%% ===== Row 1, Col 2 (子图 2) =====
ax2 = nexttile(2);
hold(ax2,'on'); box(ax2,'on'); grid(ax2,'off');
h2_fusion = fill(ax2, [t fliplr(t)], [c_1f_up(2,:) fliplr(c_1f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax2, t, c_1f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax2, t, c_1f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h2_true = plot(ax2, t, x(2,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max2 = max([max(c_1f_up(2,:)), max(x(2,:))]);
y_min2 = min([min(c_1f_down(2,:)), min(x(2,:))]);
y_pad2 = 0.10 * (y_max2 - y_min2 + eps);
ylim(ax2, [y_min2 - y_pad2, y_max2 + y_pad2]);
xlim(ax2, [1 N]);
set(ax2, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax2, 'Velocity (m/s)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax2, [h2_true, h2_fusion], {'$x_v$', 'DZFE 1 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax2.XAxis.Visible = 'on'; 
xlabel(ax2, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
%% ===== Row 2, Col 1 (子图 3) =====
ax3 = nexttile(3);
hold(ax3,'on'); box(ax3,'on'); grid(ax3,'off');
h3_fusion = fill(ax3, [t fliplr(t)], [c_2f_up(1,:) fliplr(c_2f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax3, t, c_2f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax3, t, c_2f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h3_true = plot(ax3, t, x(1,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max3 = max([max(c_2f_up(1,:)), max(x(1,:))]);
y_min3 = min([min(c_2f_down(1,:)), min(x(1,:))]);
y_pad3 = 0.10 * (y_max3 - y_min3 + eps);
ylim(ax3, [y_min3 - y_pad3, y_max3 + y_pad3]);
xlim(ax3, [1 N]);
set(ax3, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax3, 'Position (m)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax3, [h3_true, h3_fusion], {'$x_d$', 'DZFE 2 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax3.XAxis.Visible = 'on'; 
xlabel(ax3, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
%% ===== Row 2, Col 2 (子图 4) =====
ax4 = nexttile(4);
hold(ax4,'on'); box(ax4,'on'); grid(ax4,'off');
h4_fusion = fill(ax4, [t fliplr(t)], [c_2f_up(2,:) fliplr(c_2f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax4, t, c_2f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax4, t, c_2f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h4_true = plot(ax4, t, x(2,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max4 = max([max(c_2f_up(2,:)), max(x(2,:))]);
y_min4 = min([min(c_2f_down(2,:)), min(x(2,:))]);
y_pad4 = 0.10 * (y_max4 - y_min4 + eps);
ylim(ax4, [y_min4 - y_pad4, y_max4 + y_pad4]);
xlim(ax4, [1 N]);
set(ax4, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax4, 'Velocity (m/s)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax4, [h4_true, h4_fusion], {'$x_v$', 'DZFE 2 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax4.XAxis.Visible = 'on'; 
xlabel(ax4, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
%% ===== Row 3, Col 1 (子图 5) =====
ax5 = nexttile(5);
hold(ax5,'on'); box(ax5,'on'); grid(ax5,'off');
h5_fusion = fill(ax5, [t fliplr(t)], [c_3f_up(1,:) fliplr(c_3f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax5, t, c_3f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax5, t, c_3f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h5_true = plot(ax5, t, x(1,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max5 = max([max(c_3f_up(1,:)), max(x(1,:))]);
y_min5 = min([min(c_3f_down(1,:)), min(x(1,:))]);
y_pad5 = 0.10 * (y_max5 - y_min5 + eps);
ylim(ax5, [y_min5 - y_pad5, y_max5 + y_pad5]);
xlim(ax5, [1 N]);
set(ax5, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax5, 'Position (m)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax5, [h5_true, h5_fusion], {'$x_d$', 'DZFE 3 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax5.XAxis.Visible = 'on'; 
xlabel(ax5, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
%% ===== Row 3, Col 2 (子图 6) =====
ax6 = nexttile(6);
hold(ax6,'on'); box(ax6,'on'); grid(ax6,'off');
h6_fusion = fill(ax6, [t fliplr(t)], [c_3f_up(2,:) fliplr(c_3f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(ax6, t, c_3f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.5);
plot(ax6, t, c_3f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.5);
h6_true = plot(ax6, t, x(2,:), 'Color', clr_true, 'LineWidth', 1.6);
% 计算极值并动态设置 Y 轴留白
y_max6 = max([max(c_3f_up(2,:)), max(x(2,:))]);
y_min6 = min([min(c_3f_down(2,:)), min(x(2,:))]);
y_pad6 = 0.10 * (y_max6 - y_min6 + eps);
ylim(ax6, [y_min6 - y_pad6, y_max6 + y_pad6]);
xlim(ax6, [1 N]);
set(ax6, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',0.9, 'XColor',[0.20 0.20 0.20], 'YColor',[0.20 0.20 0.20], 'Layer','top');
ylabel(ax6, 'Velocity (m/s)', 'FontName','Times New Roman', 'FontSize',13);
legend(ax6, [h6_true, h6_fusion], {'$x_v$', 'DZFE 3 in (43)'}, 'Interpreter','latex', 'Location','northwest', 'Box','on', 'FontSize',10);
ax6.XAxis.Visible = 'on'; 
xlabel(ax6, '$\textrm{Step}/k$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);
exportgraphics(gcf, 'AR_ES.pdf', 'Resolution', 330);

%% 触发率图进行比较
step_k = 1:N;
% 合并触发序列
T_all = [T_1; T_2; T_3];
% 计算触发率（t=1 为初始时刻，不计入），确保返回列向量或行向量
trigger_rate = sum(T_all(:, 2:N), 2) / (N - 1) * 100;
figure('Color','w','Position',[120 100 860 350]); % 调整高度比例，使其更符合排版
ax = gca;
hold(ax, 'on'); 
box(ax, 'on');
grid(ax, 'off'); % 明确去除网格
% ==================== 匹配 Fig. 4 的高对比深色学术配色 ====================
clr1 = [0.15 0.40 0.75];   % 深海蓝 (Node 1) - 呼应 Fig.4 的 LE 蓝
clr2 = [0.85 0.20 0.18];   % 绛红色 (Node 2) - 呼应 Fig.4 的 Theorem 2 红
clr3 = [0.15 0.55 0.30];   % 森林绿 (Node 3) - 将原图的浅绿加深，增加视觉重量
% 找到各传感器触发时刻
idx1 = find(T_all(1,:) == 1);
idx2 = find(T_all(2,:) == 1);
idx3 = find(T_all(3,:) == 1);
% ==================== 绘制触发点 (线宽适中，尺寸适中) ====================
% Node 1: 深海蓝 空心圆圈 (o)
h1 = plot(ax, idx1, 1*ones(size(idx1)), 'o', ...
    'Color', clr1, ...
    'LineWidth', 1.5, ...
    'MarkerSize', 7);
% Node 2: 绛红色 叉号 (x)
h2 = plot(ax, idx2, 2*ones(size(idx2)), 'x', ...
    'Color', clr2, ...
    'LineWidth', 1.5, ...
    'MarkerSize', 8); % x 视觉上偏小，略微放大1号
% Node 3: 森林绿 空心正方形 (s)
h3 = plot(ax, idx3, 3*ones(size(idx3)), 's', ...
    'Color', clr3, ...
    'LineWidth', 1.5, ...
    'MarkerSize', 7);
% ==================== 坐标轴范围与刻度 ====================
% 动态计算 X 轴留白 (按总长度 N 的 2.5% 进行呼吸感留白)
x_pad = 0.025 * N; 
xlim(ax, [1 - (x_pad * 0.3), N + x_pad]); 
% 顶部留出足够空间放置图例，避免和数据点重叠
ylim(ax, [0.5 3.8]); 
% Y轴刻度仅保留 1, 2, 3
yticks(ax, 1:3); 
% ==================== 坐标轴风格 ====================
set(ax, ...
    'FontName','Times New Roman', ...
    'FontSize',14, ...
    'LineWidth',0.9, ...
    'XColor',[0.18 0.18 0.18], ...
    'YColor',[0.18 0.18 0.18], ...
    'Layer','top');
% 横坐标标签：使用 LaTeX 的 Step(k)
xlabel(ax, '$\textrm{Step}/k$', ...
    'Interpreter','latex', ...
    'FontName','Times New Roman', ...
    'FontSize',15);
% ==================== 图例 (动态追加触发率) ====================
% 完美复刻原图图例格式
leg_str1 = sprintf('Node 1 (%.2f\\%%)', trigger_rate(1));
leg_str2 = sprintf('Node 2 (%.2f\\%%)', trigger_rate(2));
leg_str3 = sprintf('Node 3 (%.2f\\%%)', trigger_rate(3));
legend(ax, [h1, h2, h3], ...
    {leg_str1, leg_str2, leg_str3}, ...
    'Interpreter','latex', ...
    'Orientation','horizontal', ...
    'Location','northwest', ...
    'NumColumns',3, ...
    'Box','on', ...      % 去掉图例边框，干净高级
    'FontName','Times New Roman', ...
    'FontSize',12);


exportgraphics(gcf, 'TR_ETS.pdf', 'Resolution', 330)


%% 绘制通信速率的图
%数据保存
%第一张子图
T1_L=[Tl1_10,Tl1_20,Tl1_30,Tl1_40,Tl1_50,Tl1_60,Tl1_70,Tl1_80,Tl1_90,Tl1_100];
T1_r=[Tr1_10,Tr1_20,Tr1_30,Tr1_40,Tr1_50,Tr1_60,Tr1_70,Tr1_80,Tr1_90,Tr1_100];
T1_f=[Tf1_10,Tf1_20,Tf1_30,Tf1_40,Tf1_50,Tf1_60,Tf1_70,Tf1_80,Tf1_90,Tf1_100];
%第二张子图
T2_L=[Tl2_10,Tl2_20,Tl2_30,Tl2_40,Tl2_50,Tl2_60,Tl2_70,Tl2_80,Tl2_90,Tl2_100];
T2_r=[Tr2_10,Tr2_20,Tr2_30,Tr2_40,Tr2_50,Tr2_60,Tr2_70,Tr2_80,Tr2_90,Tr2_100];
T2_f=[Tf2_10,Tf2_20,Tf2_30,Tf2_40,Tf2_50,Tf2_60,Tf2_70,Tf2_80,Tf2_90,Tf2_100];
%第三张子图
T3_L=[Tl3_10,Tl3_20,Tl3_30,Tl3_40,Tl3_50,Tl3_60,Tl3_70,Tl3_80,Tl3_90,Tl3_100];
T3_r=[Tr3_10,Tr3_20,Tr3_30,Tr3_40,Tr3_50,Tr3_60,Tr3_70,Tr3_80,Tr3_90,Tr3_100];
T3_f=[Tf3_10,Tf3_20,Tf3_30,Tf3_40,Tf3_50,Tf3_60,Tf3_70,Tf3_80,Tf3_90,Tf3_100];
save('data_rate.mat', ...
    'T1_L','T1_r','T1_f', ...
    'T2_L','T2_r','T2_f', ...
    'T3_L','T3_r','T3_f');

load('data_rate.mat');

Tl1_100; Tr1_100; Tf1_100;

Tl2_100; Tr2_100; Tf2_100;

%% 绘图  Rates
% ==================== 1. 数据整合 ====================
% 根据变量名规律推测 X 轴坐标为 10, 20, 30 ... 100
% ==================== 1. 数据整合 ====================
% 根据变量名规律推测 X 轴坐标为 10, 20, 30 ... 100
x_ax = 10:10:100; 

% 第一张子图数据
T1_L = [Tl1_10, Tl1_20, Tl1_30, Tl1_40, Tl1_50, Tl1_60, Tl1_70, Tl1_80, Tl1_90, Tl1_100];
T1_r = [Tr1_10, Tr1_20, Tr1_30, Tr1_40, Tr1_50, Tr1_60, Tr1_70, Tr1_80, Tr1_90, Tr1_100];
T1_f = [Tf1_10, Tf1_20, Tf1_30, Tf1_40, Tf1_50, Tf1_60, Tf1_70, Tf1_80, Tf1_90, Tf1_100];

% 第二张子图数据
T2_L = [Tl2_10, Tl2_20, Tl2_30, Tl2_40, Tl2_50, Tl2_60, Tl2_70, Tl2_80, Tl2_90, Tl2_100];
T2_r = [Tr2_10, Tr2_20, Tr2_30, Tr2_40, Tr2_50, Tr2_60, Tr2_70, Tr2_80, Tr2_90, Tr2_100];
T2_f = [Tf2_10, Tf2_20, Tf2_30, Tf2_40, Tf2_50, Tf2_60, Tf2_70, Tf2_80, Tf2_90, Tf2_100];

% 第三张子图数据
T3_L = [Tl3_10, Tl3_20, Tl3_30, Tl3_40, Tl3_50, Tl3_60, Tl3_70, Tl3_80, Tl3_90, Tl3_100];
T3_r = [Tr3_10, Tr3_20, Tr3_30, Tr3_40, Tr3_50, Tr3_60, Tr3_70, Tr3_80, Tr3_90, Tr3_100];
T3_f = [Tf3_10, Tf3_20, Tf3_30, Tf3_40, Tf3_50, Tf3_60, Tf3_70, Tf3_80, Tf3_90, Tf3_100];

% 将数据放入元胞数组，方便循环绘制
L_all = {T1_L, T2_L, T3_L};
r_all = {T1_r, T2_r, T3_r};
f_all = {T1_f, T2_f, T3_f};

% ==================== 2. 画图与样式配置 ====================
figure('Color','w','Position',[120 80 800 900]);
tiledlayout(3,1,'TileSpacing','loose','Padding','compact');

% 提取低饱和度的莫兰迪/学术配色，显得更加柔和高级
clr_LE  = [0.25 0.45 0.80];   % 雾霾蓝 (LE)
mk_LE   = 's';                % 正方形

clr_TH1 = [0.35 0.65 0.40];   % 鼠尾草灰绿 (DZFE in TH 1)
mk_TH1  = '^';                % 三角形

clr_TH2 = [0.85 0.35 0.35];   % 砖瓦干玫瑰红 (DZFE in TH 2)
mk_TH2  = 'o';                % 圆形


for i = 1:3
    ax = nexttile;
    hold(ax, 'on');
    box(ax, 'on');
    grid(ax, 'off'); 
    
    % 绘制 LE (蓝色，正方形)
    h1 = plot(ax, x_ax, L_all{i}, ...
        ['-', mk_LE], ...
        'Color', clr_LE, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_LE);
        
    % 绘制 DZFE in TH 1 (绿色，三角形)
    h2 = plot(ax, x_ax, r_all{i}, ...
        ['-', mk_TH1], ...
        'Color', clr_TH1, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH1);
        
    % 绘制 DZFE in TH 2 (红色，圆形)
    h3 = plot(ax, x_ax, f_all{i}, ...
        ['-', mk_TH2], ...
        'Color', clr_TH2, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH2);
        
    % ==================== 3. 坐标轴与图例设置 ====================
    % 基础字体与线条设置
    set(ax, ...
        'FontName','Times New Roman', ...
        'FontSize',14, ...
        'LineWidth',1.0, ...
        'XColor',[0.15 0.15 0.15], ...
        'YColor',[0.15 0.15 0.15], ...
        'Layer','top');
        
    % X 轴留白 (左右各自留出一定空间)
    xlim(ax, [min(x_ax)-5, max(x_ax)+5]);
    
    % 动态非对称计算 Y 轴留白
    y_all = [L_all{i}(:); r_all{i}(:); f_all{i}(:)];
    y_min = min(y_all);
    y_max = max(y_all);
    y_range = y_max - y_min + eps;
    
    % 下方统一留出 10% 空间
    y_pad_bottom = 0.12 * y_range;
    

    % 留白处理
        if i == 1
            y_pad_top = 0.3 * y_range; % 第一张上方留白40%
        elseif i == 2
            y_pad_top = 0.15 * y_range; % 第二张上方留白30%
        else
            y_pad_top = 0.80 * y_range; % 第三张上方留白70%
        end

    ylim(ax, [y_min - y_pad_bottom, y_max + y_pad_top]);
    
    % Y 轴标签
    ylabel(ax, 'AAR', ...
        'FontName','Times New Roman', ...
        'FontSize',15);
        
    % X 轴标签
    ax.XAxis.Visible = 'on';
    xlabel(ax, 'Communication rate/%', ...
        'FontName','Times New Roman', ...
        'FontSize',15);
        
    % 图例设置 (带边框，放置在右上角)
    legend(ax, [h1, h2, h3], ...
        {['LE ', num2str(i)], ...
         ['DZFE ', num2str(i), ' in (38)'], ...
         ['DZFE ', num2str(i), ' in (43)']}, ...
        'Location', 'northeast', ...
        'Box', 'on', ...
        'FontName', 'Times New Roman', ...
        'FontSize', 12);
end


exportgraphics(gcf, 'TR_ETS_Rate.pdf', 'Resolution', 330)




%% 通信率画图 0.1-1
x_ax = 0.1:0.1:1.0;  
% 将数据放入元胞数组
L_all = {T1_L, T2_L, T3_L};
r_all = {T1_r, T2_r, T3_r};
f_all = {T1_f, T2_f, T3_f};
% ==================== 画图与样式配置 ====================
figure('Color','w','Position',[120 80 800 900]);
tiledlayout(3,1,'TileSpacing','loose','Padding','compact');

clr_LE  = [0.25 0.45 0.80];
mk_LE   = 's';

clr_TH1 = [0.35 0.65 0.40];
mk_TH1  = '^';

clr_TH2 = [0.85 0.35 0.35];
mk_TH2  = 'o';

for i = 1:3
    ax = nexttile;
    hold(ax, 'on');
    box(ax, 'on');
    grid(ax, 'off');

    % LE
    h1 = plot(ax, x_ax, L_all{i}, ...
        ['-', mk_LE], ...
        'Color', clr_LE, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_LE);

    % DZFE in (38)
    h2 = plot(ax, x_ax, r_all{i}, ...
        ['-', mk_TH1], ...
        'Color', clr_TH1, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH1);

    % DZFE in (43)
    h3 = plot(ax, x_ax, f_all{i}, ...
        ['-', mk_TH2], ...
        'Color', clr_TH2, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH2);

    % 坐标轴
    set(ax, ...
        'FontName','Times New Roman', ...
        'FontSize',14, ...
        'LineWidth',1.0, ...
        'XColor',[0.15 0.15 0.15], ...
        'YColor',[0.15 0.15 0.15], ...
        'Layer','top');

    % X 轴范围与刻度
    xlim(ax, [0.05, 1.05]);
    xticks(ax, 0.1:0.1:1.0);

    % Y 轴范围
    y_all = [L_all{i}(:); r_all{i}(:); f_all{i}(:)];
    y_min = min(y_all);
    y_max = max(y_all);
    y_range = y_max - y_min + eps;

    y_pad_bottom = 0.12 * y_range;

    if i == 1
        y_pad_top = 0.30 * y_range;
    elseif i == 2
        y_pad_top = 0.15 * y_range;
    else
        y_pad_top = 0.80 * y_range;
    end

    ylim(ax, [y_min - y_pad_bottom, y_max + y_pad_top]);

    % Y 轴标签
    ylabel(ax, 'AAR', ...
        'FontName','Times New Roman', ...
        'FontSize',15);

    % X 轴标签
    ax.XAxis.Visible = 'on';
    xlabel(ax, 'Communication rate', ...
        'FontName','Times New Roman', ...
        'FontSize',15);

    % 图例
    legend(ax, [h1, h2, h3], ...
        {['LE ', num2str(i)], ...
         ['DZFE ', num2str(i), ' in (38)'], ...
         ['DZFE ', num2str(i), ' in (43)']}, ...
        'Location', 'northeast', ...
        'Box', 'on', ...
        'FontName', 'Times New Roman', ...
        'FontSize', 12);
end























%% 性能指标图
figure('Color','w','Position',[140 80 780 800]);
tiledlayout(3,1,'TileSpacing','compact','Padding','compact');
% 鲜艳但适合论文的配色
clr_local   = [0.20 0.55 0.90];   % 亮蓝色：local estimator
clr_theo2   = [0.95 0.55 0.10];   % 橙色：DZFE in Theorem 2
clr_theo3   = [0.85 0.20 0.18];   % 红色：DZFE in Theorem 3
Ja = {J_1a, J_2a, J_3a};
Jr = {J_1r, J_2r, J_3r};
Jf = {J_1f, J_2f, J_3f};
for i = 1:3
    ax = nexttile;
    hold(ax,'on');
    box(ax,'on');
    grid(ax,'on');
    % 局部估计
    plot(1:N, Ja{i}(1,:), '-', ...
        'Color', clr_local, ...
        'LineWidth', 1.8);
    % Theorem 2 对应的 DZFE
    plot(1:N, Jr{i}(1,:), '--', ...
        'Color', clr_theo2, ...
        'LineWidth', 1.9);
    % Theorem 3 对应的 DZFE
    plot(1:N, Jf{i}(1,:), '-.', ...
        'Color', clr_theo3, ...
        'LineWidth', 1.9);
    set(ax, ...
        'FontName','Times New Roman', ...
        'FontSize',13, ...
        'LineWidth',0.9, ...
        'XColor',[0.20 0.20 0.20], ...
        'YColor',[0.20 0.20 0.20], ...
        'GridColor',[0.86 0.86 0.86], ...
        'GridAlpha',0.28, ...
        'Layer','top');

    % x 轴两侧留白
    xlim([0.5, N + 0.5]);

    % y 轴留白
    y_all = [y1(:); y2(:); y3(:)];
    y_min = min(y_all);
    y_max = max(y_all);
    y_pad = 0.08 * (y_max - y_min + eps);

        if i == 2
        % 第二张图上限固定到 0.4
        ylim([y_min - y_pad, 0.4]);
    else
        ylim([y_min - y_pad, y_max + y_pad]);
    end


    if i == 2
        % 第二张图上限固定到 0.4
        ylim([y_min - y_pad, 0.4]);
    else
        ylim([y_min - y_pad, y_max + y_pad]);
    end

    ylabel('$AR_{2}(k)$', ...
        'Interpreter','latex', ...
        'FontName','Times New Roman', ...
        'FontSize',13);

    legend({ ...
        ['LE',num2str(i)], ...
        ['DZFE',num2str(i),' in Theorem 2'], ...
        ['DZFE',num2str(i),' in Theorem 3']}, ...
        'Location','northeast', ...
        'Box','off', ...
        'FontName','Times New Roman', ...
        'FontSize',10);

         xlabel(ax, '$k$/step', ...
        'Interpreter','latex', ...
        'FontName','Times New Roman', ...
        'FontSize',14);
end



%% 最终Latex代码
%% AAR 随通信率变化图

figure('Color','w','Position',[120 80 800 900]);

tiledlayout(3,1,'TileSpacing','loose','Padding','compact');

% 配色
clr_LE  = [0.25 0.45 0.80];   % 蓝色
clr_TH1 = [0.35 0.65 0.40];   % 绿色
clr_TH2 = [0.85 0.35 0.35];   % 红色

% marker
mk_LE  = 's';     % 正方形
mk_TH1 = '^';     % 三角形
mk_TH2 = 'o';     % 圆形

for i = 1:3

    ax = nexttile;
    hold(ax,'on');
    box(ax,'on');
    grid(ax,'off');

    % 横坐标：0.1 到 1
    x_ax = linspace(0.1,1,numel(L_all{i}));

    % 检查长度是否一致
    if numel(L_all{i}) ~= numel(r_all{i}) || numel(L_all{i}) ~= numel(f_all{i})
        error('第 %d 组数据长度不一致：L_all, r_all, f_all 必须长度相同。',i);
    end

    % LE
    h1 = plot(ax, x_ax, L_all{i}, ...
        ['-',mk_LE], ...
        'Color', clr_LE, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_LE);

    % DZFE in Theorem 2
    h2 = plot(ax, x_ax, r_all{i}, ...
        ['-',mk_TH1], ...
        'Color', clr_TH1, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH1);

    % DZFE in Theorem 3
    h3 = plot(ax, x_ax, f_all{i}, ...
        ['-',mk_TH2], ...
        'Color', clr_TH2, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', 'none', ...
        'MarkerEdgeColor', clr_TH2);

    set(ax, ...
        'FontName','Times New Roman', ...
        'FontSize',14, ...
        'LineWidth',1.0, ...
        'XColor',[0.15 0.15 0.15], ...
        'YColor',[0.15 0.15 0.15], ...
        'Layer','top');

    % X 轴范围：左侧从 0.08 开始，右侧超过 1，给 1 旁边留白
    xlim(ax,[0.08,1.06]);

    % X 轴刻度
    xticks(ax,0.1:0.1:1);

    % ==================== Y 轴动态留白 ====================
    y_all = [L_all{i}(:); r_all{i}(:); f_all{i}(:)];

    y_min = min(y_all);
    y_max = max(y_all);
    y_range = y_max - y_min + eps;

    % 下方统一留出 12% 空间
    y_pad_bottom = 0.12 * y_range;

    % 上方根据不同子图单独调节
    if i == 1
        y_pad_top = 0.30 * y_range;
    elseif i == 2
        y_pad_top = 0.15 * y_range;
    else
        y_pad_top = 0.80 * y_range;
    end

    ylim(ax,[y_min - y_pad_bottom, y_max + y_pad_top]);
    % ======================================================

    ylabel(ax,'AAR', ...
        'FontName','Times New Roman', ...
        'FontSize',15);

    xlabel(ax,'Communication rates', ...
        'FontName','Times New Roman', ...
        'FontSize',15);

    legend(ax,[h1,h2,h3], ...
        {['LE ',num2str(i)], ...
         ['DZFE ',num2str(i),' in Theorem 2'], ...
         ['DZFE ',num2str(i),' in Theorem 3']}, ...
        'Location','northeast', ...
        'Box','on', ...
        'FontName','Times New Roman', ...
        'FontSize',12);

end