%% 百分百通信
T_1=zeros(1,N); T_2=zeros(1,N); T_3=zeros(1,N);
c_1e=cell(1,N); c_2e=cell(1,N); c_3e=cell(1,N); R_1e=cell(1,N); R_2e=cell(1,N); R_3e=cell(1,N);
c_1a=cell(1,N); c_2a=cell(1,N); c_3a=cell(1,N); R_1a=cell(1,N); R_2a=cell(1,N); R_3a=cell(1,N);
c_1r=cell(1,N); c_2r=cell(1,N); c_3r=cell(1,N); R_1r=cell(1,N); R_2r=cell(1,N); R_3r=cell(1,N);
c_1o=cell(1,N); c_2o=cell(1,N); c_3o=cell(1,N); R_1o=cell(1,N); R_2o=cell(1,N); R_3o=cell(1,N);
c_1f=cell(1,N); c_2f=cell(1,N); c_3f=cell(1,N); R_1f=cell(1,N); R_2f=cell(1,N); R_3f=cell(1,N);
cp_1=cell(1,N); cp_2=cell(1,N); cp_3=cell(1,N); Rp_1=cell(1,N); Rp_2=cell(1,N); Rp_3=cell(1,N);
% 初始化估计值
c_1e{1,1}=[0;0];    c_2e{1,1}=[0;0];   c_3e{1,1}=[0;0];
c_1a{1,1}=[0;0];    c_2a{1,1}=[0;0];   c_3a{1,1}=[0;0];
c_1r{1,1}=[0;0];    c_2r{1,1}=[0;0];   c_3r{1,1}=[0;0];
c_1o{1,1}=[0;0];    c_2o{1,1}=[0;0];   c_3o{1,1}=[0;0];
c_1f{1,1}=[0;0];    c_2f{1,1}=[0;0];   c_3f{1,1}=[0;0];
cp_1{1,1}=[0;0];    cp_2{1,1}=[0;0];   cp_3{1,1}=[0;0];
% cp_1{1,1}=[0;0];    cp_2{1,1}=[-0.1;0.3];   cp_3{1,1}=[-0.1;-0.1];
% 初始化生成矩阵
R_1e{1,1}=0.2*eye(2);    R_2e{1,1}=0.2*eye(2);   R_3e{1,1}=0.2*eye(2);
R_1a{1,1}=0.2*eye(2);    R_2a{1,1}=0.2*eye(2);   R_3a{1,1}=0.2*eye(2);
R_1r{1,1}=0.2*eye(2);    R_2r{1,1}=0.2*eye(2);   R_3r{1,1}=0.2*eye(2);
R_1o{1,1}=0.2*eye(2);    R_2o{1,1}=0.2*eye(2);   R_3o{1,1}=0.2*eye(2);
R_1f{1,1}=0.2*eye(2);    R_2f{1,1}=0.2*eye(2);   R_3f{1,1}=0.2*eye(2);
Rp_1{1,1}=0.2*eye(2);    Rp_2{1,1}=0.2*eye(2);   Rp_3{1,1}=0.2*eye(2);
% 初始化边界
c_1a_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1a_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2a_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2a_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3a_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3a_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  

c_1r_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1r_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2r_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2r_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3r_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3r_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  

c_1f_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1f_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2f_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2f_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3f_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3f_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  
% 初始化性能指标
J_1a(:,1)=0.16; J_2a(:,1)=0.16; J_3a(:,1)=0.16;  
J_1f(:,1)=0.16; J_2f(:,1)=0.16; J_3f(:,1)=0.16; 
J_1r(:,1)=0.16; J_2r(:,1)=0.16; J_3r(:,1)=0.16; 
%% 估计器设计
for t=2:N
% 第一个估计器 中心对称多细胞体估计器设计
 c_1e{1,t} = A*c_1f{1,t-1};
 R_1e{1,t}= [A*R_1f{1,t-1},B*Q];
% 求解增益矩阵
  N_11=[R_1e{1,t},zeros(2,8)];
  N_12=[-C_1*R_1e{1,t},diag(Gamma1_r*abs(y_1(:, t))),-Gamma1*O_1,-Gamma1_r*O_1,-D_1*R_1];
  K1_opt = zeros(2, 2);
  col_1 =  size(N_11,2);
  options = sdpsettings('solver', 'sedumi', ...
         'verbose', 1, ...
         'sedumi.eps', 1e-10, ... % 求解精度
         'sedumi.maxiter', 200);  % 最大迭代次数
% 使用循环求解优化问题
    for i = 1:size(N_11,1)
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        K1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*K1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*K1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
         % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K1_opt(i,:) = value(K1_i);   % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
      % 最终结果矩阵
      K1= K1_opt;
      c_1a{1,t}= (eye(2)-K1*C_1)*c_1e{1,t} + K1*Gamma1*y_1(:, t);
      R_1a{1,t}= N_11+K1*N_12;
      R_1a{1,t}=Reduction(R_1a{1,t},q1);
      J_1a(:,t)=Volume_Interval(R_1a{1,t});
      Pc_1a=sum(abs(R_1a{1,t}),2);
      c_1a_up(:, t)  = c_1a{1,t}  + Pc_1a;
      c_1a_down(:, t)= c_1a{1,t}  - Pc_1a;

      % 第二个估计器 中心对称多细胞体估计器设计
      c_2e{1,t} = A*c_2f{1,t-1};
      R_2e{1,t}= [A*R_2f{1,t-1},B*Q];
      % 求解增益矩阵
      N_22=[R_2e{1,t},zeros(2,8)];
      N_21=[-C_2*R_2e{1,t},diag(Gamma2_r*abs(y_2(:, t))),-Gamma2*O_2,-Gamma2_r*O_2,-D_2*R_2];
      K2_opt = zeros(2, 2);
      col_2 =  size(N_22,2);
     % 使用循环求解优化问题
      for i = 1:size(N_22,1)
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);      % 向量λ_i
        K2_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*K2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*K2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K2_opt(i,:) = value(K2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
      end

      % 最终结果矩阵
      K2= K2_opt;
      c_2a{1,t}=(eye(2)-K2*C_2)*c_2e{1,t} + K2*Gamma2*y_2(:, t);
      R_2a{1,t}= N_22+K2*N_21; 
      R_2a{1,t}=Reduction(R_2a{1,t},q2);
      J_2a(:,t)=Volume_Interval(R_2a{1,t});
      Pc_2a=sum(abs(R_2a{1,t}),2);
      c_2a_up(:, t)  = c_2a{1,t}  + Pc_2a;
      c_2a_down(:, t)= c_2a{1,t}  - Pc_2a;

      % 第三个估计器 中心对称多细胞体估计器设计
      c_3e{1,t} = A*c_3f{1,t-1};
      R_3e{1,t}= [A*R_3f{1,t-1},B*Q];
      % 求解增益矩阵
      N_33=[R_3e{1,t},zeros(2,8)];
      N_31=[-C_3*R_3e{1,t},diag(Gamma3_r*abs(y_3(:, t))),-Gamma3*O_3,-Gamma3_r*O_3,-D_3*R_3];
      K3_opt = zeros(2, 2);
      col_3 =  size(N_33,2);
% 使用循环求解优化问题
    for i = 1:size(N_33,1)
        % 定义决策变量
        L3_i = sdpvar(col_3, 1);      % 向量λ_i
        K3_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_33(i,:)' +  N_31'*K3_i' >= -L3_i,
            N_33(i,:)' +  N_31'*K3_i' <=  L3_i
            ];
        % 设置目标函数
        Objective = sum(L3_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K3_opt(i,:) = value(K3_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K3_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
      % 最终结果矩阵
      K3= K3_opt;
      c_3a{1,t}=(eye(2)-K3*C_3)*c_3e{1,t} + K3*Gamma3*y_3(:, t);
      R_3a{1,t}= N_33+K3*N_31; 
      % W3 = LMI_W(W3_old, (eye(2)-K3*C_3{t})*A{t-1}, 0.98);
      R_3a{1,t}=Reduction(R_3a{1,t},q3);
      J_3a(:,t)=Volume_Interval(R_3a{1,t});
      Pc_3a=sum(abs(R_3a{1,t}),2);
      c_3a_up(:, t)  = c_3a{1,t}  + Pc_3a;
      c_3a_down(:, t)= c_3a{1,t}  - Pc_3a;
      % W3_old is only used by the commented LMI_W update.
   
  
    
      %% 融合中心1 (节点2和节点3)
      input_1 = {c_1a{1,t}, R_1a{1,t}, c_2a{1,t}, R_2a{1,t}, c_3a{1,t}, R_3a{1,t}};
      %% 融合中心1处理  (节点2和节点3)
      %  1阶段融合
      [c_1r{1,t}, R_1r{1,t},J_1r(:,t)] = Fusion_interval(input_1{:});
      %  计算边界
      Pc_1r=sum(abs(R_1r{1,t}),2);
      c_1r_up(:, t)  = c_1r{1,t}  + Pc_1r;
      c_1r_down(:, t)= c_1r{1,t}  - Pc_1r;
      %  2阶段融合
      Vr_1 = MU_ZV(input_1{:});   
      [c_1o{1,t}, R_1o{1,t},~]=  Box_VZ(Vr_1);
      % 融合阶段2
      TY_1 = {c_1r{1,t}, R_1r{1,t}, c_1o{1,t}, R_1o{1,t}};
      [c_1f{1,t}, R_1f{1,t},J_1f(:,t)] = Fusion_interval(TY_1{:});
      Pc_1f=sum(abs(R_1f{1,t}),2);
      c_1f_up(:, t)  = c_1f{1,t}  + Pc_1f;
      c_1f_down(:, t)= c_1f{1,t}  - Pc_1f;

      %% 融合中心2  (节点1和节点3)
      input_2 = {c_2a{1,t}, R_2a{1,t}, c_1a{1,t}, R_1a{1,t}, c_3a{1,t}, R_3a{1,t}};
      %% 融合中心2处理 (节点1和节点3)
      %  1阶段融合
      [c_2r{1,t}, R_2r{1,t},J_2r(:,t)] = Fusion_interval(input_2{:});
      %  计算边界
      Pc_2r=sum(abs(R_2r{1,t}),2);
      c_2r_up(:, t)  = c_2r{1,t}  + Pc_2r;
      c_2r_down(:, t)= c_2r{1,t}  - Pc_2r;
      %  2阶段融合
      Vr_2 = MU_ZV(input_2{:});   
      [c_2o{1,t}, R_2o{1,t},~]=  Box_VZ(Vr_2);
      % 融合阶段2
      TY_2 = {c_2r{1,t}, R_2r{1,t}, c_2o{1,t}, R_2o{1,t}} ;
      [c_2f{1,t}, R_2f{1,t},J_2f(:,t)] = Fusion_interval(TY_2{:});
      Pc_2f=sum(abs(R_2f{1,t}),2);
      c_2f_up(:, t)   = c_2f{1,t}  + Pc_2f;
      c_2f_down(:, t) = c_2f{1,t}  - Pc_2f;
      %% 融合中心3 (节点2和节点1)
      input_3 = {c_3a{1,t}, R_3a{1,t}, c_2a{1,t}, R_2a{1,t}, c_1a{1,t}, R_1a{1,t}};
      %% 融合中心3处理 (节点2和节点1)
      %  1阶段融合
      [c_3r{1,t}, R_3r{1,t},J_3r(:,t)] = Fusion_interval(input_3{:});
      %  计算边界
      Pc_3r=sum(abs(R_3r{1,t}),2);
      c_3r_up(:, t)  = c_3r{1,t}  + Pc_3r;
      c_3r_down(:, t)= c_3r{1,t}  - Pc_3r;
      %  2阶段融合
      Vr_3 = MU_ZV(input_3{:});   
      [c_3o{1,t}, R_3o{1,t},~]=  Box_VZ(Vr_3);
      % 融合阶段2
      TY_3 = {c_3r{1,t}, R_3r{1,t}, c_3o{1,t}, R_3o{1,t}} ;
      [c_3f{1,t}, R_3f{1,t},J_3f(:,t)] = Fusion_interval(TY_3{:});
      Pc_3f=sum(abs(R_3f{1,t}),2);
      c_3f_up(:, t)   = c_3f{1,t}  + Pc_3f;
      c_3f_down(:, t) = c_3f{1,t}  - Pc_3f;
end