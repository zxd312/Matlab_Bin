function vol_box = Volume_Interval(G)
    delta = sum(abs(G), 2);   % half lengths along each coordinate
    vol_box = prod(2 * delta);
end