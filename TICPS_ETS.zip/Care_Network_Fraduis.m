%% Care_Network  F半径+矩阵加权融合 100%融合
N=60;
TF_1=zeros(1,N); TF_2=zeros(1,N); TF_3=zeros(1,N);
%% 初始化
z_1e=cell(1,N); z_2e=cell(1,N); z_3e=cell(1,N); P_1e=cell(1,N); P_2e=cell(1,N); P_3e=cell(1,N);
z_1a=cell(1,N); z_2a=cell(1,N); z_3a=cell(1,N); P_1a=cell(1,N); P_2a=cell(1,N); P_3a=cell(1,N);
z_1r=cell(1,N); z_2r=cell(1,N); z_3r=cell(1,N); P_1r=cell(1,N); P_2r=cell(1,N); P_3r=cell(1,N);
z_1o=cell(1,N); z_2o=cell(1,N); z_3o=cell(1,N); P_1o=cell(1,N); P_2o=cell(1,N); P_3o=cell(1,N);
z_1f=cell(1,N); z_2f=cell(1,N); z_3f=cell(1,N); P_1f=cell(1,N); P_2f=cell(1,N); P_3f=cell(1,N);
zp_1=cell(1,N); zp_2=cell(1,N); zp_3=cell(1,N); Pp_1=cell(1,N); Pp_2=cell(1,N); Pp_3=cell(1,N);
% 初始化估计值
z_1e{1,1}=[0;0];    z_2e{1,1}=[0;0];   z_3e{1,1}=[0;0];
z_1a{1,1}=[0;0];    z_2a{1,1}=[0;0];   z_3a{1,1}=[0;0];
z_1r{1,1}=[0;0];    z_2r{1,1}=[0;0];   z_3r{1,1}=[0;0];
z_1o{1,1}=[0;0];    z_2o{1,1}=[0;0];   z_3o{1,1}=[0;0];
z_1f{1,1}=[0;0];    z_2f{1,1}=[0;0];   z_3f{1,1}=[0;0];
zp_1{1,1}=[0;0];    zp_2{1,1}=[0;0];   zp_3{1,1}=[0;0];
P_1e{1,1}=0.2*eye(2);    P_2e{1,1}=0.2*eye(2);   P_3e{1,1}=0.2*eye(2);
P_1a{1,1}=0.2*eye(2);    P_2a{1,1}=0.2*eye(2);   P_3a{1,1}=0.2*eye(2);
P_1r{1,1}=0.2*eye(2);    P_2r{1,1}=0.2*eye(2);   P_3r{1,1}=0.2*eye(2);
P_1o{1,1}=0.2*eye(2);    P_2o{1,1}=0.2*eye(2);   P_3o{1,1}=0.2*eye(2);
P_1f{1,1}=0.2*eye(2);    P_2f{1,1}=0.2*eye(2);   P_3f{1,1}=0.2*eye(2);
Pp_1{1,1}=0.2*eye(2);    Pp_2{1,1}=0.2*eye(2);   Pp_3{1,1}=0.2*eye(2);
% 初始化边界
z_1a_up(:, 1)= z_1a{1,1}+ 0.2*ones(2,1);  z_1a_down(:, 1)= z_1a{1,1}-0.2*ones(2,1); 
z_2a_up(:, 1)= z_2a{1,1}+ 0.2*ones(2,1);  z_2a_down(:, 1)= z_2a{1,1}-0.2*ones(2,1);
z_3a_up(:, 1)= z_3a{1,1}+ 0.2*ones(2,1);  z_3a_down(:, 1)= z_3a{1,1}-0.2*ones(2,1);  


z_1f_up(:, 1)= z_1a{1,1}+ 0.2*ones(2,1);  z_1f_down(:, 1)= z_1a{1,1}-0.2*ones(2,1); 
z_2f_up(:, 1)= z_2a{1,1}+ 0.2*ones(2,1);  z_2f_down(:, 1)= z_2a{1,1}-0.2*ones(2,1);
z_3f_up(:, 1)= z_3a{1,1}+ 0.2*ones(2,1);  z_3f_down(:, 1)= z_3a{1,1}-0.2*ones(2,1);  
% 初始化性能指标
JF_1a(:,1)=0.16; JF_2a(:,1)=0.16; JF_3a(:,1)=0.16;  
JF_1f(:,1)=0.16; JF_2f(:,1)=0.16; JF_3f(:,1)=0.16; 
JF_1r(:,1)=0.16; JF_2r(:,1)=0.16; JF_3r(:,1)=0.16; 
%
Gamma_mean =(L+U)/2;   Gamma_raduis =U-Gamma_mean;
%% 估计器设计
for t=2:N
% 第一个估计器 中心对称多细胞体估计器设计
 z_1e{1,t} = A*z_1f{1,t-1};
 P_1e{1,t}= [A*P_1f{1,t-1},B*Q];
 % 求解增益矩阵
 PF1_1=Gamma_raduis*diag(C_1*abs(z_1e{1,t}));
 PF1_2=Gamma_raduis*diag(sum(C_1*P_1e{1,t},2)); 
 PF1_3=Gamma_mean*D_1*R_1; 
 PF1_4=Gamma_raduis*D_1*R_1; 
 PF1_5=O_1; 
 F1_D=[PF1_1,PF1_2,PF1_3,PF1_4,PF1_5];
 CF_1=Gamma_mean*C_1;
 S1 = CF_1*P_1e{1,t}*P_1e{1,t}'*CF_1' + F1_D*F1_D';
 KF_1 = P_1e{1,t}*P_1e{1,t}'*CF_1' / S1;
 % 更新
 z_1a{1,t} = (eye(2)-KF_1*CF_1)*z_1e{1,t}+KF_1*y_1(:, t);
 P_1a{1,t} = [(eye(2)-KF_1*CF_1)*P_1e{1,t},-KF_1*F1_D];
 P_1a{1,t} = Reduction(P_1a{1,t},q1);
 JF_1a(:,t)= Volume_Interval(P_1a{1,t});
 Pf_1a=sum(abs(P_1a{1,t}),2); 
 z_1a_up(:, t)  = z_1a{1,t}  + Pf_1a;
 z_1a_down(:, t)= z_1a{1,t}  - Pf_1a;
 % 关于预测1的迭代 
 % zp_1{1,t} = A*zp_1{1,t-1};
 % Pp_1{1,t} = [A*Pp_1{1,t-1},B*Q];
 % Pp_1{1,t} = Reduction(Pp_1{1,t},q);

 % 第二个估计器 中心对称多细胞体估计器设计
 z_2e{1,t} = A*z_2f{1,t-1};
 P_2e{1,t}= [A*P_2f{1,t-1},B*Q];
 % 求解增益矩阵
 PF2_1=Gamma_raduis*diag(C_2*abs(z_2e{1,t}));
 PF2_2=Gamma_raduis*diag(sum(C_2*P_2e{1,t},2)); 
 PF2_3=Gamma_mean*D_2*R_2; 
 PF2_4=Gamma_raduis*D_2*R_2; 
 PF2_5=O_2; 
 F2_D=[PF2_1,PF2_2,PF2_3,PF2_4,PF2_5];
 CF_2=Gamma_mean*C_2;
 S2 = CF_2*P_2e{1,t}*P_2e{1,t}'*CF_2' + F2_D*F2_D';
 KF_2=P_2e{1,t}*P_2e{1,t}'*CF_2' / S2;
 % 更新
 z_2a{1,t} = (eye(2)-KF_2*CF_2)*z_2e{1,t}+KF_2*y_2(:, t);
 P_2a{1,t} = [(eye(2)-KF_2*CF_2)*P_2e{1,t},-KF_2*F2_D];
 P_2a{1,t} = Reduction(P_2a{1,t},q2);
 JF_2a(:,t)= Volume_Interval(P_2a{1,t});
 Pf_2a=sum(abs(P_2a{1,t}),2); 
 z_2a_up(:, t)  = z_2a{1,t}  + Pf_2a;
 z_2a_down(:, t)= z_2a{1,t}  - Pf_2a;
 
 % 关于预测2的迭代 
 % zp_2{1,t} = A*zp_2{1,t-1};
 % Pp_2{1,t} = [A*Pp_2{1,t-1},B*Q];
 % Pp_2{1,t} = Reduction(Pp_2{1,t},q);
% 第三个估计器 中心对称多细胞体估计器设计
 z_3e{1,t} = A*z_3f{1,t-1};
 P_3e{1,t}= [A*P_3f{1,t-1},B*Q];
 % 求解增益矩阵
 PF3_1=Gamma_raduis*diag(C_3*abs(z_3e{1,t}));
 PF3_2=Gamma_raduis*diag(sum(C_3*P_3e{1,t},2)); 
 PF3_3=Gamma_mean*D_3*R_3; 
 PF3_4=Gamma_raduis*D_3*R_3; 
 PF3_5=O_3; 
 F3_D=[PF3_1,PF3_2,PF3_3,PF3_4,PF3_5];
 CF_3=Gamma_mean*C_3;
 S3  = CF_3*P_3e{1,t}*P_3e{1,t}'*CF_3'+F3_D*F3_D';
 KF_3= P_3e{1,t}*P_3e{1,t}'*CF_3' / S3;
 % 更新
 z_3a{1,t} = (eye(2)-KF_3*CF_3)*z_3e{1,t}+KF_3*y_3(:, t);
 P_3a{1,t} = [(eye(2)-KF_3*CF_3)*P_3e{1,t},-KF_3*F3_D];
 P_3a{1,t} = Reduction(P_3a{1,t},q3);
 JF_3a(:,t)= Volume_Interval(P_3a{1,t});
 Pf_3a=sum(abs(P_3a{1,t}),2); 
 z_3a_up(:, t)  = z_3a{1,t}  + Pf_3a;
 z_3a_down(:, t)= z_3a{1,t}  - Pf_3a;
 % 关于预测3的迭代 
 % zp_3{1,t} = A*zp_3{1,t-1};
 % Pp_3{1,t} = [A*Pp_3{1,t-1},B*Q];
 % Pp_3{1,t} = Reduction(Pp_3{1,t},q);
 %% 关于估计器1是否需要进行触发
 %      flag1 = ETS_Fr(z_1a{1,t},P_1a{1,t},zp_1{1,t},Pp_1{1,t},0.06,1);
 %      ct_1=zp_1{1,t};
 %      Rt_1=Pp_1{1,t};
 %      if flag1 == 3 || flag1 == 1
 %          zp_1{1,t} = z_1a{1,t};
 %          Pp_1{1,t} = P_1a{1,t};
 %          TF_1(t)=1;
 %      end
 %      %% 关于估计器2是否需要进行触发
 %      flag2 = ETS_Fr(z_2a{1,t},P_2a{1,t},zp_2{1,t},Pp_2{1,t},0.06,1);
 %      ct_2=zp_2{1,t};
 %      Rt_2=Pp_2{1,t};
 %      if flag2 == 3 || flag2 == 1
 %          zp_2{1,t} = z_2a{1,t};
 %          Pp_2{1,t} = P_2a{1,t};
 %          TF_2(t)=1;
 %      end
 %      %% 关于估计器3是否需要进行触发
 %      flag3 = ETS_Fr(z_3a{1,t},P_3a{1,t},zp_3{1,t},Pp_3{1,t},0.06,1);
 %      ct_3=zp_3{1,t};
 %      Rt_3=Pp_3{1,t};
 %      if flag3 == 3 || flag3 == 1
 %          zp_3{1,t} = z_3a{1,t};
 %          Pp_3{1,t} = P_3a{1,t};
 %          TF_3(t)=1;
 %      end
    
      %% 融合中心1 (节点2和节点3)
      input_1 = {z_1a{1,t}, P_1a{1,t}, z_2a{1,t}, P_2a{1,t}, z_3a{1,t}, P_3a{1,t}};
      %% 融合中心1处理  (节点2和节点3)
      %  1阶段融合
      [z_1f{1,t},P_1f{1,t}] = Matrix_Fusion(input_1{:});
      JF_1f(:,t)= Volume_Interval(P_1f{1,t});
      %  计算边界
      Pz_1f=sum(abs(P_1f{1,t}),2);
      z_1f_up(:, t)  = z_1f{1,t}  + Pz_1f;
      z_1f_down(:, t)= z_1f{1,t}  - Pz_1f;
      %% 融合中心2  (节点1和节点3)
      input_2 = {z_1a{1,t}, P_1a{1,t}, z_2a{1,t}, P_2a{1,t}, z_3a{1,t}, P_3a{1,t}};
      %% 融合中心2处理 (节点1和节点3)
      %  1阶段融合
      [z_2f{1,t},P_2f{1,t}] = Matrix_Fusion(input_2{:});
      JF_2f(:,t)= Volume_Interval(P_2f{1,t});
      %  计算边界
      Pz_2f=sum(abs(P_1f{1,t}),2);
      z_2f_up(:, t)  = z_2f{1,t}  + Pz_2f;
      z_2f_down(:, t)= z_2f{1,t}  - Pz_2f;
      %% 融合中心3 (节点2和节点1)
      input_3 = {z_1a{1,t}, P_1a{1,t}, z_2a{1,t}, P_2a{1,t}, z_3a{1,t}, P_3a{1,t}};
      %% 融合中心3处理 (节点2和节点1)
      %  1阶段融合
      [z_3f{1,t},P_3f{1,t}] = Matrix_Fusion(input_3{:});
      JF_3f(:,t)= Volume_Interval(P_3f{1,t});
      %  计算边界
      Pz_3f=sum(abs(P_3f{1,t}),2);
      z_3f_up(:, t)  = z_3f{1,t}  + Pz_3f;
      z_3f_down(:, t)= z_3f{1,t}  - Pz_3f;
end




%% 
sum(TF_1);  sum(T_1);
sum(TF_2);
sum(TF_3);

sum(JF_1a)/N;    sum(J_1a)/N;   
sum(JF_2a)/N;    sum(J_2a)/N;
sum(JF_3a)/N;    sum(J_3a)/N;


sum(JF_1f)/N;    sum(J_1r)/N;  sum(J_1f)/N;
sum(JF_2f)/N;    sum(J_2r)/N;  sum(J_2f)/N;
sum(JF_3f)/N;    sum(J_3r)/N;  sum(J_3f)/N;
%% 




%% 状态估计图
plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  z_1a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_1a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_1f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  z_1f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置

plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  z_1a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_1a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_1f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  z_1f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度

plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  z_2a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  z_2f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置


plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  z_2a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  z_2f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度


plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_3a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_3f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置


plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_3a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_3f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度