function flag = ETS_box(c1,R1,c2,R2,beta1,beta2)
%% ============================================================
% PCA_FusionJudge
%
% 功能：
%   判断两个 zonotope 交集融合后，性能指标是否有明显提升。
%
% 输入：
%   c1,R1  : 第一个 zonotope Z1=<c1,R1> 局部估计
%   c2,R2  : 第二个 zonotope Z2=<c2,R2> 预测估计
%   beta1  : 相对第一个 zonotope 的提升阈值
%   beta2  : 相对第二个 zonotope 的提升阈值
%
% 输出：
%   flag = 0 :
%       相对第二个提升不大，相对第一个提升也不大
%
%   flag = 1 :
%       相对第二个提升大，但是相对第一个提升不大
%
%   flag = 2 :
%       相对第二个提升大，相对第一个提升也大
%
% 依赖：
%   MU_ZV.m
%   PCA_VZ.m
%% ============================================================
%% 1. 整理输入
c1 = c1(:);
c2 = c2(:);
n = length(c1);
if length(c2) ~= n
    error('两个 zonotope 的中心维度不一致。');
end
if size(R1,1) ~= n
    error('R1 的行数必须等于状态维数。');
end

if size(R2,1) ~= n
    error('R2 的行数必须等于状态维数。');
end
%% 1. 计算第每个 zonotope 的 box 性能指标
J1=Volume_Interval(R1);
J2=Volume_Interval(R2);
%% 2. 计算两个 zonotope 交集顶点
Ve = MU_ZV(c1,R1,c2,R2);
%% 3. 计算交集融合后的 box 性能指标
[~,~,Jf] = Box_VZ(Ve);
%% 6. 计算提升率
improve1 = (J1 - Jf)/J1;
improve2 = (J2 - Jf)/J2;
%% 7. 判断 flag
% 需要两者相交进行融合 且进行传输的 模式3
% if improve2 >= beta2 && improve1 >= beta1
%     flag = 3;
% end
% % 需要两者相交进行融合 且不需要传输的 模式2
% if improve2 <= beta2 && improve1 >= beta1
%     flag = 2;
% end
% % 不需要两者取交，且进行传输的 模式1
% if improve2 >= beta2 && improve1 < beta1
%     flag = 1;
% end
% % 不需要传输的
% if improve2 < beta2 && improve1 < beta1
%     flag = 0;
% end
if improve2 >= beta2 && improve1 >= beta1
    flag = 3;   %% 需要传输且需要预测进行融合
  
elseif improve2 < beta2 && improve1 >= beta1
    flag = 2;   %% 不需要传输且需要预测进行融合

elseif improve2 >= beta2 && improve1 < beta1
    flag = 1;   %% 需要传输且不需要预测进行融合

else
    flag = 0;   %%  不传输也不需要融合
end

end