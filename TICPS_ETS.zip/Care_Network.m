%% 目标追踪：A ETS；%% 直接使用区间宽度为性能指标, 三个传感器为例子
clc;
clear;
%% 动力学方程
N=60;
T=0.2;
A = [1 T;0 1];             B = [T^2/2;T]; 
C_1 = eye(2);              C_2 = eye(2);                C_3 = eye(2);  
D_1 = diag([0.4,-0.5]);    D_2 =diag([0.8,-0.2]);       D_3 = diag([0.2,-0.4]); 
x(:, 1)=[0;0];
U=0.85; L=0.75;
% A_U = diag([0.05,0.1]);
Gamma1=(L+U)/(2*L*U);  Gamma1_r=(U-L)/(2*L*U);
Gamma2=(L+U)/(2*L*U);  Gamma2_r=(U-L)/(2*L*U);
Gamma3=(L+U)/(2*L*U);  Gamma3_r=(U-L)/(2*L*U);
V_1 = cell(1,N);   V_2 = cell(1,N);   V_3 = cell(1,N);  
W1_old=eye(2); W2_old=eye(2); W3_old=eye(2); W_old =eye(2);
% 传输不确定性矩阵
for k = 1:N
    V_1{k} = diag([0.80 + 0.05*sin(0.15*(k-1)), 0.80 + 0.05*cos(0.12*(k-1))]);
    V_2{k} = diag([0.80 + 0.05*cos(0.10*(k-1) + 0.3),  0.80 + 0.05*sin(0.18*(k-1) + 0.5)]);
    V_3{k} = diag([0.80 + 0.05*sin(0.12*(k-1) + 0.4),  0.80 + 0.05*sin(0.09*(k-1) + 1.1)]);    
end
% 噪声生成
w=zeros(1,N);    v_1=zeros(2,N);  v_2=zeros(2,N); v_3=zeros(2,N);
o_1=zeros(2,N);  o_2=zeros(2,N);  o_3=zeros(2,N);
for t = 1:N
w(:,t)   = 0.5*sin(t-1);
v_1(:,t) = [0.4*cos(0.2*(t-1));  -0.4*cos(0.5*(t-1))];
v_2(:,t) = [-0.4*sin(0.5*(t-1)); 0.4*sin(0.1*(t-1))];
v_3(:,t) = [0.4*cos(0.8*(t-1)); 0.4*sin(0.1*(t-1))]; 
o_1(:,t) = [0.1*cos(t-1);       -0.1*sin(0.5*(t-1))];
o_2(:,t) = [-0.1*sin(0.5*(t-1)); 0.1*cos(t-1)];
o_3(:,t) = [0.1*sin(t-1);       0.1*cos(0.5*(t-1))];
end
Q =0.5*eye(1);  R_1=0.4*eye(2); R_2=0.4*eye(2); R_3=0.4*eye(2); 
O_1=0.1*eye(2); O_2=0.1*eye(2); O_3=0.1*eye(2);
%% 降维算子
q1=12; q2=12; q3=12; q=12;
%% 真实状态演化
 y_1(:, 1) = V_1{1}*(C_1 * x(:, 1) + D_1*v_1(:,1)) + o_1(:,1);
 y_2(:, 1) = V_2{1}*(C_2 * x(:, 1) + D_2*v_2(:,1)) + o_2(:,1);
 y_3(:, 1) = V_3{1}*(C_3 * x(:, 1) + D_3*v_3(:,1)) + o_3(:,1);
%% 
for t=2:N
 x(:, t) = A* x(:, t-1) + B*w(:,t-1);
 % 观测更新
 y_1(:, t) = V_1{t}*(C_1 * x(:, t) + D_1*v_1(:,t)) + o_1(:,t);
 y_2(:, t) = V_2{t}*(C_2 * x(:, t) + D_2*v_2(:,t)) + o_2(:,t);
 y_3(:, t) = V_3{t}*(C_3 * x(:, t) + D_3*v_3(:,t)) + o_3(:,t);
end
%% 初始化
T_1=zeros(1,N); T_2=zeros(1,N); T_3=zeros(1,N);
c_1e=cell(1,N); c_2e=cell(1,N); c_3e=cell(1,N); R_1e=cell(1,N); R_2e=cell(1,N); R_3e=cell(1,N);
c_1a=cell(1,N); c_2a=cell(1,N); c_3a=cell(1,N); R_1a=cell(1,N); R_2a=cell(1,N); R_3a=cell(1,N);
c_1r=cell(1,N); c_2r=cell(1,N); c_3r=cell(1,N); R_1r=cell(1,N); R_2r=cell(1,N); R_3r=cell(1,N);
c_1o=cell(1,N); c_2o=cell(1,N); c_3o=cell(1,N); R_1o=cell(1,N); R_2o=cell(1,N); R_3o=cell(1,N);
c_1f=cell(1,N); c_2f=cell(1,N); c_3f=cell(1,N); R_1f=cell(1,N); R_2f=cell(1,N); R_3f=cell(1,N);
cp_1=cell(1,N); cp_2=cell(1,N); cp_3=cell(1,N); Rp_1=cell(1,N); Rp_2=cell(1,N); Rp_3=cell(1,N);
% 初始化估计值
c_1e{1,1}=[0;0];    c_2e{1,1}=[0;0];   c_3e{1,1}=[0;0];
c_1a{1,1}=[0;0];    c_2a{1,1}=[0;0];   c_3a{1,1}=[0;0];
c_1r{1,1}=[0;0];    c_2r{1,1}=[0;0];   c_3r{1,1}=[0;0];
c_1o{1,1}=[0;0];    c_2o{1,1}=[0;0];   c_3o{1,1}=[0;0];
c_1f{1,1}=[0;0];    c_2f{1,1}=[0;0];   c_3f{1,1}=[0;0];
cp_1{1,1}=[0;0];    cp_2{1,1}=[0;0];   cp_3{1,1}=[0;0];
% cp_1{1,1}=[0;0];    cp_2{1,1}=[-0.1;0.3];   cp_3{1,1}=[-0.1;-0.1];
% 初始化生成矩阵
R_1e{1,1}=0.2*eye(2);    R_2e{1,1}=0.2*eye(2);   R_3e{1,1}=0.2*eye(2);
R_1a{1,1}=0.2*eye(2);    R_2a{1,1}=0.2*eye(2);   R_3a{1,1}=0.2*eye(2);
R_1r{1,1}=0.2*eye(2);    R_2r{1,1}=0.2*eye(2);   R_3r{1,1}=0.2*eye(2);
R_1o{1,1}=0.2*eye(2);    R_2o{1,1}=0.2*eye(2);   R_3o{1,1}=0.2*eye(2);
R_1f{1,1}=0.2*eye(2);    R_2f{1,1}=0.2*eye(2);   R_3f{1,1}=0.2*eye(2);
Rp_1{1,1}=0.2*eye(2);    Rp_2{1,1}=0.2*eye(2);   Rp_3{1,1}=0.2*eye(2);
% 初始化边界
c_1a_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1a_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2a_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2a_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3a_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3a_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  

c_1r_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1r_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2r_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2r_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3r_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3r_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  

c_1f_up(:, 1)= c_1a{1,1}+ 0.2*ones(2,1);  c_1f_down(:, 1)= c_1a{1,1}-0.2*ones(2,1); 
c_2f_up(:, 1)= c_2a{1,1}+ 0.2*ones(2,1);  c_2f_down(:, 1)= c_2a{1,1}-0.2*ones(2,1);
c_3f_up(:, 1)= c_3a{1,1}+ 0.2*ones(2,1);  c_3f_down(:, 1)= c_3a{1,1}-0.2*ones(2,1);  
% 初始化性能指标
J_1a(:,1)=0.16; J_2a(:,1)=0.16; J_3a(:,1)=0.16;  
J_1f(:,1)=0.16; J_2f(:,1)=0.16; J_3f(:,1)=0.16; 
J_1r(:,1)=0.16; J_2r(:,1)=0.16; J_3r(:,1)=0.16; 
%% 估计器设计
for t=2:N
% 第一个估计器 中心对称多细胞体估计器设计
 c_1e{1,t} = A*c_1f{1,t-1};
 R_1e{1,t}= [A*R_1f{1,t-1},B*Q];
% 求解增益矩阵
  N_11=[R_1e{1,t},zeros(2,8)];
  N_12=[-C_1*R_1e{1,t},diag(Gamma1_r*abs(y_1(:, t))),-Gamma1*O_1,-Gamma1_r*O_1,-D_1*R_1];
  K1_opt = zeros(2, 2);
  col_1 =  size(N_11,2);
  options = sdpsettings('solver', 'sedumi', ...
         'verbose', 1, ...
         'sedumi.eps', 1e-10, ... % 求解精度
         'sedumi.maxiter', 200);  % 最大迭代次数
% 使用循环求解优化问题
    for i = 1:size(N_11,1)
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        K1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*K1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*K1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
         % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K1_opt(i,:) = value(K1_i);   % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
      % 最终结果矩阵
      K1= K1_opt;
      c_1a{1,t}= (eye(2)-K1*C_1)*c_1e{1,t} + K1*Gamma1*y_1(:, t);
      R_1a{1,t}= N_11+K1*N_12;
      R_1a{1,t}=Reduction(R_1a{1,t},q1);
      J_1a(:,t)=Volume_Interval(R_1a{1,t});
      Pc_1a=sum(abs(R_1a{1,t}),2);
      c_1a_up(:, t)  = c_1a{1,t}  + Pc_1a;
      c_1a_down(:, t)= c_1a{1,t}  - Pc_1a;
      % 关于预测1的迭代 
      cp_1{1,t} = A*cp_1{1,t-1};
      Rp_1{1,t} = [A*Rp_1{1,t-1},B*Q];
      Rp_1{1,t} = Reduction(Rp_1{1,t},q);

      % 第二个估计器 中心对称多细胞体估计器设计
      c_2e{1,t} = A*c_2f{1,t-1};
      R_2e{1,t}= [A*R_2f{1,t-1},B*Q];
      % 求解增益矩阵
      N_22=[R_2e{1,t},zeros(2,8)];
      N_21=[-C_2*R_2e{1,t},diag(Gamma2_r*abs(y_2(:, t))),-Gamma2*O_2,-Gamma2_r*O_2,-D_2*R_2];
      K2_opt = zeros(2, 2);
      col_2 =  size(N_22,2);
     % 使用循环求解优化问题
      for i = 1:size(N_22,1)
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);      % 向量λ_i
        K2_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*K2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*K2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K2_opt(i,:) = value(K2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
      end

      % 最终结果矩阵
      K2= K2_opt;
      c_2a{1,t}=(eye(2)-K2*C_2)*c_2e{1,t} + K2*Gamma2*y_2(:, t);
      R_2a{1,t}= N_22+K2*N_21; 
      R_2a{1,t}=Reduction(R_2a{1,t},q2);
      J_2a(:,t)=Volume_Interval(R_2a{1,t});
      Pc_2a=sum(abs(R_2a{1,t}),2);
      c_2a_up(:, t)  = c_2a{1,t}  + Pc_2a;
      c_2a_down(:, t)= c_2a{1,t}  - Pc_2a;
      % W2_old is only used by the commented LMI_W update.
      % 关于预测2的迭代 
      cp_2{1,t} = A*cp_2{1,t-1};
      Rp_2{1,t}= [A*Rp_2{1,t-1},B*Q];
      Rp_2{1,t} = Reduction(Rp_2{1,t},q);
      % 第三个估计器 中心对称多细胞体估计器设计
      c_3e{1,t} = A*c_3f{1,t-1};
      R_3e{1,t}= [A*R_3f{1,t-1},B*Q];
      % 求解增益矩阵
      N_33=[R_3e{1,t},zeros(2,8)];
      N_31=[-C_3*R_3e{1,t},diag(Gamma3_r*abs(y_3(:, t))),-Gamma3*O_3,-Gamma3_r*O_3,-D_3*R_3];
      K3_opt = zeros(2, 2);
      col_3 =  size(N_33,2);
% 使用循环求解优化问题
    for i = 1:size(N_33,1)
        % 定义决策变量
        L3_i = sdpvar(col_3, 1);      % 向量λ_i
        K3_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_33(i,:)' +  N_31'*K3_i' >= -L3_i,
            N_33(i,:)' +  N_31'*K3_i' <=  L3_i
            ];
        % 设置目标函数
        Objective = sum(L3_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K3_opt(i,:) = value(K3_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K3_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
      % 最终结果矩阵
      K3= K3_opt;
      c_3a{1,t}=(eye(2)-K3*C_3)*c_3e{1,t} + K3*Gamma3*y_3(:, t);
      R_3a{1,t}= N_33+K3*N_31; 
      % W3 = LMI_W(W3_old, (eye(2)-K3*C_3{t})*A{t-1}, 0.98);
      R_3a{1,t}=Reduction(R_3a{1,t},q3);
      J_3a(:,t)=Volume_Interval(R_3a{1,t});
      Pc_3a=sum(abs(R_3a{1,t}),2);
      c_3a_up(:, t)  = c_3a{1,t}  + Pc_3a;
      c_3a_down(:, t)= c_3a{1,t}  - Pc_3a;
      % W3_old is only used by the commented LMI_W update.
      % 关于预测3的迭代 
      cp_3{1,t} =  A*cp_3{1,t-1};
      Rp_3{1,t} = [A*Rp_3{1,t-1},B*Q];
      Rp_3{1,t} = Reduction(Rp_3{1,t},q);
      %% 关于估计器1是否需要进行触发
      flag1 = ETS_box(c_1a{1,t},R_1a{1,t},cp_1{1,t},Rp_1{1,t},0.06,0.55);
      ct_1=cp_1{1,t};
      Rt_1=Rp_1{1,t};
      if flag1 == 3 || flag1 == 1
          cp_1{1,t} = c_1a{1,t};
          Rp_1{1,t} = R_1a{1,t};
          T_1(t)=1;
      end
      %% 关于估计器2是否需要进行触发
      flag2 = ETS_box(c_2a{1,t},R_2a{1,t},cp_2{1,t},Rp_2{1,t},0.06,0.55);
      ct_2=cp_2{1,t};
      Rt_2=Rp_2{1,t};
      if flag2 == 3 || flag2 == 1
          cp_2{1,t} = c_2a{1,t};
          Rp_2{1,t} = R_2a{1,t};
          T_2(t)=1;
      end
      %% 关于估计器3是否需要进行触发
      flag3 = ETS_box(c_3a{1,t},R_3a{1,t},cp_3{1,t},Rp_3{1,t},0.06,0.55);
      ct_3=cp_3{1,t};
      Rt_3=Rp_3{1,t};
      if flag3 == 3 || flag3 == 1
          cp_3{1,t} = c_3a{1,t};
          Rp_3{1,t} = R_3a{1,t};
          T_3(t)=1;
      end
    
      %% 融合中心1 (节点2和节点3)
      input_1 = {c_1a{1,t}, R_1a{1,t}, cp_2{1,t}, Rp_2{1,t}, cp_3{1,t}, Rp_3{1,t}};

      if flag1==3 || flag1==2

      input_1 = [input_1, {ct_1, Rt_1}];

      end

      if flag2==3 

      input_1 = [input_1, {ct_2, Rt_2}];
      
      end

      if flag3==3 

      input_1 = [input_1, {ct_3, Rt_3}];
      
      end

      %% 融合中心1处理  (节点2和节点3)
      %  1阶段融合
      [c_1r{1,t}, R_1r{1,t},J_1r(:,t)] = Fusion_interval(input_1{:});
      %  计算边界
      Pc_1r=sum(abs(R_1r{1,t}),2);
      c_1r_up(:, t)  = c_1r{1,t}  + Pc_1r;
      c_1r_down(:, t)= c_1r{1,t}  - Pc_1r;
      %  2阶段融合
      Vr_1 = MU_ZV(input_1{:});   
      [c_1o{1,t}, R_1o{1,t},~]=  Box_VZ(Vr_1);
      % 融合阶段2
      TY_1 = {c_1r{1,t}, R_1r{1,t}, c_1o{1,t}, R_1o{1,t}};
      [c_1f{1,t}, R_1f{1,t},J_1f(:,t)] = Fusion_interval(TY_1{:});
      Pc_1f=sum(abs(R_1f{1,t}),2);
      c_1f_up(:, t)  = c_1f{1,t}  + Pc_1f;
      c_1f_down(:, t)= c_1f{1,t}  - Pc_1f;

      %% 融合中心2  (节点1和节点3)
      input_2 = {c_2a{1,t}, R_2a{1,t}, cp_1{1,t}, Rp_1{1,t}, cp_3{1,t}, Rp_3{1,t}};

      if flag2==3 || flag2==2

      input_2 = [input_2, {ct_2, Rt_2}];

      end

      if flag1==3 

       input_2 = [input_2, {ct_1, Rt_1}];
      
      end

      if flag3==3 

      input_2 = [input_2, {ct_3, Rt_3}];
      
      end

      %% 融合中心2处理 (节点1和节点3)
      %  1阶段融合
      [c_2r{1,t}, R_2r{1,t},J_2r(:,t)] = Fusion_interval(input_2{:});
      %  计算边界
      Pc_2r=sum(abs(R_2r{1,t}),2);
      c_2r_up(:, t)  = c_2r{1,t}  + Pc_2r;
      c_2r_down(:, t)= c_2r{1,t}  - Pc_2r;
      %  2阶段融合
      Vr_2 = MU_ZV(input_2{:});   
      [c_2o{1,t}, R_2o{1,t},~]=  Box_VZ(Vr_2);
      % 融合阶段2
      TY_2 = {c_2r{1,t}, R_2r{1,t}, c_2o{1,t}, R_2o{1,t}} ;
      [c_2f{1,t}, R_2f{1,t},J_2f(:,t)] = Fusion_interval(TY_2{:});
      Pc_2f=sum(abs(R_2f{1,t}),2);
      c_2f_up(:, t)   = c_2f{1,t}  + Pc_2f;
      c_2f_down(:, t) = c_2f{1,t}  - Pc_2f;
      %% 融合中心3 (节点2和节点1)

      input_3 = {c_3a{1,t}, R_3a{1,t}, cp_2{1,t}, Rp_2{1,t}, cp_1{1,t}, Rp_1{1,t}};

      if flag3==3 || flag3==2

       input_3 = [input_3, {ct_3, Rt_3}];

      end

      if flag2==3 

      input_3 = [input_3, {ct_2, Rt_2}];
      
      end

      if flag1==3 

      input_3 = [input_3, {ct_1, Rt_1}];
      
      end

      %% 融合中心3处理 (节点2和节点1)
      %  1阶段融合
      [c_3r{1,t}, R_3r{1,t},J_3r(:,t)] = Fusion_interval(input_3{:});
      %  计算边界
      Pc_3r=sum(abs(R_3r{1,t}),2);
      c_3r_up(:, t)  = c_3r{1,t}  + Pc_3r;
      c_3r_down(:, t)= c_3r{1,t}  - Pc_3r;
      %  2阶段融合
      Vr_3 = MU_ZV(input_3{:});   
      [c_3o{1,t}, R_3o{1,t},~]=  Box_VZ(Vr_3);
      % 融合阶段2
      TY_3 = {c_3r{1,t}, R_3r{1,t}, c_3o{1,t}, R_3o{1,t}} ;
      [c_3f{1,t}, R_3f{1,t},J_3f(:,t)] = Fusion_interval(TY_3{:});
      Pc_3f=sum(abs(R_3f{1,t}),2);
      c_3f_up(:, t)   = c_3f{1,t}  + Pc_3f;
      c_3f_down(:, t) = c_3f{1,t}  - Pc_3f;
end
sum(T_1)/N;
sum(T_2)/N;
sum(T_3)/N;

%%


sum(J_1a)/N;    sum(J_1r)/N;  sum(J_1f)/N;
sum(J_2a)/N;    sum(J_2r)/N;  sum(J_2f)/N;
sum(J_3a)/N;    sum(J_3r)/N;  sum(J_3f)/N;

%% 绘制不同通信速率下的融合估计与局部估计比较图像
% 通信率50    参数为0.55
Tl1_50=sum(J_1a)/N;  Tr1_50=sum(J_1r)/N; Tf1_50=sum(J_1f)/N;
Tl2_50=sum(J_2a)/N;  Tr2_50=sum(J_2r)/N; Tf2_50=sum(J_2f)/N;
Tl3_50=sum(J_3a)/N;  Tr3_50=sum(J_3r)/N; Tf3_50=sum(J_3f)/N;
 
% 通信率40   参数为0.62
Tl1_40=sum(J_1a)/N;  Tr1_40=sum(J_1r)/N; Tf1_40=sum(J_1f)/N;
Tl2_40=sum(J_2a)/N;  Tr2_40=sum(J_2r)/N; Tf2_40=sum(J_2f)/N;
Tl3_40=sum(J_3a)/N;  Tr3_40=sum(J_3r)/N; Tf3_40=sum(J_3f)/N;

% 通信率30   参数为0.7 0.7 0.74
Tl1_30=sum(J_1a)/N;  Tr1_30=sum(J_1r)/N; Tf1_30=sum(J_1f)/N;
Tl2_30=sum(J_2a)/N;  Tr2_30=sum(J_2r)/N; Tf2_30=sum(J_2f)/N;
Tl3_30=sum(J_3a)/N;  Tr3_30=sum(J_3r)/N; Tf3_30=sum(J_3f)/N;


% 通信率20   参数为   0.81 0.84 0.84
Tl1_20=sum(J_1a)/N;  Tr1_20=sum(J_1r)/N; Tf1_20=sum(J_1f)/N;
Tl2_20=sum(J_2a)/N;  Tr2_20=sum(J_2r)/N; Tf2_20=sum(J_2f)/N;
Tl3_20=sum(J_3a)/N;  Tr3_20=sum(J_3r)/N; Tf3_20=sum(J_3f)/N;

% 通信率10   参数为   0.92 0.94 0.94
Tl1_10=sum(J_1a)/N;  Tr1_10=sum(J_1r)/N; Tf1_10=sum(J_1f)/N;
Tl2_10=sum(J_2a)/N;  Tr2_10=sum(J_2r)/N; Tf2_10=sum(J_2f)/N;
Tl3_10=sum(J_3a)/N;  Tr3_10=sum(J_3r)/N; Tf3_10=sum(J_3f)/N;


%% 通信率 60 70 80 90
% 通信率60    参数为0.45  0.45 0.5
Tl1_60=sum(J_1a)/N;  Tr1_60=sum(J_1r)/N; Tf1_60=sum(J_1f)/N;
Tl2_60=sum(J_2a)/N;  Tr2_60=sum(J_2r)/N; Tf2_60=sum(J_2f)/N;
Tl3_60=sum(J_3a)/N;  Tr3_60=sum(J_3r)/N; Tf3_60=sum(J_3f)/N;



% 通信率70    参数为0.45  0.45 0.5
Tl1_70=sum(J_1a)/N;  Tr1_70=sum(J_1r)/N; Tf1_70=sum(J_1f)/N;
Tl2_70=sum(J_2a)/N;  Tr2_70=sum(J_2r)/N; Tf2_70=sum(J_2f)/N;
Tl3_70=sum(J_3a)/N;  Tr3_70=sum(J_3r)/N; Tf3_70=sum(J_3f)/N;




% 通信率80    参数为0.3  0.32 0.45
Tl1_80=sum(J_1a)/N;  Tr1_80=sum(J_1r)/N; Tf1_80=sum(J_1f)/N;
Tl2_80=sum(J_2a)/N;  Tr2_80=sum(J_2r)/N; Tf2_80=sum(J_2f)/N;
Tl3_80=sum(J_3a)/N;  Tr3_80=sum(J_3r)/N; Tf3_80=sum(J_3f)/N;


% 通信率90    参数为0.2  0.32 0.35
Tl1_90=sum(J_1a)/N;  Tr1_90=sum(J_1r)/N; Tf1_90=sum(J_1f)/N;
Tl2_90=sum(J_2a)/N;  Tr2_90=sum(J_2r)/N; Tf2_90=sum(J_2f)/N;
Tl3_90=sum(J_3a)/N;  Tr3_90=sum(J_3r)/N; Tf3_90=sum(J_3f)/N;


%
Tl1_100=sum(J_1a)/N;  Tr1_100=sum(J_1r)/N; Tf1_100=sum(J_1f)/N;
Tl2_100=sum(J_2a)/N;  Tr2_100=sum(J_2r)/N; Tf2_100=sum(J_2f)/N;
Tl3_100=sum(J_3a)/N;  Tr3_100=sum(J_3r)/N; Tf3_100=sum(J_3f)/N;



% 通信率100    参数为0.45  0.45 0.5
Tl1_100=0.3226;  Tr1_100=0.2075; Tf1_100=0.1778;
Tl2_100=0.2235;  Tr2_100=0.2075; Tf2_100=0.1778;
Tl3_100=0.2814;  Tr3_100=0.2075; Tf3_100=0.1778;




T1_L=[Tl1_10,Tl1_20,Tl1_30,Tl1_40,Tl1_50,Tl1_60,Tl1_70,Tl1_80,Tl1_90,Tl1_100];










Tl2_40=   ;  Tr2_40=   ; Tf2_40 ;

Tl3_30=   ;  Tr3_30=   ; Tf3_30;

Tl1_20=   ;  Tr1_20=   ; Tf1_20;


Tl1_10=   ;  Tr1_10=   ; Tr1_10 ;

%%
Tl1_60=   ;  Tr1_60=   ; Tr1_60 ;

Tl1_70=   ;  Tr1_70=   ; Tr1_70 ;

Tl1_80=   ;  Tr1_80=   ; Tr1_80 ;

Tl1_90=   ;  Tr1_90=   ; Tr1_90 ;

%% 触发率 
step_k = 1:N;
% 合并触发序列
T_all = [T_1; T_2; T_3];
% 触发率（t=1 为初始时刻，不计入）
trigger_rate = sum(T_all(:,2:N), 2) / (N-1) * 100;
figure('Color','w','Position',[120 100 860 430]);
hold on; box on;
% 颜色和标记
clr1 = [0.00 0.00 1.00];   % blue
clr2 = [1.00 0.00 0.00];   % red
clr3 = [1.00 0.00 1.00];   % magenta

% 找到各传感器触发时刻
idx1 = find(T_all(1,:) == 1);
idx2 = find(T_all(2,:) == 1);
idx3 = find(T_all(3,:) == 1);
% 绘制触发点
h1 = plot(idx1, 1*ones(size(idx1)), 'x', ...
    'Color', clr1, ...
    'LineWidth', 1.6, ...
    'MarkerSize', 6);
h2 = plot(idx2, 2*ones(size(idx2)), 'o', ...
    'Color', clr2, ...
    'LineWidth', 1.6, ...
    'MarkerSize', 5, ...
    'MarkerFaceColor', 'none');
h3 = plot(idx3, 3*ones(size(idx3)), '+', ...
    'Color', clr3, ...
    'LineWidth', 1.6, ...
    'MarkerSize', 7);
% 坐标轴范围
xlim([0 N]);
ylim([0.5 4]);

% 刻度
xticks(0:10:N);
yticks(1:5);

% 坐标轴标签
xlabel('k/step', ...
    'FontName','Times New Roman', ...
    'FontSize',18);
% 改成
% xlabel(ax6, '$\textrm{Step}(k)$', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14);

% 坐标轴风格
set(gca, ...
    'FontName','Times New Roman', ...
    'FontSize',16, ...
    'LineWidth',1.0, ...
    'Layer','top');


% 图例
legend([h1,h2,h3], ...
    {'node 1', 'node 2', 'node 3'}, ...
    'Interpreter','latex', ...
    'Orientation','horizontal', ...
    'Location','northwest', ...
    'NumColumns',3, ...
    'Box','on', ...
    'FontName','Times New Roman', ...
    'FontSize',13);

% 命令行显示触发率
disp('Triggering rates (%):');
for j = 1:3
    fprintf('Sensor %d: %.2f%%\n', j, trigger_rate(j));
end
%% 状态估计图
%% =========================
% 6 subplots:
% Row 1: sensor 1
% Row 2: sensor 2
% Row 3: sensor 3
% Col 1: x^(1) position
% Col 2: x^(2) velocity
%% =========================
t = 1:N;
figure('Color','w','Position',[80 60 1000 780]);
T = tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
clr_true   = [0.10 0.10 0.10];
clr_local  = [0.86 0.33 0.10];
clr_fusion = [0.00 0.45 0.74];

alpha_local  = 0.20;
alpha_fusion = 0.18;

%% ===== Row 1, Col 1 =====
ax1 = nexttile(1);
hold(ax1,'on'); box(ax1,'on');
set(ax1, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax1,'on');
ax1.GridColor = [0.85 0.85 0.85];
ax1.GridAlpha = 0.45;

h1_local = fill([t fliplr(t)], [c_1a_up(1,:) fliplr(c_1a_down(1,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_1a_up(1,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_1a_down(1,:), 'Color', clr_local, 'LineWidth', 1.2);

h1_fusion = fill([t fliplr(t)], [c_1f_up(1,:) fliplr(c_1f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_1f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_1f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h1_true = plot(t, x(1,:), 'Color', clr_true, 'LineWidth', 1.35);

title('$x^{(1)}$ position', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14, 'FontWeight','bold');
xlim([1 N]);
legend([h1_true, h1_local, h1_fusion], ...
    {'True state', 'LE 1', 'DZFE 1'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% ===== Row 1, Col 2 =====
ax2 = nexttile(2);
hold(ax2,'on'); box(ax2,'on');
set(ax2, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax2,'on');
ax2.GridColor = [0.85 0.85 0.85];
ax2.GridAlpha = 0.45;

h2_local = fill([t fliplr(t)], [c_1a_up(2,:) fliplr(c_1a_down(2,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_1a_up(2,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_1a_down(2,:), 'Color', clr_local, 'LineWidth', 1.2);

h2_fusion = fill([t fliplr(t)], [c_1f_up(2,:) fliplr(c_1f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_1f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_1f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h2_true = plot(t, x(2,:), 'Color', clr_true, 'LineWidth', 1.35);

title('$x^{(2)}$ velocity', 'Interpreter','latex', 'FontName','Times New Roman', 'FontSize',14, 'FontWeight','bold');
xlim([1 N]);
legend([h2_true, h2_local, h2_fusion], ...
    {'True state', 'LE 1', 'DZFE 1'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% ===== Row 2, Col 1 =====
ax3 = nexttile(3);
hold(ax3,'on'); box(ax3,'on');
set(ax3, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax3,'on');
ax3.GridColor = [0.85 0.85 0.85];
ax3.GridAlpha = 0.45;

h3_local = fill([t fliplr(t)], [c_2a_up(1,:) fliplr(c_2a_down(1,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_2a_up(1,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_2a_down(1,:), 'Color', clr_local, 'LineWidth', 1.2);

h3_fusion = fill([t fliplr(t)], [c_2f_up(1,:) fliplr(c_2f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_2f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_2f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h3_true = plot(t, x(1,:), 'Color', clr_true, 'LineWidth', 1.35);

xlim([1 N]);
legend([h3_true, h3_local, h3_fusion], ...
    {'True state', 'LE 2', 'DZFE 2'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% ===== Row 2, Col 2 =====
ax4 = nexttile(4);
hold(ax4,'on'); box(ax4,'on');
set(ax4, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax4,'on');
ax4.GridColor = [0.85 0.85 0.85];
ax4.GridAlpha = 0.45;

h4_local = fill([t fliplr(t)], [c_2a_up(2,:) fliplr(c_2a_down(2,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_2a_up(2,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_2a_down(2,:), 'Color', clr_local, 'LineWidth', 1.2);

h4_fusion = fill([t fliplr(t)], [c_2f_up(2,:) fliplr(c_2f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_2f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_2f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h4_true = plot(t, x(2,:), 'Color', clr_true, 'LineWidth', 1.35);

xlim([1 N]);
legend([h4_true, h4_local, h4_fusion], ...
    {'True state', 'LE 2', 'DZFE 2'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% ===== Row 3, Col 1 =====
ax5 = nexttile(5);
hold(ax5,'on'); box(ax5,'on');
set(ax5, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax5,'on');
ax5.GridColor = [0.85 0.85 0.85];
ax5.GridAlpha = 0.45;

h5_local = fill([t fliplr(t)], [c_3a_up(1,:) fliplr(c_3a_down(1,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_3a_up(1,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_3a_down(1,:), 'Color', clr_local, 'LineWidth', 1.2);

h5_fusion = fill([t fliplr(t)], [c_3f_up(1,:) fliplr(c_3f_down(1,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_3f_up(1,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_3f_down(1,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h5_true = plot(t, x(1,:), 'Color', clr_true, 'LineWidth', 1.35);

xlim([1 N]);
xlabel('Time instant $k$', 'Interpreter','latex', 'FontSize',13, 'FontName','Times New Roman');
legend([h5_true, h5_local, h5_fusion], ...
    {'True state', 'LE 3', 'DZFE 3'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% ===== Row 3, Col 2 =====
ax6 = nexttile(6);
hold(ax6,'on'); box(ax6,'on');
set(ax6, ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
grid(ax6,'on');
ax6.GridColor = [0.85 0.85 0.85];
ax6.GridAlpha = 0.45;

h6_local = fill([t fliplr(t)], [c_3a_up(2,:) fliplr(c_3a_down(2,:))], clr_local, ...
    'FaceAlpha', alpha_local, 'EdgeColor', 'none');
plot(t, c_3a_up(2,:),   'Color', clr_local, 'LineWidth', 1.2);
plot(t, c_3a_down(2,:), 'Color', clr_local, 'LineWidth', 1.2);

h6_fusion = fill([t fliplr(t)], [c_3f_up(2,:) fliplr(c_3f_down(2,:))], clr_fusion, ...
    'FaceAlpha', alpha_fusion, 'EdgeColor', 'none');
plot(t, c_3f_up(2,:),   '--', 'Color', clr_fusion, 'LineWidth', 1.2);
plot(t, c_3f_down(2,:), '--', 'Color', clr_fusion, 'LineWidth', 1.2);

h6_true = plot(t, x(2,:), 'Color', clr_true, 'LineWidth', 1.35);

xlim([1 N]);
xlabel('Time instant $k$', 'Interpreter','latex', 'FontSize',13, 'FontName','Times New Roman');
legend([h6_true, h6_local, h6_fusion], ...
    {'True state', 'LE 3', 'DZFE 3'}, ...
    'Interpreter','latex', 'Location','northwest', 'Box','off', 'FontSize',10);

%% 性能指标图
figure('Color','w','Position',[140 80 760 760]);
TL = tiledlayout(3,1,'TileSpacing','compact','Padding','compact');
% 高级一点的配色
clr_local  = [0.18 0.18 0.18];   % graphite gray
clr_fusion = [0.00 0.38 0.70];   % deep academic blue
%% ---- Subplot 1
ax1 = nexttile;
hold(ax1,'on'); box(ax1,'on'); grid(ax1,'on');

plot(1:N, J_1a(1,:), ...
    'Color', clr_local, ...
    'LineWidth', 1.6);

plot(1:N, J_1f(1,:), '--', ...
    'Color', clr_fusion, ...
    'LineWidth', 1.8);
set(ax1, ...
    'FontName','Times New Roman', ...
    'FontSize',13, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
ax1.GridColor = [0.85 0.85 0.85];
ax1.GridAlpha = 0.30;
ylabel('$AR_{2}(k)$', ...
    'Interpreter','latex', ...
    'FontName','Times New Roman', ...
    'FontSize',13);
legend({'LE1','DZFE1'}, ...
    'Location','northeast', ...
    'Box','off', ...
    'FontName','Times New Roman', ...
    'FontSize',11);
xlim([1 N]);
%% ---- Subplot 2
ax2 = nexttile;
hold(ax2,'on'); box(ax2,'on'); grid(ax2,'on');
plot(1:N, J_2a(1,:), ...
    'Color', clr_local, ...
    'LineWidth', 1.6);

plot(1:N, J_2f(1,:), '--', ...
    'Color', clr_fusion, ...
    'LineWidth', 1.8);
set(ax2, ...
    'FontName','Times New Roman', ...
    'FontSize',13, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
ax2.GridColor = [0.85 0.85 0.85];
ax2.GridAlpha = 0.30;
ylabel('$AR_{2}(k)$', ...
    'Interpreter','latex', ...
    'FontName','Times New Roman', ...
    'FontSize',13);
legend({'LE2','DZFE2'}, ...
    'Location','northeast', ...
    'Box','off', ...
    'FontName','Times New Roman', ...
    'FontSize',11);
xlim([1 N]);
%% ---- Subplot 3
ax3 = nexttile;
hold(ax3,'on'); box(ax3,'on'); grid(ax3,'on');
plot(1:N, J_3a(1,:), ...
    'Color', clr_local, ...
    'LineWidth', 1.6);
plot(1:N, J_3f(1,:), '--', ...
    'Color', clr_fusion, ...
    'LineWidth', 1.8);
set(ax3, ...
    'FontName','Times New Roman', ...
    'FontSize',13, ...
    'LineWidth',0.9, ...
    'XColor',[0.15 0.15 0.15], ...
    'YColor',[0.15 0.15 0.15], ...
    'Layer','top');
ax3.GridColor = [0.85 0.85 0.85];
ax3.GridAlpha = 0.30;
ylabel('$AR_{2}(k)$', ...
    'Interpreter','latex', ...
    'FontName','Times New Roman', ...
    'FontSize',13);
xlabel('Time instant $k$', ...
    'Interpreter','latex', ...
    'FontName','Times New Roman', ...
    'FontSize',14);
legend({'LR3','DZFE3'}, ...
    'Location','northeast', ...
    'Box','off', ...
    'FontName','Times New Roman', ...
    'FontSize',11);
xlim([1 N]);
%% 状态估计图 论文里面的
plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_1a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_1a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_1f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_1f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置

plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_1a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_1a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_1f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_1f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度

plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_2a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_2a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_2f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_2f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置


plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_2a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_2a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_2f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_2f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度


plot(1:N,  x(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_3a_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3a_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3f_up(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_3f_down(1, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是位置


plot(1:N,  x(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  c_3a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N,  c_3f_up(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  c_3f_down(2, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
% 这个是速度






%% 性能指标图
% 第一个子图
plot(1:N,  J_1a(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  J_1f(1, :), 'r--', 'LineWidth', 1.5);
legend('局部估计','融合估计');
% 第二个子图
plot(1:N,  J_2a(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  J_2f(1, :), 'r--', 'LineWidth', 1.5);
legend('局部估计','融合估计');
% 第三个子图
plot(1:N,  J_3a(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  J_3f(1, :), 'r--', 'LineWidth', 1.5);
legend('局部估计','融合估计');

















%% ============================================================
%    绘制前三个节点的融合结果
%    三张单独图，只画前25个时刻
%    去掉网格线
tspan = 1:N;

C_a = {c_1a, c_2a, c_3a};
R_a = {R_1a, R_2a, R_3a};

C_f = {c_1f, c_2f, c_3f};
R_f = {R_1f, R_2f, R_3f};

node_name = {'Node 1','Node 2','Node 3'};

upper_f_NU = zeros(2,N,3);
lower_f_NU = zeros(2,N,3);

for i = 1:3
    for t = 1:N
        c_now_f = C_f{i}{1,t};
        R_now_f = R_f{i}{1,t};
        rad_now_f = sum(abs(R_now_f),2);

        upper_f_NU(:,t,i) = c_now_f + rad_now_f;
        lower_f_NU(:,t,i) = c_now_f - rad_now_f;
    end
end

% Make NU fused results available to EPSO.m after running this script.
assignin('base','C_f',C_f);
assignin('base','R_f',R_f);
assignin('base','upper_f_NU',upper_f_NU);
assignin('base','lower_f_NU',lower_f_NU);


%% ============================================================
% 比较 Z_ia 和 Z_if 在 x_1 上的上下界
tspan = 1:N;

% 各节点的局部后验和融合结果
C_a = {c_1a, c_2a, c_3a};
R_a = {R_1a, R_2a, R_3a};

C_f = {c_1f, c_2f, c_3f};
R_f = {R_1f, R_2f, R_3f};

node_name = {'Node 1','Node 2','Node 3'};

% 配色
color_x = [0.05 0.05 0.05];   % 黑色：真实值
color_a = [1.00 0.00 0.00];   % 红色：局部估计
color_f = [0.00 0.00 1.00];   % 蓝色：融合估计

figure('Color','w','Position',[100 80 900 760]);
tiledlayout(3,1,'TileSpacing','compact','Padding','compact');

for i = 1:3

    % 预分配
    x2_a_up   = zeros(1,N);
    x2_a_down = zeros(1,N);
    x2_f_up   = zeros(1,N);
    x2_f_down = zeros(1,N);

    % 计算上下界
    for t = 1:N

        % 局部估计 Z_ia
        c_now_a = C_a{i}{1,t};
        R_now_a = R_a{i}{1,t};
        P_now_a = sum(abs(R_now_a),2);

        x2_a_up(t)   = c_now_a(2) + P_now_a(2);
        x2_a_down(t) = c_now_a(2) - P_now_a(2);

        % 融合估计 Z_if
        c_now_f = C_f{i}{1,t};
        R_now_f = R_f{i}{1,t};
        P_now_f = sum(abs(R_now_f),2);

        x2_f_up(t)   = c_now_f(2) + P_now_f(2);
        x2_f_down(t) = c_now_f(2) - P_now_f(2);
    end

    nexttile;
    hold on; box on; grid on;

    % 真实值
    h1 = plot(tspan, x(2,:), 'k', 'LineWidth', 1.8);

    % 局部估计上下界（红色实线）
    h2 = plot(tspan, x2_a_up, '-', ...
        'Color', color_a, ...
        'LineWidth', 1.6);
    plot(tspan, x2_a_down, '-', ...
        'Color', color_a, ...
        'LineWidth', 1.6, ...
        'HandleVisibility','off');

    % 融合估计上下界（蓝色虚线）
    h3 = plot(tspan, x2_f_up, '--', ...
        'Color', color_f, ...
        'LineWidth', 1.8);
    plot(tspan, x2_f_down, '--', ...
        'Color', color_f, ...
        'LineWidth', 1.8, ...
        'HandleVisibility','off');

    xlim([1 N]);

    xlabel('Step (k)', 'FontName','Times New Roman', 'FontSize',13);
    ylabel('$x_2$', 'Interpreter','latex', 'FontSize',13);

    title([node_name{i}, ': comparison on $x_2$'], ...
        'Interpreter','latex', ...
        'FontName','Times New Roman', ...
        'FontSize',13);

    legend([h1,h2,h3], ...
        {'true state', 'local estimate', 'fusion estimate'}, ...
        'Interpreter','latex', ...
        'Location','northwest', ...
        'Orientation','horizontal', ...
        'Box','on', ...
        'FontSize',10);

    set(gca, ...
        'FontName','Times New Roman', ...
        'FontSize',11, ...
        'LineWidth',0.9, ...
        'GridAlpha',0.18);
end
%% Plot only true state and fused NU bounds.
figure('Color','w','Position',[100 70 980 760]);
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');

for i = 1:3
    nexttile; hold on; box on; grid on;

    h1 = plot(tspan, x(1,:), 'k-', 'LineWidth', 1.8);
    h2 = plot(tspan, squeeze(upper_f_NU(1,:,i)), 'b--', 'LineWidth', 1.7);
    plot(tspan, squeeze(lower_f_NU(1,:,i)), 'b--', ...
        'LineWidth', 1.7, 'HandleVisibility','off');

    xlim([1 N]);
    xlabel('Step $(k)$', 'Interpreter','latex');
    ylabel('$x_1$', 'Interpreter','latex');
    title([node_name{i}, ': fused NU bounds of $x_1$'], 'Interpreter','latex');
    legend([h1,h2], {'true state', 'fusion bounds'}, ...
        'Interpreter','latex', 'Location','northwest', 'Box','on');

    set(gca, 'FontName','Times New Roman', 'FontSize',12, ...
        'LineWidth',1.0, 'GridAlpha',0.18);

    nexttile; hold on; box on; grid on;

    h1 = plot(tspan, x(2,:), 'k-', 'LineWidth', 1.8);
    h2 = plot(tspan, squeeze(upper_f_NU(2,:,i)), 'b--', 'LineWidth', 1.7);
    plot(tspan, squeeze(lower_f_NU(2,:,i)), 'b--', ...
        'LineWidth', 1.7, 'HandleVisibility','off');

    xlim([1 N]);
    xlabel('Step $(k)$', 'Interpreter','latex');
    ylabel('$x_2$', 'Interpreter','latex');
    title([node_name{i}, ': fused NU bounds of $x_2$'], 'Interpreter','latex');
    legend([h1,h2], {'true state', 'fusion bounds'}, ...
        'Interpreter','latex', 'Location','northwest', 'Box','on');

    set(gca, 'FontName','Times New Roman', 'FontSize',12, ...
        'LineWidth',1.0, 'GridAlpha',0.18);
end

%%
tspan = 1:N;

Ja = {J_1a, J_2a, J_3a};
Jf = {J_1f, J_2f, J_3f};

clr_a = [0.12 0.47 0.71];  
clr_f = [0.84 0.29 0.20];   

figure('Color','w','Position',[120 80 900 720]);

tiledlayout(3,1,'TileSpacing','compact','Padding','compact');

for i = 1:3

    nexttile;

    plot(tspan, Ja{i}, '-', ...
        'Color', clr_a, ...
        'LineWidth', 1.8);
    hold on;

    plot(tspan, Jf{i}, '--', ...
        'Color', clr_f, ...
        'LineWidth', 1.8);

    grid on;
    box on;

    set(gca, ...
        'FontName','Times New Roman', ...
        'FontSize',11, ...
        'LineWidth',0.9, ...
        'GridAlpha',0.18);

    xlabel('$t$/step','Interpreter','latex','FontSize',12);
    ylabel('$J$','Interpreter','latex','FontSize',12);

    title(['Node ', num2str(i)], ...
        'Interpreter','latex', ...
        'FontSize',13);

    legend({sprintf('$J_{%d,a}$ before fusion',i), ...
            sprintf('$J_{%d,f}$ after fusion',i)}, ...
        'Interpreter','latex', ...
        'Location','northeast', ...
        'Box','off', ...
        'FontSize',10);
end


sum(J_1a)/N; sum(J_1f)/N;
sum(J_2a)/N; sum(J_2f)/N;
sum(J_3a)/N; sum(J_3a)/N;


