function Ve = MU_ZV(varargin)
%% ============================================================
% 输入：
%   c1,R1,c2,R2,...
%
% 输出：
%   Ve : 公共交集顶点，每一行是一个顶点
%
% 说明：
%   二维 zonotope 专用，R 可以是 2×m
%% ============================================================

%% 1. 检查输入
if mod(nargin,2) ~= 0
    error('输入必须成对出现：c1,R1,c2,R2,...');
end

numZ = nargin/2;

if numZ < 2
    error('至少需要输入两个 zonotope。');
end

tol = 1e-6;

A_all = [];
b_all = [];

%% 2. 每个二维 zonotope 直接转 H 表达式
for i = 1:numZ

    c = varargin{2*i-1};
    R = varargin{2*i};

    c = c(:);

    if length(c) ~= 2
        error('该 MU_ZV 版本只适用于二维 zonotope。');
    end

    if size(R,1) ~= 2
        error('第 %d 个 zonotope 的生成矩阵必须为 2×m。',i);
    end

    m = size(R,2);

    Ai = [];
    bi = [];

    for j = 1:m

        rj = R(:,j);

        if norm(rj) < tol
            continue;
        end

        % 与生成向量垂直的法向量
        h = [-rj(2); rj(1)];

        if norm(h) < tol
            continue;
        end

        h = h / norm(h);

        % 支撑函数
        beta = sum(abs(h' * R));

        Ai = [Ai;
              h';
             -h'];

        bi = [bi;
              h' * c + beta;
             -h' * c + beta];
    end
    A_all = [A_all; Ai];
    b_all = [b_all; bi];
end
%% 3. 构造公共交集区域
% 加一个很小的数值容差，避免边界点被误判为空
Fusion = Polyhedron('A', A_all, 'b', b_all + tol);
Fusion.minHRep();
%% 4. 判断交集是否为空
if Fusion.isEmptySet()
    error('MU_ZV:EmptyIntersection', ...
          '输入的多个 zonotope 交集为空，无法计算公共区域顶点。');
end
%% 5. 计算 V 表达式
Fusion.computeVRep();

Ve = Fusion.V;

if isempty(Ve)
    error('MU_ZV:NoVertices', ...
          '交集区域没有有效顶点。可能交集为空、退化，或 H/V 表达式转换失败。');
end
%% 6. 去重
Ve = unique(round(Ve*1e10)/1e10,'rows');
end






















% function Ve = MU_ZV(varargin)
% %% ============================================================
% % 输入：
% %   c1,R1,c2,R2,...
% %
% % 输出：
% %   Ve : 公共交集顶点，每一行是一个顶点
% %% ============================================================
% %% 1. 检查输入
% if mod(nargin,2) ~= 0
%     error('输入必须成对出现：c1,R1,c2,R2,...');
% end
% 
% numZ = nargin/2;
% 
% if numZ < 2
%     error('至少需要输入两个 zonotope。');
% end
% 
% %% 2. 初始化 H 表达式
% A_all = [];
% b_all = [];
% 
% %% 3. 每个 zonotope 转 H 表达式
% for i = 1:numZ
% 
%     c = varargin{2*i-1};
%     R = varargin{2*i};
% 
%     c = c(:);
%     n = length(c);
% 
%     if size(R,1) ~= n
%         error('第 %d 个 zonotope 的生成矩阵行数与中心维度不一致。',i);
%     end
% 
%     %% 情况 1：R 是 n×n 且满秩
%     if size(R,2) == n && rank(R) == n
% 
%         L = R \ eye(n);
% 
%         Ai = [ L;
%               -L];
% 
%         bi = [ ones(n,1) + L*c;
%                ones(n,1) - L*c];
% 
%     else
%         %% 情况 2：一般 zonotope，先转顶点，再转 H 表达式
%         Zi = zonotope(c,R);
%         Vi = vertices(Zi);
% 
%         if size(Vi,1) == n
%             Vi = Vi';
%         end
% 
%         if size(Vi,2) ~= n
%             error('第 %d 个 zonotope 的顶点维度不正确。',i);
%         end
% 
%         Vi = unique(round(Vi*1e10)/1e10,'rows');
% 
%         Pi = Polyhedron('V',Vi);
% 
%         if Pi.isEmptySet()
%             error('第 %d 个 zonotope 转成 Polyhedron 后为空。',i);
%         end
% 
%         Pi.computeHRep();
% 
%         Ai = Pi.A;
%         bi = Pi.b(:);
%     end
% 
%     A_all = [A_all; Ai];
%     b_all = [b_all; bi];
% 
% end
% 
% %% 4. 构造公共交集区域
% Fusion = Polyhedron('A',A_all,'b',b_all);
% 
% %% 5. 判断交集是否为空
% if Fusion.isEmptySet()
%     error('MU_ZV:EmptyIntersection', ...
%           '输入的多个 zonotope 交集为空，无法计算公共区域顶点。');
% end
% 
% %% 6. 计算 V 表达式
% Fusion.computeVRep();
% 
% Ve = Fusion.V;
% 
% %% 7. 检查顶点
% if isempty(Ve)
%     error('MU_ZV:NoVertices', ...
%           '交集区域没有有效顶点。可能交集为空、退化，或 H/V 表达式转换失败。');
% end
% 
% %% 8. 去重
% Ve = unique(round(Ve*1e10)/1e10,'rows');
% 
% end