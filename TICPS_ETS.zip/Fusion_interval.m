function [c_f, R_f, J_f] = Fusion_interval(varargin)
%% ============================================================
% Fusion_interval
%
% 输入：
%   c1,R1,c2,R2,...,cL,RL
%
% 输出：
%   c_f : 融合中心
%   R_f : 融合生成矩阵
%   J_f : 融合性能指标
%% ============================================================

%% 1. 检查输入
if mod(nargin,2) ~= 0
    error('输入必须成对出现：c1,R1,c2,R2,...');
end

L = nargin/2;

if L < 2
    error('至少需要输入两个 zonotope。');
end

%% 2. 读取第一个 zonotope
c1 = varargin{1};
R1 = varargin{2};

c1 = c1(:);
n = length(c1);

if size(R1,1) ~= n
    error('第 1 个 zonotope 的生成矩阵行数与中心维度不一致。');
end

%% 3. 读取所有中心和生成矩阵
c_cell = cell(1,L);
R_cell = cell(1,L);
r_list = zeros(1,L);

for i = 1:L

    c_i = varargin{2*i-1};
    R_i = varargin{2*i};

    c_i = c_i(:);

    if length(c_i) ~= n
        error('第 %d 个 zonotope 的中心维度与第 1 个不一致。',i);
    end

    if size(R_i,1) ~= n
        error('第 %d 个 zonotope 的生成矩阵行数与中心维度不一致。',i);
    end

    c_cell{i} = c_i;
    R_cell{i} = R_i;
    r_list(i) = size(R_i,2);

end

%% 4. 构造 N1 = [R1, 0, ..., 0]
total_r = sum(r_list);

N1 = zeros(n,total_r);
N1(:,1:r_list(1)) = R_cell{1};

%% 5. 构造 N2
N2 = zeros((L-1)*n,total_r);

col_pos = zeros(L,2);
col_start = 1;

for i = 1:L
    col_end = col_start + r_list(i) - 1;
    col_pos(i,:) = [col_start, col_end];
    col_start = col_end + 1;
end

for j = 1:L-1

    idx = j + 1;

    row_start = (j-1)*n + 1;
    row_end   = j*n;

    % 放入 -R1
    N2(row_start:row_end, col_pos(1,1):col_pos(1,2)) = -R_cell{1};

    % 放入 R_idx
    N2(row_start:row_end, col_pos(idx,1):col_pos(idx,2)) = R_cell{idx};

end

%% 6. 构造中心差项 dc = col{c2-c1, c3-c1, ..., cL-c1}
dc = zeros((L-1)*n,1);

for j = 1:L-1

    idx = j + 1;

    row_start = (j-1)*n + 1;
    row_end   = j*n;

    dc(row_start:row_end) = c_cell{idx} - c_cell{1};

end

%% 7. 求解融合矩阵 M
M_opt = zeros(n,(L-1)*n);

col_N1 = size(N1,2);

options = sdpsettings('solver','sedumi', ...
    'verbose',0, ...
    'sedumi.eps',1e-7, ...
    'sedumi.maxiter',500);

for row = 1:n

    lambda_i = sdpvar(col_N1,1);
    M_i = sdpvar(1,(L-1)*n);

    Constraints = [
        N1(row,:)' + N2'*M_i' >= -lambda_i, ...
        N1(row,:)' + N2'*M_i' <=  lambda_i, ...
        lambda_i >= 0
    ];

    Objective = sum(lambda_i);

    result = optimize(Constraints,Objective,options);

    if result.problem == 0
        M_opt(row,:) = value(M_i);
    else
        error('Fusion_interval:OptimizationFailed', ...
              '第 %d 行融合矩阵求解失败：%s', row, result.info);
    end

end
M = M_opt;
%% 8. 构造融合中心和融合生成矩阵
c_f = c1 + M*dc;
R_f = N1 + M*N2;
J_f = Volume_Interval(R_f);

end