%% nonlinear_robot  
clear;
clc;
N=100;
%% model parameter