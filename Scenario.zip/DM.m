%% 求非线性展开带来的确定性矩阵M
%% 非线性函数在这里面是已知的，当换模型的时候需要换相应的参数 
function [DM_Y] = DM(c,x)
% sx_estimate = c(1);  sx_true = x(1);
% vx_estimate = c(2);  vx_true = x(2);
% sy_estimate = c(3);  sy_true = x(3);
% vy_estimate = c(4);  vy_true = x(4);
%%
F1=0.03;F2=0.02;F3=0.01;F4=0.03;
y=x-c;
m=norm(y,inf);
DM_Y=m*diag([F1,F2,F3,F4]);
%% 非线性的二阶矩阵
% F_1=[-0.02*sin(sx),0,0,0;
%      0,0.03*cos(vx)*sin(vy),0,0.03*sin(vx)*cos(vy);
%      0,0,0,0;
%      0,0.03*sin(vx)*cos(vy),0,0.03*cos(vx)*sin(vy)];
% F_2=[0,0,0,0;
%      0,-0.02*sin(vx)*cos(vy),0,-0.02*cos(vx)*sin(vy);
%      0,0,0,0;
%      0,-0.02*cos(vx)*sin(vy),0,-0.02*sin(vx)*cos(vy)];
% F_3=[0,0,0,0;
%      0,-0.01*sin(vx)*cos(vy),0,-0.01*cos(vx)*sin(vy);
%      0, 0, -0.03*sin(sy),0;
%      0,-0.01*cos(vx)*sin(vy),0,-0.01*sin(vx)*cos(vy)]; 
% F_4=[0,          0,          0,          0;
%      0, 0.03*cos(vx)*sin(vy), 0, 0.03*sin(vx)*cos(vy);
%      0,          0,          0,          0;
%      0, 0.03*sin(vx)*cos(vy), 0, 0.03*cos(vx)*sin(vy)];  
end