%无攻击下局部估计
function [K, P] = solve_LMI_K(A, B, C, Bi)
setlmis([]);
% 变量定义
K_var=lmivar(2,[2 1]);
P_var = lmivar(1, [2 1]) ; 
TT=lmivar (1, [1 1]);
MM=lmivar (1, [1 1]);
T = lmivar(1, [1 1]); 
V = lmivar(1, [1 1]);  
% 构建LMI约束
I = eye(2);
% 第一约束
lmiterm( [7 1 1 0],-1);
lmiterm( [7 1 2 0],A);
lmiterm( [7 1 2 K_var],-1,C*A);
lmiterm( [7 1 3 0],B);
lmiterm( [7 1 3 K_var],-1,C*B);
lmiterm( [7 1 4 K_var],-1,Bi);
lmiterm( [7 2 2 P_var],-1,1);
lmiterm( [7 2 3 0],0);
lmiterm( [7 2 4 0],0);
lmiterm( [7 3 3 T],-1,1);
lmiterm( [7 3 4 TT],-1,1);
lmiterm( [7 4 4 MM],-1,1);
lmiterm([-1 1 1 T], 1, 1); 
lmiterm([-2 1 1 P_var], 1, 1); 
lmiterm([-3 1 1 V], 1, 1); 
lmiterm([-4 1 1 V], -1, 1); 
lmiterm([-4 1 1 0], 1); 
lmiterm([-5 1 1 P_var], -1, 1); 
lmiterm([-5 1 1 V], 1, eye(2)); 
lmiterm([-6 1 1 MM], 1, 1); 
lmis = getlmis;
n=decnbr(lmis);
c1=zeros(1,n);
for q=1:n
[T1]=defcx(lmis,q,T);
[M1]=defcx(lmis,q,MM);
c1(q)=trace(T1)+trace(M1);
end
options=[1e-4,100,0,0,0];
[copt,xopt] = mincx(lmis,c1,options);