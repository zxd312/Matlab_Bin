function fk = compute_fk(xk)
    % 输入 xk 是 4×1 列向量，格式为 [s_x(k); v_x(k); s_y(k); v_y(k)]
    % 输出 fk 是 4×1 列向量，对应题目中的 f(k)
    % 1. 从输入向量中提取各个分量
    sx = xk(1);
    vx = xk(2);
    sy = xk(3);
    vy = xk(4);
    % 2. 计算 f(k) 的每个分量
    f1 = 0.02 * sin(sx) - 0.03 * cos(vx) * sin(vy);
    f2 = 0.02 * sin(vx) * cos(vy);
    f3 = 0.03 * sin(sy) + 0.01 * sin(vx) * cos(vy);
    f4 = -0.03 * cos(vx) * sin(vy);
    % 3. 组合成输出列向量
    fk = [f1; f2; f3; f4];
end