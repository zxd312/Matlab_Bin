%% linear scenario + mincx
clc;
clear;
N=100;
%% 系统参数
C_1=[0.5,1];
C_2=[1,0];
% 生成不确定性
U_a=0.1*rand(2,2)-0.05;
U_c1=0.04*rand(1,2)-0.02;
U_c2=0.08*rand(1,2)-0.04;
% 生成系统矩阵和噪声
for t=1:N
    f=0.5+sin(t);    
    A{1,t}=[1,f;0,1];
    B{1,t}=[0.5*f*f;f];
    w(:,t)=(2+0.2*cos(t))*exp(-(t)/9);
    v1(:,t)=0.8*sin(t)*exp(-(t)/6);
    v2(:,t)=1.1*sin(t)*exp(-(t)/9);
end
%% 生成真实状态和量测
x(:,1)=[0.1;0.1]; y_1(:,1)=C_1*x(:,1); y_2(:,1)=C_2*x(:,1);
x_1a=[0.1;0.1];  x_1e=[0.1;0.1];
x_2a=[0.1;0.1];  x_2e=[0.1;0.1];
for t=2:N
    x(:,t)=(A{1,t-1}+U_a)*x(:,t-1)+B{1,t-1}*w(:,t-1);
    y_1(:,t)=(C_1+U_c1)*x(:,t-1)+v1(:,t-1);
    y_2(:,t)=(C_2+U_c2)*x(:,t-1)+v2(:,t-1);
end
%% 求解增益矩阵之前，首先先进行采样
for t=1:132
    Deta_a{1,t}=0.1*rand(2,2)-0.05;
    Deta_c1{1,t}=0.04*rand(1,2)-0.02;  
    Deta_c2{1,t}=0.08*rand(1,2)-0.04;
end
%% 估计器设计 (使用 MATLAB LMI 工具箱)
for t=2:N
    x_1e(:,t)=A{1,t-1}*x_1a(:,t-1);
    setlmis([]); % 初始化 LMI 系统
    K1_var = lmivar(2, [2 1]); 
    Theta1_var = lmivar(1, [2 1]); 
    X1_var = lmivar(1, [2 1]); 
    zeta1_var = lmivar(1, [1 1]); 
    % --- 定义约束 ---
    % 约束 1: 针对每个场景 i 的大矩阵不等式 Q1{i} < 0
    % 矩阵结构:
    % [ -I             (I-KC)A          B_t1 ]
    % [ * -Theta           0    ]
    % [ * * -X   ]
    for i=1:132
        % 获取当前场景参数
        A_curr = A{1,t-1} + Deta_a{1,i};
        C_curr = C_1 + Deta_c1{1,i};
        B_sys_curr = B{1,t-1};
        lmi_idx = newlmi; 
        % Block (1,1): -I
        lmiterm([lmi_idx, 1, 1, 0], -eye(2));
        % Block (1,2): (I - K1*C_curr)*A_curr = A_curr - K1*(C_curr*A_curr)
        % 常数项 A_curr
        lmiterm([lmi_idx, 1, 2, 0], A_curr); 
        % 变量项 -K1 * (C_curr*A_curr) -> L*K*R -> -1 * K1 * (CA)
        lmiterm([lmi_idx, 1, 2, K1_var], -1, C_curr*A_curr);
        % Block (1,3): B_t1 = [(I - K1*C_curr)*B_sys, -K1]
        %                = [B_sys - K1*C_curr*B_sys, -K1]
        %                = [B_sys, 0] - K1 * [C_curr*B_sys, 1] (注意 -K1 = -K1*1)
        % 常数项 [B_sys, 0]
        lmiterm([lmi_idx, 1, 3, 0], [B_sys_curr, zeros(2,1)]); 
        % 变量项 -K1 * [C*B, 1]
        lmiterm([lmi_idx, 1, 3, K1_var], -1, [C_curr*B_sys_curr, 1]);
        % Block (2,2): -Theta1
        lmiterm([lmi_idx, 2, 2, Theta1_var], -1, 1);
        % Block (3,3): -X1
        lmiterm([lmi_idx, 3, 3, X1_var], -1, 1);
        % 注意：LMI 工具箱会自动处理对称位置，所以不需要定义 (2,1), (3,1) 等
    end
    % 约束 2: Theta1 - zeta1 * I <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, Theta1_var], 1, 1);       % Theta1
    lmiterm([lmi_idx, 1, 1, zeta1_var], -1, eye(2));  % -zeta1 * I
    % 约束 3: zeta1 <= 1  =>  zeta1 - 1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, zeta1_var], 1, 1);
    lmiterm([lmi_idx, 1, 1, 0], -1);
    % 约束 4: Theta1 >= 0 => -Theta1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, Theta1_var], -1, 1);
    % 约束 5: X1 >= 0 => -X1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, X1_var], -1, 1);
    % 约束 6: zeta1 >= 0 => -zeta1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, zeta1_var], -1, 1);
    % --- 获取 LMI 系统描述 ---
    lmisys = getlmis;
    n=decnbr(lmisys);
    c1=zeros(1,n);
    for q=1:n
    [X1]=defcx(lmisys,q,X1_var);
    c1(q)=trace(X1);
    end
    options=[1e-2,1000,0,0,0];
    [copt,xopt] = mincx(lmisys,c1,options);
    % --- 提取结果 ---
    if ~isempty(xopt)
        % disp(['Time ' num2str(t) ' solved success.']);
        K1_val = dec2mat(lmisys, xopt, K1_var);
        % 根据增益矩阵进行更新
        x_1a(:, t) = x_1e(:, t) + K1_val * (y_1(:, t) - C_1 * x_1e(:, t));
    else
        disp(['Time ' num2str(t) ' Failed! Using prediction only.']);
        error(['时刻 t=' num2str(t) ' LMI求解失败，日志已保存至 LMI_solve_error.log']);
    end
end

%% 估计器设计2 (使用 MATLAB LMI 工具箱)
for t=2:N
    x_2e(:,t)=A{1,t-1}*x_2a(:,t-1);
    setlmis([]); % 初始化 LMI 系统
    K2_var = lmivar(2, [2 1]); 
    Theta2_var = lmivar(1, [2 1]); 
    X2_var = lmivar(1, [2 1]); 
    zeta2_var = lmivar(1, [1 1]); 
    % --- 定义约束 ---
    % 约束 1: 针对每个场景 i 的大矩阵不等式 Q1{i} < 0
    % 矩阵结构:
    % [ -I             (I-KC)A          B_t1 ]
    % [ * -Theta           0    ]
    % [ * * -X   ]
    for i=2:132
        % 获取当前场景参数
        A_curr = A{1,t-1} + Deta_a{1,i};
        C_curr = C_2 + Deta_c2{1,i};
        B_sys_curr = B{1,t-1};
        lmi_idx = newlmi; 
        % Block (1,1): -I
        lmiterm([lmi_idx, 1, 1, 0], -eye(2));
        % Block (1,2): (I - K1*C_curr)*A_curr = A_curr - K1*(C_curr*A_curr)
        % 常数项 A_curr
        lmiterm([lmi_idx, 1, 2, 0], A_curr); 
        % 变量项 -K1 * (C_curr*A_curr) -> L*K*R -> -1 * K1 * (CA)
        lmiterm([lmi_idx, 1, 2, K2_var], -1, C_curr*A_curr);
        % Block (1,3): B_t1 = [(I - K1*C_curr)*B_sys, -K1]
        %                = [B_sys - K1*C_curr*B_sys, -K1]
        %                = [B_sys, 0] - K1 * [C_curr*B_sys, 1] (注意 -K1 = -K1*1)
        % 常数项 [B_sys, 0]
        lmiterm([lmi_idx, 1, 3, 0], [B_sys_curr, zeros(2,1)]); 
        % 变量项 -K1 * [C*B, 1]
        lmiterm([lmi_idx, 1, 3, K2_var], -1, [C_curr*B_sys_curr, 1]);
        % Block (2,2): -Theta1
        lmiterm([lmi_idx, 2, 2, Theta2_var], -1, 1);
        % Block (3,3): -X1
        lmiterm([lmi_idx, 3, 3, X2_var], -1, 1);
        % 注意：LMI 工具箱会自动处理对称位置，所以不需要定义 (2,1), (3,1) 等
    end
    % 约束 2: Theta1 - zeta1 * I <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, Theta2_var], 1, 1);       % Theta1
    lmiterm([lmi_idx, 1, 1, zeta2_var], -1, eye(2));  % -zeta1 * I
    % 约束 3: zeta1 <= 1  =>  zeta1 - 1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, zeta2_var], 1, 1);
    lmiterm([lmi_idx, 1, 1, 0], -1);
    % 约束 4: Theta1 >= 0 => -Theta1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, Theta2_var], -1, 1);
    % 约束 5: X1 >= 0 => -X1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, X2_var], -1, 1);
    % 约束 6: zeta1 >= 0 => -zeta1 <= 0
    lmi_idx = newlmi;
    lmiterm([lmi_idx, 1, 1, zeta2_var], -1, 1);
    % --- 获取 LMI 系统描述 ---
    lmisys = getlmis;
    n=decnbr(lmisys);
    c2=zeros(1,n);
    for q=1:n
    [X2]=defcx(lmisys,q,X2_var);
    c2(q)=trace(X2);
    end
    options=[1e-4,100,0,0,0];
    [copt,xopt] = mincx(lmisys,c2,options);
    % --- 提取结果 ---
    if ~isempty(xopt)
        % disp(['Time ' num2str(t) ' solved success.']);
        K2_val = dec2mat(lmisys, xopt, K2_var);
        % 根据增益矩阵进行更新
        x_2a(:, t) = x_2e(:, t) + K2_val * (y_2(:, t) - C_2 * x_2e(:, t));
    else
        disp(['Time ' num2str(t) ' Failed! Using prediction only.']);
        x_2a(:, t) = x_2e(:, t); % 求解失败时的保底策略
    end
end

%% 融合中心进行融合处理
for t=2:N


end






















%% 简单绘图验证结果
figure;
subplot(2,1,1);
plot(1:N, x(1,:), 'k-', 'LineWidth', 1.5); hold on;
%plot(1:N, x_1a(1,:), 'r--', 'LineWidth', 1.5);
legend('True State 1', 'Estimated State 1');
title('State 1 Estimation'); grid on;

subplot(2,1,2);
plot(1:N, x(2,:), 'k-', 'LineWidth', 1.5); hold on;
plot(1:N, x_1a(2,:), 'r--', 'LineWidth', 1.5);
legend('True State 2', 'Estimated State 2');
title('State 2 Estimation'); grid on;






