%% linear scenario
clc;
clear;
N=100;
%% 系统参数
C_1=[0.5,1];
C_2=[1,0];
% 生成不确定性
for t=1:N
U_a{1,t}=rand(2,2)-0.5;
U_c1{1,t}=0.2*rand(1,2)-0.1;
U_c2{1,t}=0.4*rand(1,2)-0.2;
end
% 生成系统矩阵和噪声
for t=1:N
f=0.5+sin(t-1);    
A{1,t}=[1,f;0,1];
B{1,t}=[0.5*f*f;f];
w(:,t)=(2+0.2*cos(t-1))*exp(-(t-1)/9);
v1(:,t)=0.8*sin(t-1)*exp(-(t-1)/6);
v2(:,t)=1.1*sin(t-1)*exp(-(t-1)/9);
end
%% 生成真实状态和量测
x(:,1)=[0.1;0.1]; y_1(:,1)=C_1*x(:,1); y_2(:,1)=C_2*x(:,1);
x_1a=[0.1;0.1];  x_1e=[0.1;0.1];
x_2a=[0.1;0.1];  x_2e=[0.1;0.1];
for t=2:N
x(:,t)=(A{1,t-1}+U_a{1,t-1})*x(:,t-1)+B{1,t-1}*w(:,t-1);
y_1(:,t)=(C_1+U_c1{1,t-1})*x(:,t-1)+v1(:,t-1);
y_2(:,t)=(C_2+U_c2{1,t-1})*x(:,t-1)+v2(:,t-1);
end
%% 求解增益矩阵之前，首先先进行采样，直接先弄，最后才弄
for t=1:152
Deta_a{1,t}=rand(2,2)-0.5;
Deta_c1{1,t}=0.2*rand(1,2)-0.1;  
Deta_c2{1,t}=0.4*rand(1,2)-0.2;
end
%% 估计器设计 1 
for t=2:N
x_1e(:,t)=A{1,t-1}*x_1a(:,t-1);
yalmip('clear');
K1       = sdpvar(2, 1, 'full');         
Theta1   = sdpvar(2, 2,'symmetric');    
X1       = sdpvar(2, 2,'symmetric');
zeta1    = sdpvar(1, 1);      % 标量 zeta_i(k)
Constraints = [];
for i=2:135
A_t  =A{1,t-1}+Deta_a{1,i};
C_t1 =C_1+Deta_c1{1,i};
G_t1 =eye(2)-K1*C_t1;
B_t1 =[(eye(2)-K1*C_t1)*B{1,t-1},-K1];
Q1{i}=[-eye(2),     G_t1*A_t,    B_t1;
    (G_t1*A_t)'  -Theta1,     zeros(2);
     B_t1',      zeros(2),    -X1];
Constraints = [Constraints, Q1{i} <= 1e-6 * eye(size(Q1{i}))];
end
%% 第五步：添加约束条件
Constraints = [Constraints, Theta1 - zeta1 * eye(2) <= 0];
Constraints = [Constraints, zeta1 <= 1];
Constraints = [Constraints, Theta1 >= 1e-6*eye(2)];
Constraints = [Constraints, X1 >= 1e-6*eye(2)];
Constraints = [Constraints, zeta1 >= 0];
%% 第六步：定义目标函数并求解
Objective = trace(X1);
% 配置求解器为 SeDuMi
options = sdpsettings(...
    'solver', 'sdpt3', ...       % 小写求解器名
    'verbose', 1, ...            % 显示求解日志
    'sdpt3.maxiter', 1000, ...   % 增大最大迭代次数（默认200）
    'sdpt3.epsilon', 1e-8, ...   % 放宽收敛阈值（默认1e-6）
    'sdpt3.printlevel', 2);      % 输出更详细的求解信息（便于排查问题）
% 求解
sol = optimize(Constraints, Objective, options);
%% 第七步：获取结果
if sol.problem == 0
    disp('求解成功!');
    K1 = value(K1);
else
    disp('求解失败，请检查约束或系统矩阵是否可行');
    disp(sol.info);
end
%% 根据增益矩阵直接进行更新
x_1a(:, t)= x_1e(:, t)+K1*(y_1(:, t)-C_1*x_1e(:, t));
end

%% 估计器设计 2 
for t=2:N
x_2e(:,t)=A{1,t-1}*x_2a(:,t-1);
yalmip('clear');
K2       = sdpvar(2, 1, 'full');         
Theta2   = sdpvar(2, 2,'symmetric');    
X2       = sdpvar(2, 2,'symmetric');
zeta2    = sdpvar(1, 1);      % 标量 zeta_i(k)
Constraints = [];
for i=2:135
A_t  =A{1,t-1}+Deta_a{1,i};
C_t2 =C_2+Deta_c2{1,i};
G_t2 =eye(2)-K2*C_t2;
B_t2 =[(eye(2)-K2*C_t2)*B{1,t-1},-K2];
Q2{i}=[-eye(2),     G_t2*A_t,    B_t2;
    (G_t2*A_t)'  -Theta2,     zeros(2);
     B_t2',      zeros(2),    -X2];
Constraints = [Constraints, Q2{i} <= 1e-6 * eye(size(Q2{i}))];
end
%% 第五步：添加约束条件
Constraints = [Constraints, Theta2 - zeta2 * eye(2) <= 0];
Constraints = [Constraints, zeta2 <= 1];
Constraints = [Constraints, Theta2 >= 1e-6*eye(2)];
Constraints = [Constraints, X2 >= 1e-6*eye(2)];
Constraints = [Constraints, zeta2 >= 0];
%% 第六步：定义目标函数并求解
Objective = trace(X2);
% 配置求解器为 SeDuMi
options = sdpsettings(...
    'solver', 'sdpt3', ...       % 小写求解器名
    'verbose', 1, ...            % 显示求解日志
    'sdpt3.maxiter', 1000, ...   % 增大最大迭代次数（默认200）
    'sdpt3.epsilon', 1e-8, ...   % 放宽收敛阈值（默认1e-6）
    'sdpt3.printlevel', 2);      % 输出更详细的求解信息（便于排查问题）
% 求解
sol = optimize(Constraints, Objective, options);
%% 第七步：获取结果
if sol.problem == 0
    disp('求解成功!');
    K1 = value(K1);
else
    disp('求解失败，请检查约束或系统矩阵是否可行');
    disp(sol.info);
end
%% 根据增益矩阵直接进行更新
x_2a(:, t)= x_2e(:, t)+K2*(y_2(:, t)-C_2*x_2e(:, t));
end


%% 融合中心进行融合
for t=2:N








end


































