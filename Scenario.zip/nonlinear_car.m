%% 直接使用情景优化问题来进行处理, 先不考虑不确定性,后面再考虑不确定性的影响.
%% 1.先使用情景优化,跑出结果与仿真. 传感器部分先使用线性的部分   
%% 2.加入不确定项与师兄和陈老师方法进行对比实验
%% 3.需要写一个函数来生成不确定性矩阵M
clc;
clear;
%% 系统参数
N=100;
T=0.6;
omega=pi/15;
A=[1,sin(omega*T),0,(cos(omega*T)-1)/omega;
   0,cos(omega*T),0,-sin(omega*T);
   0,(1-cos(omega*T))/omega,1,sin(omega*T)/omega;
   0,sin(omega*T),0,cos(omega*T)];
B=[T,1,0,0;0,0,T,1]';
C_1=[1 0 0 0;0 0 1 0]; D_1=diag([0.4,-0.5]);
C_2=[1 0 1 0;0 0 1 0]; D_2=diag([0.8,-0.6]);
C_3=[0 0 1 0;1 0 1 0]; D_3=diag([0.2,-0.1]);
M1{1}=diag([0.03,0.02,0.01,0.03]); %% 状态缩放矩阵
M2{1}=diag([0.03,0.02,0.01,0.03]); %% 状态缩放矩阵
M3{1}=diag([0.03,0.02,0.01,0.03]); %% 状态缩放矩阵
%% 生成噪声
w=[0.8*rand(1,N)-0.7;0.4*rand(1,N)-0.3];
v_1=[0.4*rand(1,N)-0.2;0.2*rand(1,N)-0.1];
v_2=[0.8*rand(1,N)-0.4;0.6*rand(1,N)-0.3];
v_3=[0.2*rand(1,N)-0.1;0.3*rand(1,N)-0.15];
%% 初始状态
x(:, 1)=[1; 0.2; 1; 0.2];    x_f(:, 1)=[1; 0.2; 1; 0.2];
x_1a(:, 1)=[1; 0.2; 1; 0.2]; x_1e(:, 1)=[1; 0.2; 1; 0.2];
x_2a(:, 1)=[1; 0.2; 1; 0.2]; x_2e(:, 1)=[1; 0.2; 1; 0.2];
x_3a(:, 1)=[1; 0.2; 1; 0.2]; x_3e(:, 1)=[1; 0.2; 1; 0.2];
y_1(:, 1) = C_1 * x(:, 1) +D_1*v_1(:, 1);
y_2(:, 1) = C_2 * x(:, 1) +D_2*v_2(:, 1);
y_3(:, 1) = C_3 * x(:, 1) +D_3*v_3(:, 1);
%% 生成真实状态和传感器量测
for t=2:N
fk = compute_fk(x(:, t-1));
x(:, t) = A*x(:, t-1) + B*w(:, t) + fk ;
y_1(:, t) = C_1 * x(:, t) +D_1*v_1(:, t);
y_2(:, t) = C_2 * x(:, t) +D_2*v_2(:, t);
y_3(:, t) = C_3 * x(:, t) +D_3*v_3(:, t);
end
%% 先生成不确定性的采样点,先生成 100个
for t = 1: 1000
L_e1{1,t}=1*rand(4,4)-0.5;
L_e2{1,t}=2*rand(4,4)-1;
L_e3{1,t}=2*rand(4,4)-1;
end
%% 估计器设计 1
for t=2:N
%% 预测部分
x_1e(:, t)= compute_fk(x_1a(:, t-1));
A_f1{t}=Y_d(x_1a(:, t-1));
M1{t}=DM(x_1a(:, t-1),x(:, t-1));
%% 更新部分 需要先求解增益矩阵
%% 第一步：使用LMI进行求解
setlmis([]);
K1       = lmivar(2, [4 2]);         % 增益矩阵 K_i(k) (n x m)
Theta1   = lmivar(1, [4 1]); % 对称正定矩阵 Theta_i(k)
X1       = lmivar(1, [4 1]);
zeta1    = lmivar(1, [1 1]);             % 标量 epsilon_i(k)
%% 构造相关矩阵
for i=1:100 
lmi_idx = newlmi;
A_temp1{1,i} = A + A_f1{t} + M1{t} * L_e1{1,i};
lmiterm([lmi_idx, 1, 1, 0], -eye(4));
lmiterm([lmi_idx, 1, 2, 0], A_temp1{1,i});
lmiterm([lmi_idx, 1, 2, K1], -1, C_1 * A_temp1{1,i});
B_const_part1 = [B, zeros(4, 2)];
% 构造系数部分 [C1*B, D1]
B_coeff_part1 = [C_1 * B, D_1];
lmiterm([lmi_idx, 1, 3, 0], B_const_part1);
lmiterm([lmi_idx, 1, 3, K1], -1, B_coeff_part1);
lmiterm([lmi_idx, 2, 2, Theta1], -1, 1);
lmiterm([lmi_idx, 3, 3, X1], -1, 1);
end
% 约束2
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta1], 1, 1);
lmiterm([lmi_idx, 1, 1, zeta1], -1, eye(4))
% 约束3
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta1], 1, 1);
lmiterm([lmi_idx, 1, 1, 0], -1);
% 约束4
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta1], -1, 1);      % -Theta1
lmiterm([lmi_idx, 1, 1, 0], 1e-2 * eye(4));      % +Constant
% 约束4
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, X1], -1, 1);
lmiterm([lmi_idx, 1, 1, 0], 1e-2 * eye(4));
% 约束5
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta1], -1, 1);
lmisys1 = getlmis;
n1 = decnbr(lmisys1); 
c1 = zeros(1, n1);
for q=1:n1
[T1]=defcx(lmisys1,q,X1);
c1(q)=trace(T1);
end
options=[1e-3,2000,1e-3,0,0];
[copt,xopt] = mincx(lmisys1,c1,options);
if ~isempty(xopt)
  % disp(['Time ' num2str(t) ' solved success.']);
  K1_val{i} = dec2mat(lmisys1, xopt, K1);
  x_1a(:, t) = x_1e(:, t) + K1_val{i} * (y_1(:, t) - C_1 * x_1e(:, t));
else
logFile = fopen('LMI_solve_error.log', 'a');
fprintf(logFile, '时刻 t=%d：LMI求解失败，使用预测值保底，已终止循环\n', t);
fclose(logFile);
% 2. 保底赋值,不需要保底赋值
x_1a(:, t) = x_1e(:, t);
error(['时刻 t=' num2str(t) ' LMI求解失败，日志已保存至 LMI_solve_error.log']);
end
end

%% 估计器设计 2
for t=2:N
%% 预测部分
x_2e(:, t)= compute_fk(x_2a(:, t-1));
A_f2{t}=Y_d(x_2a(:, t-1));
M2{t}=DM(x_2a(:, t-1),x(:, t-1));
%% 更新部分 需要先求解增益矩阵
%% 第一步：使用LMI进行求解
setlmis([]);
K2       = lmivar(2, [4 2]);         % 增益矩阵 K_i(k) (n x m)
Theta2   = lmivar(1, [4 1]); % 对称正定矩阵 Theta_i(k)
X2       = lmivar(1, [4 1]);
zeta2    = lmivar(1, [1 1]);             % 标量 epsilon_i(k)
%% 构造相关矩阵
for i=1:100 
lmi_idx = newlmi;
A_temp2{1,i} = A + A_f2{t} + M2{t} * L_e2{1,i};
lmiterm([lmi_idx, 1, 1, 0], -eye(4));
lmiterm([lmi_idx, 1, 2, 0], A_temp2{1,i});
lmiterm([lmi_idx, 1, 2, K2], -1, C_2 * A_temp2{1,i});
B_const_part2 = [B, zeros(4, 2)];
% 构造系数部分 [C1*B, D1]
B_coeff_part2 = [C_2 * B, D_2];
lmiterm([lmi_idx, 1, 3, 0], B_const_part2);
lmiterm([lmi_idx, 1, 3, K2], -1, B_coeff_part2);
lmiterm([lmi_idx, 2, 2, Theta2], -1, 1);
lmiterm([lmi_idx, 3, 3, X2], -1, 1);
end
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta2], 1, 1);
lmiterm([lmi_idx, 1, 1, zeta2], -1, eye(4))
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta2], 1, 1);
lmiterm([lmi_idx, 1, 1, 0], -1);
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta2], -1, 1);      % -Theta1
lmiterm([lmi_idx, 1, 1, 0], 1e-6 * eye(4));       % +Constant
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, X2], -1, 1);
lmiterm([lmi_idx, 1, 1, 0], 1e-6 * eye(4));
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta2], -1, 1);
lmisys2 = getlmis;
n2 = decnbr(lmisys2); 
c2 = zeros(1, n2);
for q=1:n2
[T2]=defcx(lmisys2,q,X2);
c2(q)=trace(T2);
end
options=[1e-4,100,0,0,0];
[copt,xopt] = mincx(lmisys2,c2,options);
if ~isempty(xopt)
   % disp(['Time ' num2str(t) ' solved success.']);
   K2_val{i} = dec2mat(lmisys2, xopt, K2);
   x_2a(:, t) = x_2e(:, t) + K2_val{i} * (y_2(:, t) - C_2 * x_2e(:, t));
else
logFile = fopen('LMI_solve_error.log', 'a');
fprintf(logFile, '时刻 t=%d：LMI求解失败，使用预测值保底，已终止循环\n', t);
fclose(logFile);
% 2. 保底赋值
x_2a(:, t) = x_2e(:, t);
error(['时刻 t=' num2str(t) ' LMI求解失败，日志已保存至 LMI_solve_error.log']);
end
end

%% 估计器设计 3
for t=2:N
%% 预测部分
x_3e(:, t)= compute_fk(x_3a(:, t-1));
A_f3{t}=Y_d(x_3a(:, t-1));
M3{t}=DM(x_3a(:, t-1),x(:, t-1));
%% 更新部分 需要先求解增益矩阵
%% 第一步：使用LMI进行求解
setlmis([]);
K3       = lmivar(2, [4 2]);         % 增益矩阵 K_i(k) (n x m)
Theta3   = lmivar(1, [4 1]); % 对称正定矩阵 Theta_i(k)
X3       = lmivar(1, [4 1]);
zeta3    = lmivar(1, [1 1]);             % 标量 epsilon_i(k)
%% 构造相关矩阵
for i=1:100 
lmi_idx = newlmi;
A_temp3{1,i} = A + A_f3{t} + M3{t} * L_e1{1,i};
lmiterm([lmi_idx, 1, 1, 0], -eye(4));
lmiterm([lmi_idx, 1, 2, 0], A_temp3{1,i});
lmiterm([lmi_idx, 1, 2, K3], -1, C_3 * A_temp3{1,i});
B_const_part3 = [B, zeros(4, 2)];
% 构造系数部分 [C1*B, D1]
B_coeff_part3 = [C_3 * B, D_3];
lmiterm([lmi_idx, 1, 3, 0], B_const_part3);
lmiterm([lmi_idx, 1, 3, K3], -1, B_coeff_part3);
lmiterm([lmi_idx, 2, 2, Theta3], -1, 1);
lmiterm([lmi_idx, 3, 3, X3], -1, 1);
end
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta3], 1, 1);
lmiterm([lmi_idx, 1, 1, zeta3], -1, eye(4))
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta3], 1, 1);
lmiterm([lmi_idx, 1, 1, 0], -1);
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, Theta3], -1, 1);      % -Theta1
lmiterm([lmi_idx, 1, 1, 0], 1e-6 * eye(4));       % +Constant
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, X3], -1, 1);
lmiterm([lmi_idx, 1, 1, 0], 1e-6 * eye(4));
lmi_idx = newlmi;
lmiterm([lmi_idx, 1, 1, zeta3], -1, 1);
lmisys3 = getlmis;
n3 = decnbr(lmisys3); 
c3 = zeros(1, n3);
for q=1:n3
[T3]=defcx(lmisys3,q,X3);
c3(q)=trace(T3);
end
options=[1e-4,100,0,0,0];
[copt,xopt] = mincx(lmisys3,c3,options);
if ~isempty(xopt)
   % disp(['Time ' num2str(t) ' solved success.']);
   K3_val{i} = dec2mat(lmisys3, xopt, K3);
   x_3a(:, t) = x_3e(:, t) + K3_val{i} * (y_3(:, t) - C_3 * x_3e(:, t));
else
logFile = fopen('LMI_solve_error.log', 'a');
fprintf(logFile, '时刻 t=%d：LMI求解失败，使用预测值保底，已终止循环\n', t);
fclose(logFile);
% 2. 保底赋值
x_3a(:, t) = x_3e(:, t);
error(['时刻 t=' num2str(t) ' LMI求解失败，日志已保存至 LMI_solve_error.log']);
end

end

%% 融合中心进行融合
for t=2:N
B_K1=[(eye(4)-K1_val{i}*C_1)*B,-K1_val{i}*D_1];
B_K2=[(eye(4)-K2_val{i}*C_2)*B,-K2_val{i}*D_2];
B_K3=[(eye(4)-K3_val{i}*C_3)*B,-K3_val{i}*D_3];
B_K=mdiag(B_K1,B_K2,B_K3);
RB_1=[B_K1,zeros(4),-B_K3];
RB_2=[zeros(4),B_K2,-B_K3];
RB_3=[zeros(4),zeros(4),B_K3];
for i=1:100
A_K1{i}=(eye(4)-K1_val{t}*C_1)*(A+A_f1{t}+ M1{t}*L_e1{1,i});
A_K2{i}=(eye(4)-K2_val{t}*C_2)*(A+A_f2{t}+ M2{t}*L_e2{1,i});
A_K3{i}=(eye(4)-K3_val{t}*C_3)*(A+A_f3{t}+ M3{t}*L_e3{1,i});
A_K{i}=mdiag(A_K1{i},A_K2{i},A_K3{i});
RA_1{i}=[A_K1{i},zeros(4),-A_K3{i}];
RA_2{i}=[zeros(4),A_K2{i},-A_K3{i}];
RA_3{i}=[zeros(4),zeros(4),A_K3{i}];
end
%% 求取权重矩阵W,
setlmis([]);
W1 = lmivar(2, [4 4]);
W2 = lmivar(2, [4 4]);
Theta = lmivar(1, [12 1]);
X     = lmivar(1, [12 1]);
Pi    = lmivar(2, [12 12]);
for i = 1:100
lmi = newlmi;
% 第一块 11
lmiterm([lmi, 1, 1, 0], -eye(4));
% 第二块 12
lmiterm([lmi, 1, 2 W1], 1,RA_1{i}); % 变量项 W1
lmiterm([lmi, 1, 2 W2], 1,RA_2{i}); % 变量项 W1
lmiterm([lmi, 1, 2 0],  RA_3{i}); % 变量项 W1
% 第三块 13
lmiterm([lmi, 1, 3 W1], 1,RB_1); % 变量项 W1
lmiterm([lmi, 1, 3 W2], 1,RB_2); % 变量项 W1
lmiterm([lmi, 1, 3 0],    RB_3); % 变量项 W1
% 第四块 22
lmiterm([lmi, 2, 2 Theta], -1, 1);
% 第四块 23
lmiterm([lmi, 2, 3 Pi], -1, 1);
% 第五块 33
lmiterm([lmi, 3, 3 X], -1, 1);
end
lmi = newlmi;
lmiterm([lmi, 1, 1, Theta], -1, 1);       % -Theta1
lmiterm([lmi, 1, 1, 0], 1e-6 * eye(12));  % +Constant
lmi = newlmi;
lmiterm([lmi, 1, 1, X], -1, 1);
lmiterm([lmi, 1, 1, 0], 1e-6 * eye(12));
lmis = getlmis;
n_w = decnbr(lmis); 
c_w = zeros(1, n_w);
for q=1:n_w 
[TT]=defcx(lmis,q,X);
[MM]=defcx(lmis,q,Theta);
c_w(q)=trace(TT)+trace(MM);
end
options=[1e-4,100,0,0,0];
[copt,xopt] = mincx(lmis,c_w,options);
if ~isempty(xopt)
   % disp(['Time ' num2str(t) ' solved success.']);
   W1_val = dec2mat(lmis, xopt, W1);
   W2_val = dec2mat(lmis, xopt, W2);
   x_f(:, t)=W1_val*x_1a(:, t)+W2_val*x_2a(:, t)+(eye(4)-W1-W2)*x_3a(:, t);
else
logFile = fopen('LMI_solve_error.log', 'a');
fprintf(logFile, '时刻 t=%d：LMI求解失败，使用预测值保底，已终止循环\n', t);
fclose(logFile);
error(['时刻 t=' num2str(t) ' LMI求解失败，日志已保存至 LMI_solve_error.log']);
end
end



yalmip('clear');
W1= sdpvar(4, 4, 'full');     
W2= sdpvar(4, 4, 'full');   
Theta = sdpvar(12, 12,'symmetric');    
X     = sdpvar(12, 12,'symmetric');
Pi    = sdpvar(12, 12);      % 标量 zeta_i(k)
W=[W1,W2,eye(4)-W1-W2];
for i=1:100
F_W{i}=[eye(4),      W*A_K{i},     W*B_K;
       (W*A_K{i})',  -Theta,       -Pi;
       (W*B_K)',     (-Pi)',       -X];             
Constraints = [Constraints, F_W{i} <= 1e-6 * eye(size(F_W{i}))];
end
Constraints = [Constraints, Theta >= 1e-6*eye(12)];
Constraints = [Constraints, X >= 1e-6*eye(12)];
%% 第六步：定义目标函数并求解
Objective = trace(X)+trace(Theta);
% 配置求解器为 SeDuMi
options = sdpsettings(...
    'solver', 'sdpt3', ...       % 小写求解器名
    'verbose', 1, ...            % 显示求解日志
    'sdpt3.maxiter', 1000, ...   % 增大最大迭代次数（默认200）
    'sdpt3.epsilon', 1e-8, ...   % 放宽收敛阈值（默认1e-6）
    'sdpt3.printlevel', 2);      % 输出更详细的求解信息（便于排查问题）
% 求解
sol = optimize(Constraints, Objective, options);






























































