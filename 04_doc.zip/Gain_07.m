function [K_opt] = Gain_07(ss) 
    setlmis([])
        Phi_1=lmivar(1,[ss.dim_x,1]);
        Phi_12=lmivar(2,[ss.dim_x,sum(ss.dim_neighbor)+ss.dim_w+ss.dim_v]);
        Phi_2=lmivar(1,[sum(ss.dim_neighbor)+ss.dim_w+ss.dim_v,1]);
        [K,~,~]=lmivar(2,[ss.dim_x,ss.dim_y]);
%         kar=lmivar(1,[1,1]);
        %1st LMI
        lmiterm([1 1 1 0],-1);
        lmiterm([1 1 2 0],ss.A);
        lmiterm([1 1 2 K],-1,ss.C*ss.A);
        lmiterm([1 1 3 0],[ss.A_neighbor{1:end} ss.B zeros(ss.dim_x,ss.dim_v)]);
        if(ss.number_neighbor==0)
            lmiterm([1 1 3 K],-1,[ss.C*ss.B ss.D]);
        else
            lmiterm([1 1 3 K],-1,[ss.C*[ss.A_neighbor{1:end}] ss.C*ss.B ss.D]);
        end
        lmiterm([1 2 2 Phi_1],-1,1);
        lmiterm([1 2 3 Phi_12],-1,1);
    
        lmiterm([1 3 3 Phi_2],-1,1);
%         %2nd LMI
%         lmiterm([2 1 1 Phi_1],1,1);
%         lmiterm([-2 1 1 kar],1,eye(ss.dim_x));
%         %3rd LMI
%         lmiterm([3 1 1 kar],1,1);
%         lmiterm([-3 1 1 0],1);
        lmisys=getlmis;
    %LMI ���
    n_LMI=decnbr(lmisys);
    c_LMI=zeros(1,n_LMI);
    for j=1:n_LMI
        [Phi_1s,Phi_2s]=defcx(lmisys,j,Phi_1,Phi_2);
        c_LMI(j)=trace(Phi_1s)+trace(Phi_2s);
    end
    [copt xopt]=mincx(lmisys,c_LMI); % ����н�
    K_opt=dec2mat(lmisys,xopt,K); % ��ȡ�����
end

