classdef Subsystem
    properties
        index;
        A;
        B; % system noise;
        C;
        D; % measurement noise;
        F; % control;
        A_neighbor; % neighbor subsystems; data type: cell;
        neighbor; % index of neighbors;
        number_neighbor;
        dim_neighbor;
        dim_x;
        dim_y;
        dim_w;
        dim_v;
        dim_u;
        number_overlap;
        overlap;
    end
    methods
        
        function ss=Subsystem(index,A,B,C,D,F,A_neighbor,neighbor)
            ss.index=index; ss.A=A; ss.B=B; ss.C=C; ss.D=D; ss.F=F;
            ss.A_neighbor=A_neighbor; ss.neighbor=neighbor;
        end   
        function ss=Compute_dim(ss)
            ss.dim_x=size(ss.A,1);
            ss.dim_y=size(ss.C,1);
            ss.dim_w=size(ss.B,2);
            ss.dim_v=size(ss.D,2);
            ss.dim_u=size(ss.F,2);
            ss.number_neighbor=size(ss.neighbor,2);
            ss.number_overlap=size(ss.overlap,2);
            ss.dim_neighbor=[];
            for i=1:size(ss.A_neighbor,2)
                ss.dim_neighbor(end+1)=size(ss.A_neighbor{i},2);
            end
        end
        
    end
end