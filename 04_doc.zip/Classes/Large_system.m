classdef Large_system
    properties
        A;
        B;
        C; %C的划分是错误的？
        D;
        F;
        dim_x; dim_y; dim_w; dim_v; dim_u;
        part_x; part_w; part_y; part_v; part_u; % partions of a large system
        L % number of subsystems;
        subsystems; % L*1 cell;
        adjacent; % adjacent matrix
        permutation; % permutation matrix among subsystems
    end
    methods
        
        % Construct a large system
        function sys=Large_system(A,B,C,D,F)
            sys.A=A; sys.B=B; sys.C=C; sys.D=D; sys.F=F;
        end
        % Compute its dimensions
        function sys=Compute_dim(sys)
            sys.dim_x=size(sys.A,1);
            sys.dim_y=size(sys.C,1);
            sys.dim_w=size(sys.B,2);
            sys.dim_v=size(sys.D,2);
            sys.dim_u=size(sys.F,2);
        end
        % Decompose a large system into subsystems by given partions
        function sys=Partion(sys,part_x,part_w,part_y,part_v,part_u)
            sys.part_x=part_x;
            sys.part_w=part_w;
            sys.part_y=part_y;
            sys.part_v=part_v;
            sys.part_u=part_u;
            sys.L=size(part_x,2);
            for i=1:sys.L
                neighbor=[]; A_neighbor={};
                for j=1:sys.L
                    if(j~=i)
                        % find non-zero matrices as neighbors 
                        if(any(any(sys.A(part_x{i},setdiff(part_x{j},part_x{i}))))==1)
                            neighbor(end+1)=j;
                            A_neighbor{end+1}=[zeros(size(part_x{i},2),size(intersect(part_x{i},part_x{j}),2)) sys.A(part_x{i},setdiff(part_x{j},part_x{i}))];
                        end
                    end
                end
                sys.subsystems{1,i}=Subsystem(i,sys.A(part_x{i},part_x{i}),...
                                                 sys.B(part_x{i},part_w{i}),....
                                                 sys.C(part_y{i},part_x{i}),...
                                                 sys.D(part_y{i},part_v{i}),...
                                                 sys.F(part_x{i},part_u{i}),...
                                                 A_neighbor,neighbor);
            end
        end
        % compute its adjacent matrix
        function sys=Compute_adjacent(sys)
            sys.adjacent=[];
            for i=1:sys.L
                sys.adjacent(i,[i sys.subsystems{i}.neighbor])=1;
            end
        end
        % compute its permutation matrix
        function sys=Compute_permutation(sys)
            sys.permutation={};
            for i=1:sys.L
                for j=1:sys.L
                    temp=diag(ones(1,size(sys.part_x{i},2)));
                    sys.permutation{i,j,1}=temp(find(ismember(sys.part_x{i},intersect(sys.part_x{i},sys.part_x{j}))==1),:);
                    sys.permutation{i,j,2}=temp(find(ismember(sys.part_x{i},setdiff(sys.part_x{i},sys.part_x{j}))==1),:);
                end
            end
        end
        function sys=Compute_overlap(sys)
            for i=1:sys.L
                sys.subsystems{i}.overlap=[];
                for j=1:sys.L
                    if(size(intersect(sys.part_x{i},sys.part_x{j}),2)~=0 && j~=i)
                        sys.subsystems{i}.overlap=[sys.subsystems{i}.overlap j];
                    end
                end
            end
        end

    end
end