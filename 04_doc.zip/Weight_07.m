function [W_opt] = Weight_07(ss,permutation,K)
    % ����û�ж�neighbor��overlap�������֣�ʵ����Ӧ���Ǽ���overlap����neighbor�Ż�ִ���ںϡ�
    setlmis([])
        temp=[];
        count=0;
        for i=1:ss.number_neighbor
            W_opt{i}=zeros(ss.dim_x);
            if(size(permutation{ss.index,ss.neighbor(i),1},1)~=0)
                temp(end+1)=i;
                count=count+1;
                [W1{count},nW1{count},sW1{count}]=lmivar(1,[size(permutation{ss.index,ss.neighbor(i),1},1),1]);
                [W2{count},nW2{count},sW2{count}]=lmivar(3,permutation{ss.index,ss.neighbor(i),1}'*sW1{count}*permutation{ss.neighbor(i),ss.index,1}); 
            end
        end
        [W0,nW0,sW0]=lmivar(3,[sW2{1:end}]);
        Phi_1=lmivar(1,[ss.dim_x,1]);
        Phi_2=lmivar(1,[ss.dim_x*size(sW2,2)+sum(ss.dim_neighbor)+ss.dim_w+ss.dim_v,1]);
%         Phi_12=lmivar(2,[ss.dim_x,sum(ss.dim_neighbor)+ss.dim_w+ss.dim_v]); 
        kar=lmivar(1,[1,1]);
        %1st LMI
        lmiterm([1 1 1 0],-1);
        lmiterm([1 1 2 0],eye(ss.dim_x)-K*ss.C*ss.A);
        lmiterm([1 1 2 W0],-1,repmat(eye(ss.dim_x),size(sW2,2),1)*[eye(ss.dim_x)-K*ss.C*ss.A]);
        lmiterm([1 1 3 0],[zeros(ss.dim_x,ss.dim_x*size(sW2,2)) (eye(ss.dim_x)-K*ss.C)*[ss.A_neighbor{1:end}] (eye(ss.dim_x)-K*ss.C)*ss.B -K*ss.D]);
        lmiterm([1 1 3 W0],-1,repmat(eye(ss.dim_x),size(sW2,2),1)*[zeros(ss.dim_x,ss.dim_x*size(sW2,2)) (eye(ss.dim_x)-K*ss.C)*[ss.A_neighbor{1:end}] (eye(ss.dim_x)-K*ss.C)*ss.B -K*ss.D]);
        lmiterm([1 1 3 W0],1,[eye(ss.dim_x*size(sW2,2)) zeros(ss.dim_x*size(sW2,2),sum(ss.dim_neighbor)+ss.dim_w+ss.dim_v)]);
        
        lmiterm([1 2 2 Phi_1],-1,1);
%         lmiterm([1 2 3 Phi_12],-1,1);
    
        lmiterm([1 3 3 Phi_2],-1,1);
        %2nd LMI
        lmiterm([2 1 1 Phi_1],1,1);
        lmiterm([-2 1 1 kar],1,eye(ss.dim_x));
        %3rd LMI
        lmiterm([3 1 1 kar],1,1);
        lmiterm([-3 1 1 0],1.1);
        lmisys=getlmis;
    %LMI ���
    n_LMI=decnbr(lmisys);
    c_LMI=zeros(1,n_LMI);
    for j=1:n_LMI
        [Phi_1s,Phi_2s]=defcx(lmisys,j,Phi_1,Phi_2);
        c_LMI(j)=trace(Phi_1s)+trace(Phi_2s);
    end
    [copt xopt]=mincx(lmisys,c_LMI); % ����н�
    W0_opt=dec2mat(lmisys,xopt,W0); % ��ȡ�����
    for i=1:size(sW2,2)
        W2_opt{i}=dec2mat(lmisys,xopt,W2{i}); % ��ȡ�����
        W_opt{temp(i)}=W2_opt{i};
    end
    W_opt{end+1}=eye(ss.dim_x)-W0_opt*repmat(eye(ss.dim_x),size(sW2,2),1);
end

