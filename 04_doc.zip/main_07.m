clc;
clear;
close all;
warning ('off');
%% Interconnected system model
T=0.1; % Sampling time
L0=4; % number of inverted pendulums   
g=9.8; % gravity unit
l=1; % rod length
for i=1:L0
    m(i)=10+5*rand;
    M(i)=20+5*rand;
end
for i=1:L0
    A_D{i}=[1 T 0 0;0 1 -m(i)*g*T/M(i) 0;0 0 1 T;0 0 (M(i)+m(i))*g*T/(M(i)*l) 1];
    B_D{i}=[0;T/M(i);0;-T/(M(i)*l)];
end
M_T=[0 T 0 0];
A_d=[1 zeros(1,4) -M_T 0 M_T zeros(1,4);
   zeros(4,1) A_D{1} zeros(4,13);
   zeros(4,5) A_D{2} zeros(4,9);
   zeros(1,9) 1 -M_T M_T;
   zeros(4,10) A_D{3} zeros(4,4);
   zeros(4,14) A_D{4}];

F_d=[zeros(1,4);B_D{1} zeros(4,3);zeros(4,1) B_D{2} zeros(4,2);zeros(1,4);zeros(4,2) B_D{3} zeros(4,1);zeros(4,3) B_D{4}];
sys=Large_system(A_d,eye(18),mdiag(1,[1 0 0 0;0 0 1 0],[1 0 0 0;0 0 1 0],1,[1 0 0 0;0 0 1 0],[1 0 0 0;0 0 1 0]),eye(10),F_d);
sys=Partion(sys,{1:9 6:14 15:18},{1:9 6:14 15:18},{1:5 4:8 9:10},{1:5 4:8 9:10},{1:1 2:2 3:3 4:4});
sys=sys.Compute_dim; sys=sys.Compute_adjacent; sys=sys.Compute_permutation; sys=sys.Compute_overlap;
for i=1:sys.L
    sys.subsystems{i}=sys.subsystems{i}.Compute_dim;
end

%% System running
N=200;
% LQR control
R=mdiag(1,1,1,1);
Q=diag([1000000,0.1,10,0.1,1000000,0.1,10,0.1,1000000,0.1,10,0.1,1000000,0.1,10,0.1]);
[K_u,~,~]=dlqr(mdiag(A_D{1},A_D{2},A_D{3},A_D{4}),mdiag(B_D{1},B_D{2},B_D{3},B_D{4}),Q,R);
% System noises
w_c=0.1*(2*rand(sys.dim_w,N)-1);
w_c(1,:)=zeros(1,size(w_c,2));
w_c(10,:)=zeros(1,size(w_c,2));
for i=1:sys.L
    w{i}=w_c(sys.part_x{i},:);
    v{i}=0.2*(2*rand(sys.subsystems{i}.dim_v,N)-1);
end
% state iteration
x_c(:,1)=zeros(sys.dim_x,1);
for k=2:N
    u_temp(:,k)=-mdiag(B_D{1},B_D{2},B_D{3},B_D{4})*K_u*[x_c(2:9,k-1);x_c(11:18,k-1)];
    u(:,k)=[0;u_temp(1:8,k);0;u_temp(9:16,k)]
    x_c(:,k)=sys.A*x_c(:,k-1)+sys.B*w_c(:,k-1)+u(:,k);
end
for k=1:N
    for i=1:sys.L   
        x{i}(:,k)=x_c(sys.part_x{i},k);
        y{i}(:,k)=sys.subsystems{i}.C*x{i}(:,k)+sys.subsystems{i}.D*v{i}(:,k);
    end
end

%% Estimation without Fusion
for i=1:sys.L
    x_e1{i}(:,1)=zeros(sys.subsystems{i}.dim_x,1);
end
for k=2:N
    for i=1:sys.L
        x_e1{i}(:,k)=sys.subsystems{i}.A*x_e1{i}(:,k-1)+u(sys.part_x{i},k);
        for j=1:sys.subsystems{i}.number_neighbor
            x_e1{i}(:,k)=x_e1{i}(:,k)+sys.subsystems{i}.A_neighbor{j}*x_e1{sys.subsystems{i}.neighbor(j)}(:,k-1);
        end
        K{i}(:,:,k)=Gain_07(sys.subsystems{i});
        x_e1{i}(:,k)=x_e1{i}(:,k)+K{i}(:,:,k)*(y{i}(:,k)-sys.subsystems{i}.C*x_e1{i}(:,k));
        err1{i}(:,k)=x{i}(:,k)-x_e1{i}(:,k);
        se1{i}(k)=err1{i}(:,k)'*err1{i}(:,k);
    end
    
%     for i=1:sys.L
%         W_opt=Weight_07(sys.subsystems{i},sys.permutation,K{i}(:,:,k));
%         x_e2{i}(:,k)=W_opt{end}*x_e1{i}(:,k);
%         for j=1:sys.subsystems{i}.number_neighbor
%             x_e2{i}(:,k)=x_e2{i}(:,k)+W_opt{j}*x_e1{j}(:,k);
%         end
%         err2{i}(:,k)=x{i}(:,k)-x_e2{i}(:,k);
%         se2{i}(k)=err2{i}(:,k)'*err2{i}(:,k);
%     end
end

% %% Estimation with Fusion
% for i=1:sys.L
%     x_e2{i}(:,1)=zeros(sys.subsystems{i}.dim_x,1);
% end
% for k=2:N
%     for i=1:sys.L
%         x_e2{i}(:,k)=sys.subsystems{i}.A*x_e2{i}(:,k-1)+u(sys.part_x{i},k);
%         for j=1:sys.subsystems{i}.number_neighbor
%             x_e2{i}(:,k)=x_e2{i}(:,k)+sys.subsystems{i}.A_neighbor{j}*x_e2{sys.subsystems{i}.neighbor(j)}(:,k-1);
%         end
%         K{i}(:,:,k)=Gain_07(sys.subsystems{i});
%         x_e2{i}(:,k)=x_e2{i}(:,k)+K{i}(:,:,k)*(y{i}(:,k)-sys.subsystems{i}.C*x_e2{i}(:,k));
%     end
%     
%     for i=1:1
%         W_opt=Weight_07(sys.subsystems{i},sys.permutation,K{i}(:,:,k));
%         x_e2{i}(:,k)=W_opt{end}*x_e2{i}(:,k);
%         for j=1:sys.subsystems{i}.number_neighbor
%             x_e2{i}(:,k)=x_e2{i}(:,k)+W_opt{j}*x_e2{j}(:,k);
%         end
%         err2{i}(:,k)=x{i}(:,k)-x_e2{i}(:,k);
%         se2{i}(k)=err2{i}(:,k)'*err2{i}(:,k);
%     end    
% end

% %% KF
% for i=1:sys.L
%     x_e3{i}(:,1)=zeros(sys.subsystems{i}.dim_x,1);
% end
% for k=2:N
%     for i=1:sys.L
%         x_e3{i}(:,k)=sys.subsystems{i}.A*x_e3{i}(:,k-1)+u(sys.part_x{i},k);
%         for j=1:sys.subsystems{i}.number_neighbor
%             x_e3{i}(:,k)=x_e3{i}(:,k)+sys.subsystems{i}.A_neighbor{j}*x_e3{sys.subsystems{i}.neighbor(j)}(:,k-1);
%         end
%         P_predict=F*P_EKF*F'+Q;
%         K_EKF=P_predict*H'/(H*P_predict*H'+R);
%         P_EKF=P_predict-P_predict*H'/(H*P_predict*H'+R)*H*P_predict;
%         x_e3{i}(:,k)=x_e3{i}(:,k)+K{i}(:,:,k)*(y{i}(:,k)-sys.subsystems{i}.C*x_e1{i}(:,k));
%         err3{i}(:,k)=x{i}(:,k)-x_e3{i}(:,k);
%         se3{i}(k)=err3{i}(:,k)'*err3{i}(:,k);
%     end
% end

%% Centralized
for i=1:sys.L
    x_e4(:,1)=zeros(sys.dim_x,1);
end
for k=2:N
    x_e4(:,k)=sys.A*x_e4(:,k-1)+u(:,k);
    C_temp=mdiag(1,[1 0 0 0;0 0 1 0],[1 0 0 0;0 0 1 0;1 0 0 0;0 0 1 0],1,[1 0 0 0;0 0 1 0],[1 0 0 0;0 0 1 0]);
    K3(:,:,k)=GainCentralized(sys.A,sys.B,C_temp,eye(12));
    x_e4(:,k)=x_e4(:,k)+K3(:,:,k)*(y(:,k)-C_temp*x_e4(:,k));
%     err1{i}(:,k)=x{i}(:,k)-x_e1{i}(:,k);
%     se1{i}(k)=err1{i}(:,k)'*err1{i}(:,k);
end


%% Plot
% figure(1)
% subplot(2,1,1);
% hold on;
% plot(1:N,x_c(2,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{1}(2,1:N),'r.-','LineWidth',2);
% subplot(2,1,2);
% hold on;
% plot(1:N,x_c(4,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{1}(4,1:N),'r.-','LineWidth',2);
% 
% figure(2)
% subplot(2,1,1);
% hold on;
% plot(1:N,x_c(7,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{2}(3,1:N),'r.-','LineWidth',2);
% subplot(2,1,2);
% hold on;
% plot(1:N,x_c(11,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{2}(7,1:N),'r.-','LineWidth',2);
% 
% figure(3)
% subplot(2,1,1);
% hold on;
% plot(1:N,x_c(11,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{3}(3,1:N),'r.-','LineWidth',2);
% subplot(2,1,2);
% hold on;
% plot(1:N,x_c(15,1:N),'k-','LineWidth',2);
% plot(1:N,x_e1{3}(7,1:N),'r.-','LineWidth',2);
% 
figure(4)
subplot(2,1,1);
hold on;
plot(1:N,x_c(6,1:N)+5,'k-','LineWidth',2);
plot(1:N,x_e1{1}(6,1:N)+5,'r.-','LineWidth',2);
subplot(2,1,2);
hold on;
plot(1:N,x_c(8,1:N),'k-','LineWidth',2);
plot(1:N,x_e1{1}(8,1:N),'r.-','LineWidth',2);


% figure(1) % control
% subplot(2,4,1);
% plot(1:N,x_c(2,1:N),'k-','LineWidth',2);
% subplot(2,4,2);
% plot(1:N,x_c(4,1:N),'k-','LineWidth',2);
% subplot(2,4,3);
% plot(1:N,x_c(6,1:N),'k-','LineWidth',2);
% subplot(2,4,4);
% plot(1:N,x_c(8,1:N),'k-','LineWidth',2);
% subplot(2,4,5);
% plot(1:N,x_c(11,1:N),'k-','LineWidth',2);
% subplot(2,4,6);
% plot(1:N,x_c(13,1:N),'k-','LineWidth',2);
% subplot(2,4,7);
% plot(1:N,x_c(15,1:N),'k-','LineWidth',2);
% subplot(2,4,8);
% plot(1:N,x_c(17,1:N),'k-','LineWidth',2);