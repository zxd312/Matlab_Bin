function [K_opt] = GainCentralized(A,B,C,D)
n = size(A,1); % ״̬x��ά��
m = size(C,1); % �۲�y_i��ά�� 
z0 = size(B,2); % ����w��ά��
z1 = size(D,2); % ����v_i��ά��
% A=A(t-1)  B=B(t-1)  C=C(t)  D=D(t)

%% ���K
setlmis([])
    P=lmivar(1,[n,1]);  
    kar=lmivar(1,[1,1]);
    [K,nK,sK]=lmivar(2,[n,m]);
    Theta=lmivar(1,[z0+z1,1]); 
    %1st LMI
    lmiterm([1 1 1 0],-1);
    lmiterm([1 1 2 0],A);
    lmiterm([1 1 2 K],-1,C*A);
    lmiterm([1 1 3 0],[B zeros(n,z1)]);
    lmiterm([1 1 3 K],-1,[C*B D]);
    
    lmiterm([1 2 2 P],-1,1);
    
    lmiterm([1 3 3 Theta],-1,1);
    %2nd LMI
    lmiterm([2 1 1 P],1,1);
    lmiterm([-2 1 1 kar],1,eye(n));
    %3rd LMI
    lmiterm([3 1 1 kar],1,1);
    lmiterm([-3 1 1 0],1);
 
lmisys=getlmis;
%LMI ���
n_LMI=decnbr(lmisys);
c_LMI=zeros(1,n_LMI);
for j=1:n_LMI
    [Theta_j]=defcx(lmisys,j,Theta);
    c_LMI(j)=trace(Theta_j);
end
[copt xopt]=mincx(lmisys,c_LMI); % ����н�
K_opt=dec2mat(lmisys,xopt,K) % ��ȡ�����
end

