function nearest_point = findNearestZonotopePoint(x, c, G)
    % 输入:
    %   x: 外部点 (n维列向量)
    %   c: zonotope中心 (n维列向量)
    %   G: zonotope生成矩阵 (n×m矩阵)
    % 输出:
    %   farthest_point: zonotope中距离x最远的点 (n维列向量)
    
    % 使用MPT3工具箱将zonotope转换为多面体
    Z = zonotope(c, G);  % 创建zonotope对象
    % 转换为多面体（H表示）
    P = Polyhedron('A', Z.A, 'b', Z.b); % 使用不等式表示
    % 计算每个顶点到x的距离
    % 计算x到多面体的最近点
    [~, nearest_point]= P.distance(x);
end