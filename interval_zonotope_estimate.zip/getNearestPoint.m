function nearest_point = getNearestPoint(x, c, G)
    Z = zonotope(c, G);
    P = Polyhedron('A', Z.A, 'b', Z.b);
    % 提取多面体约束 A*y ≤ b
    A = P.A;
    b = P.b;
    % 构造二次规划问题: min ||y - x||^2  s.t. A*y ≤ b
    H = 2*eye(size(x,1));  % 二次项矩阵 (Hessian)
    f = -2*x;              % 线性项
    % 调用 quadprog
    options = optimoptions('quadprog', 'Display', 'off');
    y_opt = quadprog(H, f, A, b, [], [], [], [], [], options);
    nearest_point = y_opt;
end