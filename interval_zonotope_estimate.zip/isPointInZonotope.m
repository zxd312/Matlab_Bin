function isInside = isPointInZonotope(x, c, G)
    % 判断向量x是否在由中心c和生成矩阵G定义的Zonotope内
    % 输入:
    %   x: 待判断的向量 (d×1)
    %   c: Zonotope的中心 (d×1)
    %   G: Zonotope的生成矩阵 (d×p)
    % 输出:
    %   isInside: 1（在内部），0（不在内部）

    % 检查输入维度
    if size(x, 1) ~= size(c, 1) || size(c, 1) ~= size(G, 1)
        error('输入维度不匹配！');
    end

    % 构造Zonotope并转换为H-表示（超平面表示）
    Z = zonotope(c, G);
    Z = computeHRep(Z); % 关键修正：必须显式转换为H-表示

    % 转换为MPT3的Polyhedron对象
    Z_poly = Polyhedron('A', Z.A, 'b', Z.b);

    % 判断点是否在多面体内
    isInside = Z_poly.contains(x);

    % 转换为1/0输出
    isInside = double(isInside);
end