function y_decoded = decoder(y_encoded, Rj, bj, qj)
    % y_encoded : 编码索引列向量 (n×1)
    % bj        : 动态范围（标量）
    % Rj, qj    : 比特率与维度（标量）

    M = floor(2^(Rj / qj));      % 区间数
    delta = 2 * bj / M;
    % 对应的区间中心点
    y_decoded = -bj + (y_encoded - 0.5) * delta;
end