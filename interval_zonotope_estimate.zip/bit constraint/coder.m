function C = coder(y, Ri, bi, qi)
    % y     : 输入信号列向量 (n×1)
    % Ri    : 分配的比特率（标量）
    % bi    : 动态范围上限（标量）
    % qi    : 信号维度（标量）
    M = floor(2^(Ri / qi));       % 区间数
    delta = 2 * bi / M;           % 区间宽度
    % 编码为整数索引（从1到M）
    C = floor((y + bi) / delta) + 1;
    % 保证在区间 [1, M] 内
    C(C < 1) = 1;
    C(C > M) = M;
end