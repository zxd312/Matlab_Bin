%% 初始化事件触发参数  %40触发率
d2_1e=1.05;d2_2e=1.05;d2_3e=1.05;
T2_1=zeros(1,N);T2_2=zeros(1,N);T2_3=zeros(1,N);
T2_1(1,1)=1;T2_2(1,1)=1;T2_3(1,1)=1;
yx1=y_1(:,1);  yx2=y_2(:,1);  yx3=y_3(:,1);
yx11=y_1(:,1); yx22=y_2(:,1); yx33=y_3(:,1);
%% 初始协方差矩阵和状态
Rx_1a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rx_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rx_2a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rx_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rx_3a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rx_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
cx_1a{1,1}=[0; v; d; v];            cx_1b{1,1}=cx_1a{1,1};    
cx_2a{1,1}=[d; v; 2*d; v];          cx_2b{1,1}=cx_2a{1,1};
cx_3a{1,1}=[2*d; v; 3*d; v];        cx_3b{1,1}=cx_3a{1,1};
%% 初始化边界
% box半径下的
cx_1a_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);   cx_1b_up(:, 1)=cx_1a_up(:, 1); 
cx_1a_down(:, 1)= x_1(:, 1)-0.01*ones(4,1);  cx_1b_down(:, 1)=cx_1a_down(:, 1);
cx_2a_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);   cx_2b_up(:, 1)=cx_2a_up(:, 1);
cx_2a_down(:, 1)= x_2(:, 1)-0.01*ones(4,1);  cx_2b_down(:, 1)=cx_2a_down(:, 1);
cx_3a_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);   cx_3b_up(:, 1)=cx_3a_up(:, 1);
cx_3a_down(:, 1)= x_3(:, 1)-0.01*ones(4,1);  cx_3b_down(:, 1)=cx_3a_down(:, 1);
% 性能指标
J2_1a(:,1)=0.02^4;J2_2a(:,1)=0.02^4;J2_3a(:,1)=0.02^4;
J2_1b(:,1)=0.02^4;J2_2b(:,1)=0.02^4;J2_3b(:,1)=0.02^4;
num2_1a(:,1)=4; num2_2a(:,1)=4; num2_3a(:,1)=4;
num2_1b(:,1)=4; num2_2b(:,1)=4; num2_3b(:,1)=4;
%% 定义每个事件触发机制的误差矩阵
E2_11=d2_1e*eye(4); E2_22=d2_2e*eye(4); E2_33=d2_3e*eye(4);
%% 消融实验
for t=2:N+1
%% 在F半径下的融合处理
 %第一个估计器的融合中心
 N_11b=[Rx_1b{1,t-1},zeros(4,num2_2b(:,t-1))];
 N_12b=[-C_12intersection*Rx_1b{1,t-1},C_12overlaping*Rx_2b{1,t-1}];
 M_1b(:,:,t-1)=-N_11b*N_12b'*inv(N_12b*N_12b');
 cx_1c{1,t-1}= (eye(4)-M_1b(:,:,t-1)*C_12intersection)*cx_1b{1,t-1} + M_1b(:,:,t-1)*C_12overlaping*cx_2b{1,t-1};
 Rx_1c{1,t-1}= N_11b+M_1b(:,:,t-1)*N_12b; 
 P2_1c(:,t-1) =sum(abs(Rx_1c{1,t-1}), 2);
 J2_1c(:,t-1)=prod(2*P2_1c(:,t-1));
 cx_1c_up(:, t-1)= cx_1c{1,t-1} + P2_1c(:,t-1);
 cx_1c_down(:,t-1)=cx_1c{1,t-1}- P2_1c(:,t-1);
%第二个估计器的融合中心
 N_22b=[Rx_2b{1,t-1},zeros(4,num2_1b(:,t-1)),zeros(4,num2_3b(:,t-1))];
 N_21b=[-C_21intersection*Rx_2b{1,t-1},C_21overlaping*Rx_1b{1,t-1},zeros(2,num2_3b(:,t-1));
        -C_23intersection*Rx_2b{1,t-1},zeros(2,num2_1b(:,t-1)),C_23overlaping*Rx_3b{1,t-1}];
 M_2b(:,:,t-1)=-N_22b*N_21b'*inv(N_21b*N_21b');
 cx_2c{1,t-1}= (eye(4)-M_2b(:,1:2,t-1)*C_21intersection - M_2b(:,3:4,t-1)*C_23intersection)*cx_2b{1,t-1} + M_2b(:,1:2,t-1)*C_21overlaping*cx_1b{1,t-1} + M_2b(:,3:4,t-1)*C_23overlaping*cx_3b{1,t-1};
 Rx_2c{1,t-1}= N_22b+M_2b(:,:,t-1)*N_21b;
 P2_2c(:,t-1) =sum(abs(Rx_2c{1,t-1}), 2);
 J2_2c(:,t-1)=prod(2*P2_2c(:,t-1));
 cx_2c_up(:, t-1)=  cx_2c{1,t-1} + P2_2c(:,t-1);
 cx_2c_down(:, t-1)=cx_2c{1,t-1} - P2_2c(:,t-1);
%第三个估计器的融合中心
 N_33b=[Rx_3b{1,t-1},zeros(4,num2_2b(:,t-1))];
 N_31b=[-C_32intersection*Rx_3b{1,t-1},C_32overlaping*Rx_2b{1,t-1}];
 M_3b(:,:,t-1)=-N_33b*N_31b'*inv(N_31b*N_31b');
 cx_3c{1,t-1}= (eye(4)-M_3b(:,:,t-1)*C_32intersection)*cx_3b{1,t-1} + M_3b(:,:,t-1)*C_32overlaping*cx_2b{1,t-1};
 Rx_3c{1,t-1}= N_33b + M_3b(:,:,t-1)*N_31b;      
 P2_3c(:,t-1) =sum(abs(Rx_3c{1,t-1}), 2);
 J2_3c(:,t-1)=prod(2*P2_3c(:,t-1));
 cx_3c_up(:, t-1)= cx_3c{1,t-1}  +  P2_3c(:,t-1);
 cx_3c_down(:,t-1)=cx_3c{1,t-1}  -  P2_3c(:,t-1);
 %% 融合处理（第一个估计器）
 N_11=[Rx_1a{1,t-1},zeros(4,num2_2a(:,t-1))];
 N_12=[-C_12intersection*Rx_1a{1,t-1},C_12overlaping*Rx_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    cx_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*cx_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*cx_2a{1,t-1};
    Rx_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    P2_1r(:,t-1)=sum(abs(Rx_1r{1,t-1}),2);
    J2_1r(:,t-1)=prod(2*P2_1r(:,t-1));
    cx_1r_up(:, t-1)=  cx_1r{1,t-1} + P2_1r(:,t-1);
    cx_1r_down(:,t-1)= cx_1r{1,t-1}-  P2_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[Rx_2a{1,t-1},zeros(4,num2_1a(:,t-1)),zeros(4,num2_3a(:,t-1))];
  N_21=[-C_21intersection*Rx_2a{1,t-1},C_21overlaping*Rx_1a{1,t-1},zeros(2,num2_3a(:,t-1));
                 -C_23intersection*Rx_2a{1,t-1},zeros(2,num2_1a(:,t-1)),C_23overlaping*Rx_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  cx_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*cx_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*cx_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*cx_3a{1,t-1};
  Rx_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  P2_2r(:,t-1) =sum(abs(Rx_2r{1,t-1}), 2);
  J2_2r(:,t-1)=prod(2*P2_2r(:,t-1));
  cx_2r_up(:, t-1)=  cx_2r{1,t-1} + P2_2r(:,t-1);
  cx_2r_down(:, t-1)=cx_2r{1,t-1} - P2_2r(:,t-1);
%% 融合处理（第三个估计器）
  N_33=[Rx_3a{1,t-1},zeros(4,num2_2a(:,t-1))];
  N_31=[-C_32intersection*Rx_3a{1,t-1},C_32overlaping*Rx_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  cx_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*cx_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*cx_2a{1,t-1};
  Rx_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  P2_3r(:,t-1) =sum(abs(Rx_3r{1,t-1}), 2);
  J2_3r(:,t-1)=prod(2*P2_3r(:,t-1));
  cx_3r_up(:, t-1)=cx_3r{1,t-1}  + P2_3r(:,t-1);
  cx_3r_down(:,t-1)=cx_3r{1,t-1} - P2_3r(:,t-1);
%% 跳出循环
  if t == N+1
      break;  % 立即终止循环
  end
  % 第一个估计器 在F半径下的中心对称多细胞体估计器设计
  cx_1f{1,t}= A_1*cx_1c{1,t-1}+U_1(:,t)+A_12*cx_2b{1,t-1};
  Rx_1f{1,t}= [A_1*Rx_1c{1,t-1},A_12*Rx_2b{1,t-1},QE1];
  % 第一个估计器 中心对称多细胞体估计器设计
  cx_1e{1,t} = A_1*cx_1r{1,t-1}+U_1(:,t)+A_12*cx_2a{1,t-1};
  Rx_1e{1,t}= [A_1*Rx_1r{1,t-1},A_12*Rx_2a{1,t-1},QE1];
% 先使用简单的事件触发来设计
  if  norm(y_1(:,t)-yx1,2) <= d2_1e
      T2_1(1,t)=0;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rx_1f{1,t}*Rx_1f{1,t}'*C_1'*inv(C_1*Rx_1f{1,t}*Rx_1f{1,t}'*C_1' +D_1*RE1*RE1'*D_1'+E2_11*E2_11'+E_1co*E_1co');
      cx_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cx_1f{1,t} + K_1b(:,:,t)*yx11;
      Rx_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rx_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*D_1*E_1co,K_1b(:,:,t)*E2_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rx_1e{1,t}, zeros(4,12)];
      Ps1 = [C_1*Rx_1e{1,t},D_1*RE1,-E_1co,-E2_11];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cx_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cx_1e{1,t} + K_1(:,:,t)*yx11;
      Rx_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rx_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co,K_1(:,:,t)*E2_11];
  else
      yx1=y_1(:,t);
      yx11=coder(yx1,R(1),b1,q1);
      yx11=decoder(yx11,R(1),b1,q1);
      T2_1(1,t)=1;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rx_1f{1,t}*Rx_1f{1,t}'*C_1'*inv(C_1*Rx_1f{1,t}*Rx_1f{1,t}'*C_1' + D_1*RE1*RE1'*D_1'+E_1co*E_1co');
      cx_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cx_1f{1,t} + K_1b(:,:,t)*yx11;
      Rx_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rx_1f{1,t},-K_1b(:,:,t)*D_1*RE1,K_1b(:,:,t)*E_1co];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rx_1e{1,t}, zeros(4,8)];
      Ps1 = [C_1*Rx_1e{1,t},D_1*RE1,-E_1co];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cx_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cx_1e{1,t} + K_1(:,:,t)*yx11;
      Rx_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rx_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co];
  end
% F半径下的
    Rx_1b{1,t} = Reduction(Rx_1b{1,t},q);
    num2_1b(:,t)=size(Rx_1b{1,t},2);
    P2_1b =sum(abs(Rx_1b{1,t}),2);
    cx_1b_up(:, t)= cx_1b{1,t}  + P2_1b;
    cx_1b_down(:, t)=cx_1b{1,t} - P2_1b;
    J2_1b(:,t)=prod(2*P2_1b);
    % box半径下的
    Rx_1a{1,t} = Reduction(Rx_1a{1,t},q);
    num2_1a(:,t)=size(Rx_1a{1,t},2);
    P2_1a =sum(abs(Rx_1a{1,t}), 2);
    cx_1a_up(:, t)=  cx_1a{1,t} + P2_1a;
    cx_1a_down(:, t)=cx_1a{1,t} - P2_1a;
    J2_1a(:,t)=prod(2*P2_1a);
    % 第二个估计器  
    % F半径下的
    cx_2f{1,t} = A_2*cx_2c{1,t-1}+A_21*cx_1b{1,t-1}+A_23*cx_3b{1,t-1}+U_2(:,t);           
    Rx_2f{1,t} = [A_2*Rx_2c{1,t-1},A_21*Rx_1b{1,t-1},A_23*Rx_3b{1,t-1},QE2];
    % box下的
    cx_2e{1,t} = A_2*cx_2r{1,t-1}+A_21*cx_1a{1,t-1}+A_23*cx_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    Rx_2e{1,t} = [A_2*Rx_2r{1,t-1}, A_21*Rx_1a{1,t-1},A_23*Rx_3a{1,t-1}, QE2];
    % 先使用简单的事件触发来设计
    if  norm(y_2(:,t)-yx2,2) <= d2_2e
        T2_2(1,t)=0;
    % F半径下的增益矩阵设计
      K_2b(:,:,t)=Rx_2f{1,t}*Rx_2f{1,t}'*C_2'*inv(C_2*Rx_2f{1,t}*Rx_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E2_22*E2_22'+E_2co*E_2co');
      cx_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cx_2f{1,t} + K_2b(:,:,t)*yx22;
      Rx_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rx_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co,K_2b(:,:,t)*E2_22];
        % box下的增益矩阵设计
        Ph2= [Rx_2e{1,t}, zeros(4,12)];
        Ps2 = [C_2*Rx_2e{1,t},D_2*RE2,-E_2co,-E2_22];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cx_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cx_2e{1,t} + K_2(:,:,t)*yx22;
        Rx_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rx_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co,K_2(:,:,t)*E2_22];
    else
        yx2=y_2(:,t);
        yx22=coder(yx2,R(2),b2,q2);
        yx22=decoder(yx22,R(2),b2,q2);
        T2_2(1,t)=1;
        % F半径下的增益矩阵设计
        K_2b(:,:,t)=Rx_2f{1,t}*Rx_2f{1,t}'*C_2'*inv(C_2*Rx_2f{1,t}*Rx_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E_2co*E_2co');
        cx_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cx_2f{1,t} + K_2b(:,:,t)*yx22;
        Rx_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rx_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co];
        % box半径下的增益矩阵设计
        Ph2= [Rx_2e{1,t}, zeros(4,8)];
        Ps2 = [C_2*Rx_2e{1,t},D_2*RE2,-E_2co];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);          % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cx_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cx_2e{1,t} + K_2(:,:,t)*yx22;
        Rx_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rx_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co];
    end
      % F半径指标下
      Rx_2b{1,t} = Reduction(Rx_2b{1,t},q);
      num2_2b(:,t)=size(Rx_2b{1,t},2);
      P2_2b =sum(abs(Rx_2b{1,t}), 2);
      cx_2b_up(:, t)= cx_2b{1,t} + P2_2b;
      cx_2b_down(:, t)=cx_2b{1,t}- P2_2b;
      J2_2b(:,t)=prod(2*P2_2b);
      % box指标下
      Rx_2a{1,t} = Reduction(Rx_2a{1,t},q);
      num2_2a(:,t)=size(Rx_2a{1,t},2);
      P2_2a =sum(abs(Rx_2a{1,t}), 2);
      cx_2a_up(:, t)=  cx_2a{1,t} + P2_2a;
      cx_2a_down(:, t)=cx_2a{1,t} - P2_2a;
      J2_2a(:,t)=prod(2*P2_2a);
     % 第三个估计器
     % F半径下的
      cx_3f{1,t}=A_3*cx_3c{1,t-1} +A_32*cx_2b{1,t-1}+ U_3(:,t) ;
      Rx_3f{1,t}=[A_3*Rx_3c{1,t-1},A_32*Rx_2b{1,t-1}, QE3];
     % box半径下的
      cx_3e{1,t}=A_3*cx_3r{1,t-1} +A_32*cx_2a{1,t-1}+ U_3(:,t) ;
      Rx_3e{1,t}=[A_3*Rx_3r{1,t-1},A_32*Rx_2a{1,t-1}, QE3];
     if  norm(y_3(:,t)-yx3,2) <= d2_3e
        T2_3(1,t)=0;
        % F半径下的增益矩阵设计
        K_3b(:,:,t)=Rx_3f{1,t}*Rx_3f{1,t}'*C_3'*inv(C_3*Rx_3f{1,t}*Rx_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3*+E2_33*E2_33'+E_3co*E_3co');
        cx_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cx_3f{1,t} + K_3b(:,:,t)*yx33;
        Rx_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rx_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co,K_3b(:,:,t)*E2_33];
        % box半径下的增益矩阵设计
        Ph3= [Rx_3e{1,t}, zeros(4,12)];
        Ps3 = [C_3*Rx_3e{1,t},D_3*RE3,-E_3co,-E2_33];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);      % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cx_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cx_3e{1,t} + K_3(:,:,t)*yx33;
        Rx_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rx_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co,K_3(:,:,t)*E2_33];
    else
        yx3=y_3(:,t);
        yx33=coder(yx3,R(3),b3,q3);
        yx33=decoder(yx33,R(3),b3,q3);
        T2_3(1,t)=1;
       % F半径下的性能指标设计
        K_3b(:,:,t)=Rx_3f{1,t}*Rx_3f{1,t}'*C_3'*inv(C_3*Rx_3f{1,t}*Rx_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3'+E_3co*E_3co');
        cx_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cx_3f{1,t} + K_3b(:,:,t)*yx33;
        Rx_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rx_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co];
        % box半径下的性能指标设计
        Ph3= [Rx_3e{1,t}, zeros(4,8)];
        Ps3 = [C_3*Rx_3e{1,t},D_3*RE3,-E_3co];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);         % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cx_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cx_3e{1,t} + K_3(:,:,t)*yx33;
        Rx_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rx_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co];
    end
 %% F半径下的
    Rx_3b{1,t} = Reduction(Rx_3b{1,t},q);
    num2_3b(:,t)=size(Rx_3b{1,t},2);
    P2_3b =sum(abs(Rx_3b{1,t}), 2);
    cx_3b_up(:, t)= cx_3b{1,t} + P2_3b;
    cx_3b_down(:, t)=cx_3b{1,t}- P2_3b;
    J2_3b(:,t)=prod(2*P2_3b);
    %% box半径下的
    Rx_3a{1,t} = Reduction(Rx_3a{1,t},q);
    num2_3a(:,t)=size(Rx_3a{1,t},2);
    P2_3a =sum(abs(Rx_3a{1,t}), 2);
    cx_3a_up(:, t)= cx_3a{1,t} + P2_3a;
    cx_3a_down(:, t)=cx_3a{1,t}- P2_3a;
    J2_3a(:,t)=prod(2*P2_3a);
end


sum(T2_1);
sum(T2_2);
sum(T2_3);
%% 估计图
plot(1:N, x_2(4, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N, cx_2a_up(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, cx_2a_down(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, cx_2r_up(4, :), 'b', 'LineWidth', 1.5);
plot(1:N, cx_2r_down(4, :), 'b', 'LineWidth', 1.5);
legend('真实值','估计值的上界','估计值的下界','融合值的上界','融合值的下界' );