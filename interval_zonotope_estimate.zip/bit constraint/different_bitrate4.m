%% 初始化事件触发参数  %20触发率
d3_1e=2.3;d3_2e=2.3;d3_3e=2.3;
T3_1=zeros(1,N);T3_2=zeros(1,N);T3_3=zeros(1,N);
T3_1(1,1)=1;T3_2(1,1)=1;T3_3(1,1)=1;
ym1=y_1(:,1);  ym2=y_2(:,1);  ym3=y_3(:,1);
ym11=y_1(:,1); ym22=y_2(:,1); ym33=y_3(:,1);
%% 初始协方差矩阵和状态
Rm_1a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rm_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rm_2a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rm_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rm_3a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rm_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
cm_1a{1,1}=[0; v; d; v];            cm_1b{1,1}=cx_1a{1,1};    
cm_2a{1,1}=[d; v; 2*d; v];          cm_2b{1,1}=cx_2a{1,1};
cm_3a{1,1}=[2*d; v; 3*d; v];        cm_3b{1,1}=cx_3a{1,1};
%% 初始化边界
% box半径下的
cm_1a_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);   cm_1b_up(:, 1)=cm_1a_up(:, 1); 
cm_1a_down(:, 1)= x_1(:, 1)-0.01*ones(4,1);  cm_1b_down(:, 1)=cm_1a_down(:, 1);
cm_2a_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);   cm_2b_up(:, 1)=cm_2a_up(:, 1);
cm_2a_down(:, 1)= x_2(:, 1)-0.01*ones(4,1);  cm_2b_down(:, 1)=cm_2a_down(:, 1);
cm_3a_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);   cm_3b_up(:, 1)=cm_3a_up(:, 1);
cm_3a_down(:, 1)= x_3(:, 1)-0.01*ones(4,1);  cm_3b_down(:, 1)=cm_3a_down(:, 1);
% 性能指标
J3_1a(:,1)=0.02^4;J3_2a(:,1)=0.02^4;J3_3a(:,1)=0.02^4;
J3_1b(:,1)=0.02^4;J3_2b(:,1)=0.02^4;J3_3b(:,1)=0.02^4;
num3_1a(:,1)=4; num3_2a(:,1)=4; num3_3a(:,1)=4;
num3_1b(:,1)=4; num3_2b(:,1)=4; num3_3b(:,1)=4;
%% 定义每个事件触发机制的误差矩阵
E3_11=d3_1e*eye(4); E3_22=d3_2e*eye(4); E3_33=d3_3e*eye(4);
%% 消融实验
for t=2:N+1
%% 在F半径下的融合处理
 %第一个估计器的融合中心
 N_11b=[Rm_1b{1,t-1},zeros(4,num3_2b(:,t-1))];
 N_12b=[-C_12intersection*Rm_1b{1,t-1},C_12overlaping*Rm_2b{1,t-1}];
 M_1b(:,:,t-1)=-N_11b*N_12b'*inv(N_12b*N_12b');
 cm_1c{1,t-1}= (eye(4)-M_1b(:,:,t-1)*C_12intersection)*cm_1b{1,t-1} + M_1b(:,:,t-1)*C_12overlaping*cm_2b{1,t-1};
 Rm_1c{1,t-1}= N_11b+M_1b(:,:,t-1)*N_12b; 
 P3_1c(:,t-1) =sum(abs(Rm_1c{1,t-1}), 2);
 J3_1c(:,t-1)=prod(2*P3_1c(:,t-1));
 cm_1c_up(:, t-1)= cm_1c{1,t-1} + P3_1c(:,t-1);
 cm_1c_down(:,t-1)=cm_1c{1,t-1}- P3_1c(:,t-1);
%第二个估计器的融合中心
 N_22b=[Rm_2b{1,t-1},zeros(4,num3_1b(:,t-1)),zeros(4,num3_3b(:,t-1))];
 N_21b=[-C_21intersection*Rm_2b{1,t-1},C_21overlaping*Rm_1b{1,t-1},zeros(2,num3_3b(:,t-1));
        -C_23intersection*Rm_2b{1,t-1},zeros(2,num3_1b(:,t-1)),C_23overlaping*Rm_3b{1,t-1}];
 M_2b(:,:,t-1)=-N_22b*N_21b'*inv(N_21b*N_21b');
 cm_2c{1,t-1}= (eye(4)-M_2b(:,1:2,t-1)*C_21intersection - M_2b(:,3:4,t-1)*C_23intersection)*cm_2b{1,t-1} + M_2b(:,1:2,t-1)*C_21overlaping*cm_1b{1,t-1} + M_2b(:,3:4,t-1)*C_23overlaping*cm_3b{1,t-1};
 Rm_2c{1,t-1}= N_22b+M_2b(:,:,t-1)*N_21b;
 P3_2c(:,t-1) =sum(abs(Rm_2c{1,t-1}), 2);
 J3_2c(:,t-1)=prod(2*P3_2c(:,t-1));
 cm_2c_up(:, t-1)=  cm_2c{1,t-1} + P3_2c(:,t-1);
 cm_2c_down(:, t-1)=cm_2c{1,t-1} - P3_2c(:,t-1);
%第三个估计器的融合中心
 N_33b=[Rm_3b{1,t-1},zeros(4,num3_2b(:,t-1))];
 N_31b=[-C_32intersection*Rm_3b{1,t-1},C_32overlaping*Rm_2b{1,t-1}];
 M_3b(:,:,t-1)=-N_33b*N_31b'*inv(N_31b*N_31b');
 cm_3c{1,t-1}= (eye(4)-M_3b(:,:,t-1)*C_32intersection)*cm_3b{1,t-1} + M_3b(:,:,t-1)*C_32overlaping*cm_2b{1,t-1};
 Rm_3c{1,t-1}= N_33b + M_3b(:,:,t-1)*N_31b;      
 P3_3c(:,t-1) =sum(abs(Rm_3c{1,t-1}), 2);
 J3_3c(:,t-1)=prod(2*P3_3c(:,t-1));
 cm_3c_up(:, t-1)= cm_3c{1,t-1}  +  P3_3c(:,t-1);
 cm_3c_down(:,t-1)=cm_3c{1,t-1}  -  P3_3c(:,t-1);
 %% 融合处理（第一个估计器）
 N_11=[Rm_1a{1,t-1},zeros(4,num3_2a(:,t-1))];
 N_12=[-C_12intersection*Rm_1a{1,t-1},C_12overlaping*Rm_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    cm_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*cm_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*cm_2a{1,t-1};
    Rm_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    P3_1r(:,t-1)=sum(abs(Rm_1r{1,t-1}),2);
    J3_1r(:,t-1)=prod(2*P3_1r(:,t-1));
    cm_1r_up(:, t-1)=  cm_1r{1,t-1} + P3_1r(:,t-1);
    cm_1r_down(:,t-1)= cm_1r{1,t-1}-  P3_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[Rm_2a{1,t-1},zeros(4,num3_1a(:,t-1)),zeros(4,num3_3a(:,t-1))];
  N_21=[-C_21intersection*Rm_2a{1,t-1},C_21overlaping*Rm_1a{1,t-1},zeros(2,num3_3a(:,t-1));
                 -C_23intersection*Rm_2a{1,t-1},zeros(2,num3_1a(:,t-1)),C_23overlaping*Rm_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  cm_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*cm_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*cm_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*cm_3a{1,t-1};
  Rm_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  P3_2r(:,t-1) =sum(abs(Rm_2r{1,t-1}), 2);
  J3_2r(:,t-1)=prod(2*P3_2r(:,t-1));
  cm_2r_up(:, t-1)=  cm_2r{1,t-1} + P3_2r(:,t-1);
  cm_2r_down(:, t-1)=cm_2r{1,t-1} - P3_2r(:,t-1);
%% 融合处理（第三个估计器）
  N_33=[Rm_3a{1,t-1},zeros(4,num3_2a(:,t-1))];
  N_31=[-C_32intersection*Rm_3a{1,t-1},C_32overlaping*Rm_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  cm_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*cm_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*cm_2a{1,t-1};
  Rm_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  P3_3r(:,t-1) =sum(abs(Rm_3r{1,t-1}), 2);
  J3_3r(:,t-1)=prod(2*P3_3r(:,t-1));
  cm_3r_up(:, t-1)=cm_3r{1,t-1}  + P3_3r(:,t-1);
  cm_3r_down(:,t-1)=cm_3r{1,t-1} - P3_3r(:,t-1);
%% 跳出循环
  if t == N+1
      break;  % 立即终止循环
  end
  % 第一个估计器 在F半径下的中心对称多细胞体估计器设计
  cm_1f{1,t}= A_1*cm_1c{1,t-1}+U_1(:,t)+A_12*cm_2b{1,t-1};
  Rm_1f{1,t}= [A_1*Rm_1c{1,t-1},A_12*Rm_2b{1,t-1},QE1];
  % 第一个估计器 中心对称多细胞体估计器设计
  cm_1e{1,t} = A_1*cm_1r{1,t-1}+U_1(:,t)+A_12*cm_2a{1,t-1};
  Rm_1e{1,t}= [A_1*Rm_1r{1,t-1},A_12*Rm_2a{1,t-1},QE1];
% 先使用简单的事件触发来设计
  if  norm(y_1(:,t)-ym1,2) <= d3_1e
      T3_1(1,t)=0;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rm_1f{1,t}*Rm_1f{1,t}'*C_1'*inv(C_1*Rm_1f{1,t}*Rm_1f{1,t}'*C_1' +D_1*RE1*RE1'*D_1'+E3_11*E3_11'+E_1co*E_1co');
      cm_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cm_1f{1,t} + K_1b(:,:,t)*ym11;
      Rm_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rm_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*D_1*E_1co,K_1b(:,:,t)*E3_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rm_1e{1,t}, zeros(4,12)];
      Ps1 = [C_1*Rm_1e{1,t},D_1*RE1,-E_1co,-E3_11];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cm_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cm_1e{1,t} + K_1(:,:,t)*ym11;
      Rm_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rm_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co,K_1(:,:,t)*E3_11];
  else
      ym1=y_1(:,t);
      ym11=coder(ym1,R(1),b1,q1);
      ym11=decoder(ym11,R(1),b1,q1);
      T3_1(1,t)=1;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rm_1f{1,t}*Rm_1f{1,t}'*C_1'*inv(C_1*Rm_1f{1,t}*Rm_1f{1,t}'*C_1' + D_1*RE1*RE1'*D_1'+E_1co*E_1co');
      cm_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cm_1f{1,t} + K_1b(:,:,t)*ym11;
      Rm_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rm_1f{1,t},-K_1b(:,:,t)*D_1*RE1,K_1b(:,:,t)*E_1co];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rm_1e{1,t}, zeros(4,8)];
      Ps1 = [C_1*Rm_1e{1,t},D_1*RE1,-E_1co];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cm_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cm_1e{1,t} + K_1(:,:,t)*ym11;
      Rm_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rm_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co];
  end
% F半径下的
    Rm_1b{1,t} = Reduction(Rm_1b{1,t},q);
    num3_1b(:,t)=size(Rm_1b{1,t},2);
    P3_1b =sum(abs(Rm_1b{1,t}),2);
    cm_1b_up(:, t)= cm_1b{1,t}  + P3_1b;
    cm_1b_down(:, t)=cm_1b{1,t} - P3_1b;
    J3_1b(:,t)=prod(2*P3_1b);
    % box半径下的
    Rm_1a{1,t} = Reduction(Rm_1a{1,t},q);
    num3_1a(:,t)=size(Rm_1a{1,t},2);
    P3_1a =sum(abs(Rm_1a{1,t}), 2);
    cm_1a_up(:, t)=  cm_1a{1,t} + P3_1a;
    cm_1a_down(:, t)=cm_1a{1,t} - P3_1a;
    J3_1a(:,t)=prod(2*P3_1a);
    % 第二个估计器  
    % F半径下的
    cm_2f{1,t} = A_2*cm_2c{1,t-1}+A_21*cm_1b{1,t-1}+A_23*cm_3b{1,t-1}+U_2(:,t);           
    Rm_2f{1,t} = [A_2*Rm_2c{1,t-1},A_21*Rm_1b{1,t-1},A_23*Rm_3b{1,t-1},QE2];
    % box下的
    cm_2e{1,t} = A_2*cm_2r{1,t-1}+A_21*cm_1a{1,t-1}+A_23*cm_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    Rm_2e{1,t} = [A_2*Rm_2r{1,t-1}, A_21*Rm_1a{1,t-1},A_23*Rm_3a{1,t-1}, QE2];
    % 先使用简单的事件触发来设计
    if  norm(y_2(:,t)-ym2,2) <= d3_2e
        T3_2(1,t)=0;
    % F半径下的增益矩阵设计
      K_2b(:,:,t)=Rm_2f{1,t}*Rm_2f{1,t}'*C_2'*inv(C_2*Rm_2f{1,t}*Rm_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E3_22*E3_22'+E_2co*E_2co');
      cm_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cm_2f{1,t} + K_2b(:,:,t)*ym22;
      Rm_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rm_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co,K_2b(:,:,t)*E3_22];
        % box下的增益矩阵设计
        Ph2= [Rm_2e{1,t}, zeros(4,12)];
        Ps2 = [C_2*Rm_2e{1,t},D_2*RE2,-E_2co,-E3_22];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cm_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cm_2e{1,t} + K_2(:,:,t)*ym22;
        Rm_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rm_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co,K_2(:,:,t)*E3_22];
    else
        ym2=y_2(:,t);
        ym22=coder(ym2,R(2),b2,q2);
        ym22=decoder(ym22,R(2),b2,q2);
        T3_2(1,t)=1;
        % F半径下的增益矩阵设计
        K_2b(:,:,t)=Rm_2f{1,t}*Rm_2f{1,t}'*C_2'*inv(C_2*Rm_2f{1,t}*Rm_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E_2co*E_2co');
        cm_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cm_2f{1,t} + K_2b(:,:,t)*ym22;
        Rm_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rm_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co];
        % box半径下的增益矩阵设计
        Ph2= [Rm_2e{1,t}, zeros(4,8)];
        Ps2 = [C_2*Rm_2e{1,t},D_2*RE2,-E_2co];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);          % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cm_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cm_2e{1,t} + K_2(:,:,t)*ym22;
        Rm_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rm_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co];
    end
      % F半径指标下
      Rm_2b{1,t} = Reduction(Rm_2b{1,t},q);
      num3_2b(:,t)=size(Rm_2b{1,t},2);
      P3_2b =sum(abs(Rm_2b{1,t}), 2);
      cm_2b_up(:, t)= cm_2b{1,t} + P3_2b;
      cm_2b_down(:, t)=cm_2b{1,t}- P3_2b;
      J3_2b(:,t)=prod(2*P3_2b);
      % box指标下
      Rm_2a{1,t} = Reduction(Rm_2a{1,t},q);
      num3_2a(:,t)=size(Rm_2a{1,t},2);
      P3_2a =sum(abs(Rm_2a{1,t}), 2);
      cm_2a_up(:, t)=  cm_2a{1,t} + P3_2a;
      cm_2a_down(:, t)=cm_2a{1,t} - P3_2a;
      J3_2a(:,t)=prod(2*P3_2a);
     % 第三个估计器
     % F半径下的
      cm_3f{1,t}=A_3*cm_3c{1,t-1} +A_32*cm_2b{1,t-1}+ U_3(:,t) ;
      Rm_3f{1,t}=[A_3*Rm_3c{1,t-1},A_32*Rm_2b{1,t-1}, QE3];
     % box半径下的
      cm_3e{1,t}=A_3*cm_3r{1,t-1} +A_32*cm_2a{1,t-1}+ U_3(:,t) ;
      Rm_3e{1,t}=[A_3*Rm_3r{1,t-1},A_32*Rm_2a{1,t-1}, QE3];
     if  norm(y_3(:,t)-ym3,2) <= d3_3e
        T3_3(1,t)=0;
        % F半径下的增益矩阵设计
        K_3b(:,:,t)=Rm_3f{1,t}*Rm_3f{1,t}'*C_3'*inv(C_3*Rm_3f{1,t}*Rm_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3*+E3_33*E3_33'+E_3co*E_3co');
        cm_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cm_3f{1,t} + K_3b(:,:,t)*ym33;
        Rm_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rm_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co,K_3b(:,:,t)*E3_33];
        % box半径下的增益矩阵设计
        Ph3= [Rm_3e{1,t}, zeros(4,12)];
        Ps3 = [C_3*Rm_3e{1,t},D_3*RE3,-E_3co,-E3_33];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);      % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cm_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cm_3e{1,t} + K_3(:,:,t)*ym33;
        Rm_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rm_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co,K_3(:,:,t)*E3_33];
    else
        ym3=y_3(:,t);
        ym33=coder(ym3,R(3),b3,q3);
        ym33=decoder(ym33,R(3),b3,q3);
        T3_3(1,t)=1;
       % F半径下的性能指标设计
        K_3b(:,:,t)=Rm_3f{1,t}*Rm_3f{1,t}'*C_3'*inv(C_3*Rm_3f{1,t}*Rm_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3'+E_3co*E_3co');
        cm_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cm_3f{1,t} + K_3b(:,:,t)*ym33;
        Rm_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rm_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co];
        % box半径下的性能指标设计
        Ph3= [Rm_3e{1,t}, zeros(4,8)];
        Ps3 = [C_3*Rm_3e{1,t},D_3*RE3,-E_3co];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);         % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cm_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cm_3e{1,t} + K_3(:,:,t)*ym33;
        Rm_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rm_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co];
    end
 %% F半径下的
    Rm_3b{1,t} = Reduction(Rm_3b{1,t},q);
    num3_3b(:,t)=size(Rm_3b{1,t},2);
    P3_3b =sum(abs(Rm_3b{1,t}), 2);
    cm_3b_up(:, t)= cm_3b{1,t} + P3_3b;
    cm_3b_down(:, t)=cm_3b{1,t}- P3_3b;
    J3_3b(:,t)=prod(2*P3_3b);
    %% box半径下的
    Rm_3a{1,t} = Reduction(Rm_3a{1,t},q);
    num3_3a(:,t)=size(Rm_3a{1,t},2);
    P3_3a =sum(abs(Rm_3a{1,t}), 2);
    cm_3a_up(:, t)= cm_3a{1,t} + P3_3a;
    cm_3a_down(:, t)=cm_3a{1,t}- P3_3a;
    J3_3a(:,t)=prod(2*P3_3a);
end
%% 触发率校正
sum(T3_1);
sum(T3_2);
sum(T3_3);
%% 估计图
plot(1:N, x_1(4, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N, cm_1a_up(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, cm_1a_down(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, cm_1r_up(4, :), 'b', 'LineWidth', 1.5);
plot(1:N, cm_1r_down(4, :), 'b', 'LineWidth', 1.5);
legend('真实值','估计值的上界','估计值的下界','融合值的上界','融合值的下界' );