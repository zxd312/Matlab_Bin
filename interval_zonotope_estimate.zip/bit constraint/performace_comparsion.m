%% 事件触发 + bit constraint + zonotope fusion 
clc
clear
close all;
N=50;   % Time steps
numbers=4; 
d=1;    %init position
v=0.1;  %init velocity
q=16;    %Reduction
%% Overall System
k=2;
c=2;
Ts=0.05;
% car quality
for i = 1:numbers
   m(i) = 10 + 5 * rand;
end
% 定义 A 矩阵
A = [0, 1, 0, 0, 0, 0, 0, 0;
    -k/m(1), -c/m(1), k/m(1), c/m(1), 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0;
    k/m(2), c/m(2), -2*k/m(2), -2*c/m(2), k/m(2), c/m(2), 0, 0;             
    0, 0, 0, 0, 0, 1, 0, 0;
    0, 0, k/m(3), c/m(3), -2*k/m(3), -2*c/m(3), k/m(3), c/m(3);
    0, 0, 0, 0, 0, 0, 0, 1;
    0, 0, 0, 0, k/m(4), c/m(4), -2*k/m(4), -2*c/m(4)];
%% 定义重叠部分的索引矩阵(直接定义重叠索引矩阵即可)
C_12overlaping= [eye(2,2),zeros(2,2)];   C_12intersection=[zeros(2,2),eye(2,2)]; 
C_21overlaping= [zeros(2,2),eye(2,2)];   C_23overlaping= [eye(2,2),zeros(2,2)];  
C_21intersection=[eye(2,2),zeros(2,2)];  C_23intersection=[zeros(2,2),eye(2,2)]; 
C_32overlaping= [zeros(2,2),eye(2,2)];   C_32intersection= [eye(2,2),zeros(2,2)];
%% 定义非重叠部分的矩阵
C_1nonoverlap=[eye(2,2),zeros(2,2)]; 
C_23nonoverlap=[eye(2,2),zeros(2,2)]; 
C_21nonoverlap=[zeros(2,2),eye(2,2)]; 
C_3nonoverlap=[zeros(2,2),eye(2,2)]; 
%% block discretization
%  block
A_1d=A(1:2,1:2);A_12d=A(1:2,3:4);
A_2d=A(3:4,3:4);A_21d=A(3:4,1:2);A_23d=A(3:4,5:6);
A_3d=A(5:6,5:6);A_32d=A(5:6,3:4);A_34d=A(5:6,7:8);
A_4d=A(7:8,7:8);A_43d=A(7:8,5:6);
U_11=[0;1/m(1)];U_22=[0;1/m(2)];
U_33=[0;1/m(3)];U_44=[0;1/m(4)];
% discretization
A_1b = expm(A_1d*Ts);
fun_12 = @(t) expm(A_1d*t) * A_12d;
A_12b = integral(fun_12, 0, Ts, 'ArrayValued', true);
A_2b = expm(A_2d * Ts);
fun_21 = @(t) expm(A_2d*t) * A_21d;
A_21b = integral(fun_21, 0, Ts, 'ArrayValued', true);
fun_23 = @(t) expm(A_2d*t) * A_23d;
A_23b = integral(fun_23, 0, Ts, 'ArrayValued', true);
A_3b = expm(A_3d * Ts);
fun_32 = @(t) expm(A_3d * t) * A_32d;
A_32b = integral(fun_32, 0, Ts, 'ArrayValued', true);
fun_34 = @(t) expm(A_3d * t) * A_34d;
A_34b = integral(fun_34, 0, Ts, 'ArrayValued', true);
A_4b = expm(A_4d * Ts);
fun_43 = @(t) expm(A_4d * t) * A_43d;
A_43b = integral(fun_43, 0, Ts, 'ArrayValued', true);
A_1=[A_1b,A_12b;A_21b,A_2b];
A_12=[zeros(2,4);zeros(2,2),A_23b];
A_2=[A_2b,A_23b;A_32b,A_3b];
A_21=[A_21b,zeros(2,2);zeros(2,2),zeros(2,2)];
A_23=[zeros(2,2),zeros(2,2);zeros(2,2),A_34b];
A_3=[A_3b,A_34b;A_43b,A_4b];
A_32=[A_32b,zeros(2,2);zeros(2,2),zeros(2,2)];
%% 系统矩阵
C=eye(2);C_1=mdiag(C,C);
C_2=mdiag(C,C);C_3=mdiag(C,C); 
%% 噪声协方差矩阵调整
Q_1 = diag([0.25, 0.25]); % 过程噪声的协方差矩阵
Q_2 = diag([0.25, 0.25]);
Q_3 = diag([0.25, 0.25]);
Q_4 = diag([0.25, 0.25]);
R_1 = diag([0.1, 0.1]); 
R_2high = diag([0.1, 0.1]);% 观测噪声协方差
R_2 = diag([0.25, 0.25]);
R_3 = diag([0.25, 0.25]);
R_3high = diag([0.1, 0.1]);
R_4 = diag([0.1, 0.1]);
QE1=mdiag(Q_1,Q_2);
QE2=mdiag(Q_2,Q_3);
QE3=mdiag(Q_3,Q_4);
RE1=mdiag(R_1,R_2high);
RE2=mdiag(R_2,R_3);
RE3=mdiag(R_3high,R_4);
%% 生成噪声的中心对称多细胞体
w_1= 0.5*rand(2,N)-0.25;
w_2= 0.5*rand(2,N)-0.25;
w_3= 0.5*rand(2,N)-0.25;
w_4= 0.5*rand(2,N)-0.25;
v_1= 0.2*rand(2,N)-0.1;
v_2high=0.2*rand(2,N)-0.1;
v_2= 0.5*rand(2,N)-0.25;
v_3= 0.5*rand(2,N)-0.25;
v_3high=0.2*rand(2,N)-0.1;
v_4= 0.2*rand(2,N)-0.1;
WE1=[w_1;w_2]; 
WE2=[w_2;w_3]; 
WE3=[w_3;w_4];
VE1=[v_1;v_2high];
VE2=[v_2;v_3];
VE3=[v_3high;v_4];
%% 初始协方差矩阵和状态
R_1a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_1e{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_1f{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_2a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_2e{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_2f{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_3a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_3e{1,1}=diag([0.01, 0.01, 0.01, 0.01]);R_3f{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
c_1a{1,1}=[0; v; d; v];     c_1e{1,1}=[0; v; d; v];     
c_2a{1,1}=[d; v; 2*d; v];   c_2e{1,1}=[d; v; 2*d; v];    
c_3a{1,1}=[2*d; v; 3*d; v]; c_3e{1,1}=[2*d; v; 3*d; v];  
c_1b{1,1}=c_1a{1,1};        c_1f{1,1}=c_1e{1,1};         
c_2b{1,1}=c_2a{1,1};        c_2f{1,1}=c_2e{1,1};         
c_3b{1,1}=c_3a{1,1};        c_3f{1,1}=c_3e{1,1};         
x_1(:, 1)=[0; v; d; v]; x_2(:, 1)=[d; v; 2*d; v]; x_3(:, 1)=[2*d; v; 3*d; v];
%% 初始化边界
% box半径下的
x_1a_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);  x_1r_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);
x_1a_down(:, 1)= x_1(:, 1)-0.01*ones(4,1); x_1r_down(:, 1)= x_1(:, 1)-0.01*ones(4,1);
x_2a_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);  x_2r_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);
x_2a_down(:, 1)= x_2(:, 1)-0.01*ones(4,1); x_2r_down(:, 1)= x_2(:, 1)- 0.01*ones(4,1);
x_3a_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);  x_3r_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);
x_3a_down(:, 1)= x_3(:, 1)-0.01*ones(4,1); x_3r_down(:, 1)= x_3(:, 1)- 0.01*ones(4,1);
% F半径下的
x_1b_up(:, 1)=x_1a_up(:, 1); x_1c_up(:, 1)=x_1r_up(:, 1);
x_1b_down(:, 1)=x_1a_down(:, 1); x_1c_down(:, 1)=x_1r_down(:, 1);
x_2b_up(:, 1)=x_2a_up(:, 1); x_2c_up(:, 1)=x_2r_up(:, 1);
x_2b_down(:, 1)=x_2a_down(:, 1); x_2c_down(:, 1)=x_2r_down(:, 1);
x_3b_up(:, 1)=x_3a_up(:, 1); x_3c_up(:, 1)=x_3r_up(:, 1);
x_3b_down(:, 1)=x_3a_down(:, 1); x_3c_down(:, 1)=x_3r_down(:, 1);
% 性能指标
J_1a(:,1)=0.08;J_2a(:,1)=0.08;J_3a(:,1)=0.08;
J_1b(:,1)=0.08;J_2b(:,1)=0.08;J_3b(:,1)=0.08;
y_1(:,1)=C_1 * x_1(:, 1) + VE1(:, 1);
y_2(:,1)=C_2 * x_2(:, 1) + VE2(:, 1);
y_3(:,1)=C_3 * x_3(:, 1) + VE3(:, 1);
num_1a(:,1)=4; num_2a(:,1)=4; num_3a(:,1)=4;
num_1b(:,1)=4; num_2b(:,1)=4; num_3b(:,1)=4;
%% 初始化事件触发参数
d_1e=0.6;d_2e=0.6;d_3e=0.6;
T_1=zeros(1,N);T_2=zeros(1,N);T_3=zeros(1,N);
T_1(1,1)=1;T_2(1,1)=1;T_3(1,1)=1;
y1=y_1(:,1);  y2=y_2(:,1);  y3=y_3(:,1);
y11=y_1(:,1); y22=y_2(:,1); y33=y_3(:,1);
%% 迭代循环
for t=2:N
 F1(:,t)=5 * rand;  F2(:,t)=5 * rand;
 F3(:,t)=5 * rand;  F4(:,t)=5 * rand;
 u_1(:,t)=F1(:,t)*U_11; u_2(:,t)=F2(:,t)*U_22; u_3(:,t)=F3(:,t)*U_33; u_4(:,t)=F4(:,t)*U_44;
 U_1(:,t)=[u_1(:,t);u_2(:,t)];
 U_2(:,t)=[u_2(:,t);u_3(:,t)];
 U_3(:,t)=[u_3(:,t);u_4(:,t)];
 % 状态更新
 x_1(:, t) = A_1 * x_1(:, t-1) + U_1(:,t) + WE1(:, t) + A_12 * x_2(:, t-1) ;
 x_2(:, t) = A_2 * x_2(:, t-1) + U_2(:,t) + WE2(:, t) + A_21 * x_1(:, t-1) + A_23 * x_3(:, t-1);
 x_3(:, t) = A_3 * x_3(:, t-1) + U_3(:,t) + WE3(:, t) + A_32 * x_2(:, t-1)  ;
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + VE1(:, t);
 y_2(:, t) = C_2 * x_2(:, t) + VE2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + VE3(:, t);  
end
%% 分配带宽 %% 遗传算法来求解bit分配
b1=12;b2=12;b3=12;q1=4;q2=4;q3=4;R_total=66;
b=[b1;b2;b3];q_bit=[q1;q2;q3];
%% 目标函数（连续放缩版本）
objective = @(R) (q_bit(1)*b(1))/floor(2^(R(1)/q_bit(1))) + ...
                 (q_bit(2)*b(2))/floor(2^(R(2)/q_bit(2))) + ...
                 (q_bit(3)*b(3))/floor(2^(R(3)/q_bit(3)));
lb = [1; 1; 1]; ub = [R_total; R_total; R_total];
A = [1, 1, 1];  b_con = R_total;
%% 调用遗传算法求解
intcon = [1, 2, 3];  % 整数约束
options = optimoptions('ga', ...
    'Display', 'iter', ...
    'PopulationSize', 100, ...
    'MaxGenerations', 200);
[R, fval] = ga(objective, 3, A, b_con, [], [], lb, ub, [], intcon, options);
%% 输出结果
fprintf('\n===== 最优解 =====\n');
fprintf('R1 = %d, R2 = %d, R3 = %d\n', R(1), R(2), R(3));
fprintf('目标函数值 = %.4f\n', fval);
fprintf('资源使用量 = %d (总共可用 %d)\n', sum(R), R_total);
%% 各项贡献
term1 = (q_bit(1) * abs(b(1))) / (2^(R(1)/q_bit(1)));
term2 = (q_bit(2) * abs(b(2))) / (2^(R(2)/q_bit(2)));
term3 = (q_bit(3) * abs(b(3))) / (2^(R(3)/q_bit(3)));
fprintf('\n===== 各项贡献 =====\n');
fprintf('第一项: %.4f (R1 = %d, 2^{R1/4} = %.2f)\n', term1, R(1), 2^(R(1)/4));
fprintf('第二项: %.4f (R2 = %d, 2^{R2/4} = %.2f)\n', term2, R(2), 2^(R(2)/4));
fprintf('第三项: %.4f (R3 = %d, 2^{R3/4} = %.2f)\n', term3, R(3), 2^(R(3)/4));
%% 定义每个传感器的量化误差
E_1coder=b1/floor(2^(R(1) /q1));E_2coder=b2/floor(2^(R(2) /q2));E_3coder=b3/floor(2^(R(3) /q3));
E_1co=E_1coder*eye(4);E_2co=E_2coder*eye(4);E_3co=E_3coder*eye(4);
%% 定义每个事件触发机制的误差矩阵
E_11=d_1e*eye(4); E_22=d_2e*eye(4); E_33=d_3e*eye(4);
%% zonotope estimator (a和b e和f c和r)
for t=2:N+1
%% 在F半径下的融合处理
 %第一个估计器的融合中心
 N_11b=[R_1b{1,t-1},zeros(4,num_2b(:,t-1))];
 N_12b=[-C_12intersection*R_1b{1,t-1},C_12overlaping*R_2b{1,t-1}];
 M_1b(:,:,t-1)=-N_11b*N_12b'*inv(N_12b*N_12b');
 c_1c{1,t-1}= (eye(4)-M_1b(:,:,t-1)*C_12intersection)*c_1b{1,t-1} + M_1b(:,:,t-1)*C_12overlaping*c_2b{1,t-1};
 R_1c{1,t-1}= N_11b+M_1b(:,:,t-1)*N_12b; 
 P_1c(:,t-1) =sum(abs(R_1c{1,t-1}), 2);
 J_1c(:,t-1)=2*sum(P_1c(:,t-1));
 x_1c_up(:, t-1)= c_1c{1,t-1} + P_1c(:,t-1);
 x_1c_down(:,t-1)=c_1c{1,t-1}- P_1c(:,t-1);
 %第二个估计器的融合中心
 N_22b=[R_2b{1,t-1},zeros(4,num_1b(:,t-1)),zeros(4,num_3b(:,t-1))];
 N_21b=[-C_21intersection*R_2b{1,t-1},C_21overlaping*R_1b{1,t-1},zeros(2,num_3b(:,t-1));
        -C_23intersection*R_2b{1,t-1},zeros(2,num_1b(:,t-1)),C_23overlaping*R_3b{1,t-1}];
 M_2b(:,:,t-1)=-N_22b*N_21b'*inv(N_21b*N_21b');
 c_2c{1,t-1}= (eye(4)-M_2b(:,1:2,t-1)*C_21intersection - M_2b(:,3:4,t-1)*C_23intersection)*c_2b{1,t-1} + M_2b(:,1:2,t-1)*C_21overlaping*c_1b{1,t-1} + M_2b(:,3:4,t-1)*C_23overlaping*c_3b{1,t-1};
 R_2c{1,t-1}= N_22b+M_2b(:,:,t-1)*N_21b;
 P_2c(:,t-1) =sum(abs(R_2c{1,t-1}), 2);
 J_2c(:,t-1)=2*sum(P_2c(:,t-1));
 x_2c_up(:, t-1)= c_2c{1,t-1} + P_2c(:,t-1);
 x_2c_down(:, t-1)=c_2c{1,t-1}- P_2c(:,t-1);
 %第三个估计器的融合中心
 N_33b=[R_3b{1,t-1},zeros(4,num_2b(:,t-1))];
 N_31b=[-C_32intersection*R_3b{1,t-1},C_32overlaping*R_2b{1,t-1}];
 M_3b(:,:,t-1)=-N_33b*N_31b'*inv(N_31b*N_31b');
 c_3c{1,t-1}= (eye(4)-M_3b(:,:,t-1)*C_32intersection)*c_3b{1,t-1} + M_3b(:,:,t-1)*C_32overlaping*c_2b{1,t-1};
 R_3c{1,t-1}= N_33b + M_3b(:,:,t-1)*N_31b;      
 P_3c(:,t-1) =sum(abs(R_3c{1,t-1}), 2);
 J_3c(:,t-1)=2*sum(P_3c(:,t-1));
 x_3c_up(:, t-1)=c_3c{1,t-1}  + P_3c(:,t-1);
 x_3c_down(:,t-1)=c_3c{1,t-1} - P_3c(:,t-1);
 %% 融合处理（第一个估计器）
 N_11=[R_1a{1,t-1},zeros(4,num_2a(:,t-1))];
 N_12=[-C_12intersection*R_1a{1,t-1},C_12overlaping*R_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    c_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*c_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*c_2a{1,t-1};
    R_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    P_1r(:,t-1) =sum(abs(R_1r{1,t-1}), 2);
    J_1r(:,t-1)=2*sum(P_1r(:,t-1));
    x_1r_up(:, t-1)= c_1r{1,t-1} + P_1r(:,t-1);
    x_1r_down(:,t-1)=c_1r{1,t-1}- P_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[R_2a{1,t-1},zeros(4,num_1a(:,t-1)),zeros(4,num_3a(:,t-1))];
  N_21=[-C_21intersection*R_2a{1,t-1},C_21overlaping*R_1a{1,t-1},zeros(2,num_3a(:,t-1));
                 -C_23intersection*R_2a{1,t-1},zeros(2,num_1a(:,t-1)),C_23overlaping*R_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
  M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  c_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*c_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*c_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*c_3a{1,t-1};
  R_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  P_2r(:,t-1) =sum(abs(R_2r{1,t-1}), 2);
  J_2r(:,t-1)=2*sum(P_2r(:,t-1));
  x_2r_up(:, t-1)= c_2r{1,t-1} + P_2r(:,t-1);
  x_2r_down(:, t-1)=c_2r{1,t-1}- P_2r(:,t-1);
  %% 融合处理（第三个估计器）
  N_33=[R_3a{1,t-1},zeros(4,num_2a(:,t-1))];
  N_31=[-C_32intersection*R_3a{1,t-1},C_32overlaping*R_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  c_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*c_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*c_2a{1,t-1};
  R_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  P_3r(:,t-1) =sum(abs(R_3r{1,t-1}), 2);
  J_3r(:,t-1)=2*sum(P_3r(:,t-1));
  x_3r_up(:, t-1)=c_3r{1,t-1}  + P_3r(:,t-1);
  x_3r_down(:,t-1)=c_3r{1,t-1} - P_3r(:,t-1);
  %% 跳出循环
  if t == N+1
      break;  % 立即终止循环
  end
  % 第一个估计器 在F半径下的中心对称多细胞体估计器设计
  c_1f{1,t} = A_1*c_1c{1,t-1}+U_1(:,t)+A_12*c_2b{1,t-1};
  R_1f{1,t}= [A_1*R_1c{1,t-1},A_12*R_2b{1,t-1},QE1];
  % 第一个估计器 中心对称多细胞体估计器设计
  c_1e{1,t} = A_1*c_1r{1,t-1}+U_1(:,t)+A_12*c_2a{1,t-1};
  R_1e{1,t}= [A_1*R_1r{1,t-1},A_12*R_2a{1,t-1},QE1];
  % 先使用简单的事件触发来设计
  if  norm(y_1(:,t)-y1,2) <= d_1e
      T_1(1,t)=0;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1' + RE1*RE1'+E_11*E_11'+E_1co*E_1co');
      c_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*c_1f{1,t} + K_1b(:,:,t)*y11;
      R_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*E_1co,K_1b(:,:,t)*E_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [R_1e{1,t}, zeros(4,12)];
      Ps1 = [C_1*R_1e{1,t},RE1,-E_1co,-E_11];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      c_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y11;
      R_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*R_1e{1,t},-K_1(:,:,t)*RE1,K_1(:,:,t)*E_1co,K_1(:,:,t)*E_11];
  else
      y1=y_1(:,t);
      y11=coder(y1,R(1),b1,q1);
      y11=decoder(y11,R(1),b1,q1);
      T_1(1,t)=1;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1' + RE1*RE1'+E_11*E_11');
      c_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*c_1f{1,t} + K_1b(:,:,t)*y11;
      R_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*E_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [R_1e{1,t}, zeros(4,8)];
      Ps1 = [C_1*R_1e{1,t},RE1,-E_1co];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      c_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y11;
      R_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*R_1e{1,t},-K_1(:,:,t)*RE1,K_1(:,:,t)*E_1co];
  end
    % F半径下的
    R_1b{1,t} = Reduction(R_1b{1,t},q);
    num_1b(:,t)=size(R_1b{1,t},2);
    P_1b =sum(abs(R_1b{1,t}), 2);
    x_1b_up(:, t)= c_1b{1,t} + P_1b;
    x_1b_down(:, t)=c_1b{1,t}-P_1b;
    J_1b(:,t)=2*sum(P_1b);
    % box半径下的
    R_1a{1,t} = Reduction(R_1a{1,t},q);
    num_1a(:,t)=size(R_1a{1,t},2);
    P_1a =sum(abs(R_1a{1,t}), 2);
    x_1a_up(:, t)= c_1a{1,t} + P_1a;
    x_1a_down(:, t)=c_1a{1,t}-P_1a;
    J_1a(:,t)=2*sum(P_1a);
    % 第二个估计器  
    % F半径下的
    c_2f{1,t} = A_2*c_2c{1,t-1}+A_21*c_1b{1,t-1}+A_23*c_3b{1,t-1}+U_2(:,t);           
    R_2f{1,t} = [A_2*R_2c{1,t-1}, A_21*R_1b{1,t-1},A_23*R_3b{1,t-1}, QE2];
    % box下的
    c_2e{1,t} = A_2*c_2r{1,t-1}+A_21*c_1a{1,t-1}+A_23*c_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    R_2e{1,t} = [A_2*R_2r{1,t-1}, A_21*R_1a{1,t-1},A_23*R_3a{1,t-1}, QE2];
    % 先使用简单的事件触发来设计
    if  norm(y_2(:,t)-y2,2) <= d_2e
        T_2(1,t)=0;
    % F半径下的增益矩阵设计
      K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2' + RE2*RE2'+E_22*E_22'+E_2co*E_2co');
      c_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*c_2f{1,t} + K_2b(:,:,t)*y22;
      R_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*RE2,K_2b(:,:,t)*E_2co,K_2b(:,:,t)*E_22];
        % box下的增益矩阵设计
        Ph2= [R_2e{1,t}, zeros(4,12)];
        Ps2 = [C_2*R_2e{1,t},RE2,-E_2co,-E_22];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        c_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y22;
        R_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*R_2e{1,t},-K_2(:,:,t)*RE2,K_2(:,:,t)*E_2coder,K_2(:,:,t)*E_22];
    else
        y2=y_2(:,t);
        y22=coder(y_2(:,t),R(2),b2,q2);
        y22=decoder(y22,R(2),b2,q2);
        T_2(1,t)=1;
        % F半径下的增益矩阵设计
        K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2' + RE2*RE2'+E_2co*E_2co');
        c_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*c_2f{1,t} + K_2b(:,:,t)*y22;
        R_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*RE2,K_2b(:,:,t)*E_2co];
        % box半径下的增益矩阵设计
        Ph2= [R_2e{1,t}, zeros(4,8)];
        Ps2 = [C_2*R_2e{1,t},RE2,-E_2co];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);          % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        c_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y22;
        R_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*R_2e{1,t},-K_2(:,:,t)*RE2,K_2(:,:,t)*E_2co];
    end
    % F半径指标下
    R_2b{1,t} = Reduction(R_2b{1,t},q);
    num_2b(:,t)=size(R_2b{1,t},2);
    P_2b =sum(abs(R_2b{1,t}), 2);
    x_2b_up(:, t)= c_2b{1,t} + P_2b;
    x_2b_down(:, t)=c_2b{1,t}- P_2b;
    J_2b(:,t)=2*sum(P_2b);
    % box指标下
    R_2a{1,t} = Reduction(R_2a{1,t},q);
    num_2a(:,t)=size(R_2a{1,t},2);
    P_2a =sum(abs(R_2a{1,t}), 2);
    x_2a_up(:, t)= c_2a{1,t} + P_2a;
    x_2a_down(:, t)=c_2a{1,t}- P_2a;
    J_2a(:,t)=2*sum(P_2a);
    % 第三个估计器
    % F半径下的
    c_3f{1,t}=A_3*c_3c{1,t-1} +A_32*c_2b{1,t-1}+ U_3(:,t) ;
    R_3f{1,t}=[A_3*R_3c{1,t-1},A_32*R_2b{1,t-1}, QE3];
    % box半径下的
    c_3e{1,t}=A_3*c_3r{1,t-1} +A_32*c_2a{1,t-1}+ U_3(:,t) ;
    R_3e{1,t}=[A_3*R_3r{1,t-1},A_32*R_2a{1,t-1}, QE3];
    if  norm(y_3(:,t)-y3,2) <= d_3e
        T_3(1,t)=0;
        % F半径下的增益矩阵设计
        K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3' + RE3*RE3'+E_33*E_33'+E_3co*E_3co');
        c_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*c_3f{1,t} + K_3b(:,:,t)*y33;
        R_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*RE3,K_3b(:,:,t)*E_3co,K_3b(:,:,t)*E_33];
        % box半径下的增益矩阵设计
        Ph3= [R_3e{1,t}, zeros(4,12)];
        Ps3 = [C_3*R_3e{1,t},RE3,-E_3co,-E_33];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);      % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        c_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y33;
        R_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*R_3e{1,t},-K_3(:,:,t)*RE3,K_3(:,:,t)*E_3co,K_3(:,:,t)*E_33];
    else
        y3=y_3(:,t);
        y33=coder(y_3(:,t),R(3),b3,q3);
        y33=decoder(y33,R(3),b3,q3);
        T_3(1,t)=1;
       % F半径下的性能指标设计
        K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3' + RE3*RE3'+E_3co*E_3co');
        c_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*c_3f{1,t} + K_3b(:,:,t)*y33;
        R_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*RE3,K_3b(:,:,t)*E_3co];
        % box半径下的性能指标设计
        Ph3= [R_3e{1,t}, zeros(4,8)];
        Ps3 = [C_3*R_3e{1,t},RE3,-E_3co];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);         % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        c_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y33;
        R_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*R_3e{1,t},-K_3(:,:,t)*RE3,K_3(:,:,t)*E_3co];
    end

    %% F半径下的
    R_3b{1,t} = Reduction(R_3b{1,t},q);
    num_3b(:,t)=size(R_3b{1,t},2);
    P_3b =sum(abs(R_3b{1,t}), 2);
    x_3b_up(:, t)= c_3b{1,t} + P_3b;
    x_3b_down(:, t)=c_3b{1,t}- P_3b;
    J_3b(:,t)=2*sum(P_3b);
    %% box半径下的
    R_3a{1,t} = Reduction(R_3a{1,t},q);
    num_3a(:,t)=size(R_3a{1,t},2);
    P_3a =sum(abs(R_3a{1,t}), 2);
    x_3a_up(:, t)= c_3a{1,t} + P_3a;
    x_3a_down(:, t)=c_3a{1,t}- P_3a;
    J_3a(:,t)=2*sum(P_3a);
end
%% 估计图
plot(1:N, x_2(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N, x_2b_up(1, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_2b_down(1, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_2c_up(1, :), 'b', 'LineWidth', 1.5);
plot(1:N, x_2c_down(1, :), 'b', 'LineWidth', 1.5);
legend('真实值','估计值的上界','估计值的下界','融合值的上界','融合值的下界' );
%% 性能指标图
plot(1:N,  log10(J_2b(1, :)), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  log10(J_2a(1, :)), 'r', 'LineWidth', 1.5);
plot(1:N,  log10(J_2c(1, :)), 'g', 'LineWidth', 1.5);
plot(1:N,  log10(J_2r(1, :)), 'b', 'LineWidth', 1.5);
legend('F半径下的','box半径下的','F半径+融合','box半径+融合');
%% 触发率判断
sum(T_1);
sum(T_2);
sum(T_3);
%% 可视化中心对称多细胞体（重写）
section_matrix=[0,1,0,0;0,0,1,0;0,0,0,1];
% 以区间为性能指标下的
zo1=section_matrix*c_2a{1,t};
Zo1=section_matrix*R_2a{1,t};
zo1_r=section_matrix*c_2r{1,t};
Zo1_r=section_matrix*R_2r{1,t};
% 以F半径为性能指标下的
zo2=section_matrix*c_2b{1,t};
Zo2=section_matrix*R_2b{1,t};
zo2_r=section_matrix*c_2c{1,t};
Zo2_r=section_matrix*R_2c{1,t};
%% 绘制三维图像



%%  可视化这个中心对称多细胞体
C_12overlaping= [eye(2,2),zeros(2,2)];   C_12intersection=[zeros(2,2),eye(2,2)];  
z_1a=C_12intersection*c_1a{1,30}; Z_1a=C_12intersection*R_1a{1,30};           
z_1r=C_12intersection*c_1r{1,30}; Z_1r=C_12intersection*R_1r{1,30};   Z_1r= Reduction(Z_1r,16);      
z_21a=C_12overlaping*c_2r{1,30};  Z_21a=C_12overlaping*R_2a{1,30};     
%%  上面是只融合重叠部分，下面这部分是增广之后的融合；
%% 初始协方差矩阵和状态
R_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_1d{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_1c{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_2d{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_2c{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_3d{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
R_3c{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
c_1b{1,1}=[0; v; d; v];     c_1d{1,1}=[0; v; d; v];      c_1c{1,1}=[0; v; d; v];
c_2b{1,1}=[d; v; 2*d; v];   c_2d{1,1}=[d; v; 2*d; v];    c_2c{1,1}=[d; v; 2*d; v];
c_3b{1,1}=[2*d; v; 3*d; v]; c_3d{1,1}=[2*d; v; 3*d; v];  c_3c{1,1}=[2*d; v; 3*d; v];
%% 初始化边界
x_1b_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);  x_1c_up(:, 1)= x_1(:, 1)+ 0.001*ones(4,1);
x_1b_down(:, 1)= x_1(:, 1)-0.01*ones(4,1); x_1c_down(:, 1)= x_1(:, 1)-0.001*ones(4,1);
x_2b_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);  x_2c_up(:, 1)= x_2(:, 1)+ 0.001*ones(4,1);
x_2b_down(:, 1)= x_2(:, 1)-0.01*ones(4,1); x_2c_down(:, 1)= x_2(:, 1)- 0.001*ones(4,1);
x_3b_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);  x_3c_up(:, 1)= x_3(:, 1)+ 0.001*ones(4,1);
x_3b_down(:, 1)= x_3(:, 1)-0.01*ones(4,1); x_3c_down(:, 1)= x_3(:, 1)- 0.001*ones(4,1);
for t=2:N
 % 第一个估计器 中心对称多细胞体估计器设计
 c_1d{1,t} = A_1*c_1c{1,t-1}+U_1(:,t)+A_12*c_2b{1,t-1};
 R_1d{1,t}= [A_1*R_1c{1,t-1},A_12*R_2b{1,t-1},QE1];
 K_1b = R_1d{1,t}*R_1d{1,t}'*C_1'*inv(C_1*R_1d{1,t}*R_1d{1,t}'*C_1' + RE1*RE1');
 c_1b{1,t} = (eye(4)-K_1b*C_1)*c_1d{1,t} + K_1b*y_1(:, t);
 R_1b{1,t} = [(eye(4)-K_1b*C_1)*R_1d{1,t}, -K_1b*RE1];
 R_1b{1,t} = Reduction(R_1b{1,t},q_1);
 P_1b =sum(abs(R_1b{1,t}), 2);
 x_1b_up(:, t)= c_1b{1,t} + P_1b;
 x_1b_down(:, t)=c_1b{1,t}-P_1b;
 J_1b(:,t)=trace(R_1b{1,t}*R_1b{1,t}');
 % 第二个估计器  向1发送
 c_2d{1,t} = A_2*c_2c{1,t-1}+A_21*c_1b{1,t-1}+A_23*c_3b{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
 R_2d{1,t} = [A_2*R_2c{1,t-1}, A_21*R_1b{1,t-1},A_23*R_3b{1,t-1}, QE2];
 K_2b = R_2d{1,t}*R_2d{1,t}'*C_2'* inv(C_2*R_2d{1,t}*R_2d{1,t}'*C_2' + RE2*RE2');
 c_2b{1,t}= (eye(4)-K_2b*C_2)*c_2d{1,t} + K_2b*y_2(:, t);
 R_2b{1,t} = [(eye(4)-K_2b*C_2)*R_2d{1,t},-K_2b*RE2];
 R_2b{1,t} = Reduction(R_2b{1,t},q_2);
 P_2b=sum(abs(R_2b{1,t}), 2);
 J_2b(:,t)=trace(R_2b{1,t}*R_2b{1,t}');
 % 第三个估计器
 c_3d{1,t}=A_3*c_3c{1,t-1} +A_32*c_2b{1,t-1}+ U_3(:,t) ;
 R_3d{1,t}=[A_3*R_3c{1,t-1},A_32*R_2b{1,t-1}, QE3];
 K_3b = R_3d{1,t}*R_3d{1,t}'*C_3'*inv(C_3*R_3d{1,t}*R_3d{1,t}'*C_3' + RE3*RE3') ;
 c_3b{1,t}=(eye(4)-K_3b*C_3)*c_3d{1,t} + K_3b*y_3(:,t);
 R_3b{1,t}=[(eye(4)-K_3b*C_3)*R_3d{1,t},-K_3b*RE3];
 R_3b{1,t} = Reduction(R_3b{1,t},q_3);
 P_3b=sum(abs(R_3b{1,t}), 2);
 J_3b(:,t)=trace(R_3b{1,t}*R_3b{1,t}');
 % 融合的事件触发估计器1
 % 先增广
 c_12b{1,t}=C_1coupling'*C_21coupling*c_2b{1,t} + C_1out'*C_1out*c_1b{1,t};
 R_12b{1,t}=[C_1out'*C_1out*R_1b{1,t},C_1coupling'*C_21coupling*R_2b{1,t}];
 K_12b=R_1b{1,t}*R_1b{1,t}'*inv(R_1b{1,t}*R_1b{1,t}'+R_12b{1,t}*R_12b{1,t}');
 c_1c{1,t}=(eye(4)-K_12b)*c_1b{1,t} + K_12b*c_12b{1,t};
 R_1c{1,t}=[(eye(4)-K_12b)*R_1b{1,t}, K_12b*R_12b{1,t}];
 R_1c{1,t}=Reduction(R_1c{1,t},size(R_1r{1,t},2));
 P_1c=sum(abs(R_1c{1,t}), 2);
 x_1c_up(:, t)=  c_1c{1,t}+P_1c;
 x_1c_down(:, t)=c_1c{1,t}-P_1c;
 J_1c(:,t)=trace(R_1c{1,t}*R_1c{1,t}');
 % 融合的事件触发估计器2
 % 序贯融合 2先与1融合再与3融合 
 c_21b{1,t}=C_21coupling'*C_1coupling*c_1b{1,t} + C_21out'*C_21out*c_2b{1,t};
 R_21b{1,t}=[C_21out'*C_21out*R_2b{1,t},C_21coupling'*C_1coupling*R_1b{1,t}];
 K_21b=R_2b{1,t}*R_2b{1,t}'*inv(R_2b{1,t}*R_2b{1,t}'+ R_21b{1,t}*R_21b{1,t}');
 c_21c{1,t}=(eye(4)-K_21b)*c_2b{1,t} + K_21b*c_21b{1,t};
 R_21c{1,t}=[(eye(4)-K_21b)*R_2b{1,t}, K_21b*R_21b{1,t}];
 % 比较性能指标 （与3的融合）
 c_23b{1,t}=C_23coupling'*C_3coupling*c_3b{1,t} + C_23out'*C_23out*c_21c{1,t};
 R_23b{1,t}=[C_23out'*C_23out*R_21c{1,t},C_23coupling'*C_3coupling*R_3b{1,t}];
 K_23b=R_21c{1,t}*R_21c{1,t}'*inv(R_21c{1,t}*R_21c{1,t}'+R_23b{1,t}*R_23b{1,t}');
 c_2c{1,t}=(eye(4)-K_23b)*c_21c{1,t} + K_23b*c_23b{1,t};
 R_2c{1,t}=[(eye(4)-K_23b)*R_21c{1,t}, K_23b*R_23b{1,t}];
 R_2c{1,t}=Reduction(R_2c{1,t},size(R_2r{1,t},2));
 % 比较性能指标
 J_2c(:,t)=trace(R_2c{1,t}*R_2c{1,t}');
 % 先融合再传输
 P_2c=sum(abs(R_2c{1,t}), 2);
 x_2c_up(:, t)=  c_2c{1,t}+P_2c;
 x_2c_down(:, t)=c_2c{1,t}-P_2c;
 % 融合的事件触发估计器3
 c_32b{1,t}=C_3coupling'*C_23coupling*c_2b{1,t} + C_3out'*C_3out*c_3b{1,t};
 R_32b{1,t}=[C_3out'*C_3out*R_3b{1,t},C_3coupling'*C_23coupling*c_2b{1,t}];
 K_3b=R_3b{1,t}*R_3b{1,t}'*inv(R_3b{1,t}*R_3b{1,t}'+ R_32b{1,t}*R_32b{1,t}');
 c_3c{1,t}=(eye(4)-K_3b)*c_3b{1,t} + K_3b*c_2b{1,t};
 R_3c{1,t}=[(eye(4)-K_3b)*R_3b{1,t}, K_3b*R_2b{1,t}];
 R_3c{1,t}=Reduction(R_3c{1,t},size(R_3r{1,t},2));
 P_3c=sum(abs(R_3c{1,t}), 2);
 x_3c_up(:, t)=  c_3c{1,t}+P_3c;
 x_3c_down(:, t)=c_3c{1,t}-P_3c;
 x_3b_up(:,t)= c_3b{1,t}+P_3b;
 x_3b_down(:,t)= c_3b{1,t}-P_3b;
 J_3c(:,t)=trace(R_3c{1,t}*R_3c{1,t}');
end
%% 将不重叠的结果直接拿来（代码肯定有错误所以需要格外小心）
 t=20;
 c_21b=C_21coupling'*C_1coupling*c_1a{1,t} + C_21out'*C_21out*c_2a{1,t};
 R_21b=[C_21out'*C_21out*R_2a{1,t}, C_21coupling'*C_1coupling*R_1a{1,t}];
 K_21b=R_2a{1,t}*R_2a{1,t}'*inv(R_2a{1,t}*R_2a{1,t}'+ R_21b*R_21b');
 c_21c=(eye(4)-K_21b)*c_2a{1,t} + K_21b*c_21b;
 R_21c=[(eye(4)-K_21b)*R_2a{1,t}, K_21b*R_21b];
 % 比较性能指标 （与3的融合）
 c_23b=C_23coupling'*C_3coupling*c_3a{1,t} + C_23out'*C_23out*c_21c;
 R_23b=[C_23out'*C_23out*R_21c,C_23coupling'*C_3coupling*R_3a{1,t}];
 K_23b=R_21c*R_21c'*inv(R_21c*R_21c'+R_23b*R_23b');
 c_2c=(eye(4)-K_23b)*c_21c + K_23b*c_23b;
 R_2c=[(eye(4)-K_23b)*R_21c, K_23b*R_23b];
 R_2c=Reduction(R_2c,size(R_2r{1,t},2));
 
 C_21out=[zeros(2,2),eye(2,2)];
 C_23out=[eye(2,2),zeros(2,2)];
 z_1=C_21out*c_2c;      Zon_1=C_21out*R_2c;
 z_2=C_21out*c_2r{1,t}; Zon_2=C_21out*R_2r{1,t};
 Z_1=zonotope(z_1,Zon_1);
 Z_2=zonotope(z_2,Zon_1);
 J=trace(R_2c'*R_2c);
 J_2r(:,20)
 c_2r{1,20}
 [c,r]=box_wrap(c_2c,R_2c);
 [c1,r1]=box_wrap(c_2r{1,20},R_2r{1,20});

figure(1)
hold on
plot(Z_1,'color','r','alpha',0.1);
plot(Z_2,'color','b','alpha',0.3);



%% 遗传算法来求解这个
%% 初始化参数
b = [18; 20; 20];    % b1, b2, b3
q = [4; 4; 4];       % q1, q2, q3
R_total = 30;        % 总资源限制
%% 目标函数（连续放缩版本）
objective = @(R) (q(1)*b(1))/floor(2^(R(1)/q(1))) + ...
                 (q(2)*b(2))/floor(2^(R(2)/q(2))) + ...
                 (q(3)*b(3))/floor(2^(R(3)/q(3)));
%% 变量设置
lb = [1; 1; 1];
ub = [30; 30; 30];
A = [1, 1, 1];
b_con = R_total;
%% 调用遗传算法求解
intcon = [1, 2, 3];  % 整数约束
options = optimoptions('ga', ...
    'Display', 'iter', ...
    'PopulationSize', 100, ...
    'MaxGenerations', 200);
[R, fval] = ga(objective, 3, A, b_con, [], [], lb, ub, [], intcon, options);
%% 输出结果
fprintf('\n===== 最优解 =====\n');
fprintf('R1 = %d, R2 = %d, R3 = %d\n', R(1), R(2), R(3));
fprintf('目标函数值 = %.4f\n', fval);
fprintf('资源使用量 = %d (总共可用 %d)\n', sum(R), R_total);
%% 各项贡献
term1 = (q(1) * abs(b(1))) / (2^(R(1)/q(1)));
term2 = (q(2) * abs(b(2))) / (2^(R(2)/q(2)));
term3 = (q(3) * abs(b(3))) / (2^(R(3)/q(3)));
fprintf('\n===== 各项贡献 =====\n');
fprintf('第一项: %.4f (R1 = %d, 2^{R1/4} = %.2f)\n', term1, R(1), 2^(R(1)/4));
fprintf('第二项: %.4f (R2 = %d, 2^{R2/4} = %.2f)\n', term2, R(2), 2^(R(2)/4));
fprintf('第三项: %.4f (R3 = %d, 2^{R3/4} = %.2f)\n', term3, R(3), 2^(R(3)/4));