%% 初始化事件触发参数     100%触发率
d1_1e=0;d1_2e=0;d1_3e=0;
T1_1=zeros(1,N);T1_2=zeros(1,N);T1_3=zeros(1,N);
T1_1(1,1)=1;T1_2(1,1)=1;T1_3(1,1)=1;
yz1=y_1(:,1);  yz2=y_2(:,1);  yz3=y_3(:,1);
yz11=y_1(:,1); yz22=y_2(:,1); yz33=y_3(:,1);
%% 初始协方差矩阵和状态
Rz_1a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rz_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rz_2a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rz_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
Rz_3a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);Rz_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
cz_1a{1,1}=[0; v; d; v];            cz_1b{1,1}=cz_1a{1,1};    
cz_2a{1,1}=[d; v; 2*d; v];          cz_2b{1,1}=cz_2a{1,1};
cz_3a{1,1}=[2*d; v; 3*d; v];        cz_3b{1,1}=cz_3a{1,1};
%% 初始化边界
% box半径下的
cz_1a_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);   cz_1b_up(:, 1)=cz_1a_up(:, 1); 
cz_1a_down(:, 1)= x_1(:, 1)-0.01*ones(4,1);  cz_1b_down(:, 1)=cz_1a_down(:, 1);
cz_2a_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);   cz_2b_up(:, 1)=cz_2a_up(:, 1);
cz_2a_down(:, 1)= x_2(:, 1)-0.01*ones(4,1);  cz_2b_down(:, 1)=cz_2a_down(:, 1);
cz_3a_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);   cz_3b_up(:, 1)=cz_3a_up(:, 1);
cz_3a_down(:, 1)= x_3(:, 1)-0.01*ones(4,1);  cz_3b_down(:, 1)=cz_3a_down(:, 1);
% 性能指标
J1_1a(:,1)=0.02^4;J1_2a(:,1)=0.02^4;J1_3a(:,1)=0.02^4;
J1_1b(:,1)=0.02^4;J1_2b(:,1)=0.02^4;J1_3b(:,1)=0.02^4;
num1_1a(:,1)=4; num1_2a(:,1)=4; num1_3a(:,1)=4;
num1_1b(:,1)=4; num1_2b(:,1)=4; num1_3b(:,1)=4;
%% 定义每个事件触发机制的误差矩阵
E1_11=d1_1e*eye(4); E1_22=d1_2e*eye(4); E1_33=d1_3e*eye(4);
%% 消融实验
for t=2:N+1
%% 在F半径下的融合处理
 %第一个估计器的融合中心
 N_11b=[Rz_1b{1,t-1},zeros(4,num1_2b(:,t-1))];
 N_12b=[-C_12intersection*Rz_1b{1,t-1},C_12overlaping*Rz_2b{1,t-1}];
 M_1b(:,:,t-1)=-N_11b*N_12b'*inv(N_12b*N_12b');
 cz_1c{1,t-1}= (eye(4)-M_1b(:,:,t-1)*C_12intersection)*cz_1b{1,t-1} + M_1b(:,:,t-1)*C_12overlaping*cz_2b{1,t-1};
 Rz_1c{1,t-1}= N_11b+M_1b(:,:,t-1)*N_12b; 
 P1_1c(:,t-1) =sum(abs(Rz_1c{1,t-1}), 2);
 J1_1c(:,t-1)=prod(2*P1_1c(:,t-1));
 cz_1c_up(:, t-1)= cz_1c{1,t-1} + P1_1c(:,t-1);
 cz_1c_down(:,t-1)=cz_1c{1,t-1}- P1_1c(:,t-1);
%第二个估计器的融合中心
 N_22b=[Rz_2b{1,t-1},zeros(4,num1_1b(:,t-1)),zeros(4,num1_3b(:,t-1))];
 N_21b=[-C_21intersection*Rz_2b{1,t-1},C_21overlaping*Rz_1b{1,t-1},zeros(2,num1_3b(:,t-1));
        -C_23intersection*Rz_2b{1,t-1},zeros(2,num1_1b(:,t-1)),C_23overlaping*Rz_3b{1,t-1}];
 M_2b(:,:,t-1)=-N_22b*N_21b'*inv(N_21b*N_21b');
 cz_2c{1,t-1}= (eye(4)-M_2b(:,1:2,t-1)*C_21intersection - M_2b(:,3:4,t-1)*C_23intersection)*cz_2b{1,t-1} + M_2b(:,1:2,t-1)*C_21overlaping*cz_1b{1,t-1} + M_2b(:,3:4,t-1)*C_23overlaping*cz_3b{1,t-1};
 Rz_2c{1,t-1}= N_22b+M_2b(:,:,t-1)*N_21b;
 P1_2c(:,t-1) =sum(abs(Rz_2c{1,t-1}), 2);
 J1_2c(:,t-1)=prod(2*P1_2c(:,t-1));
 cz_2c_up(:, t-1)=  cz_2c{1,t-1} + P1_2c(:,t-1);
 cz_2c_down(:, t-1)=cz_2c{1,t-1} - P1_2c(:,t-1);
%第三个估计器的融合中心
 N_33b=[Rz_3b{1,t-1},zeros(4,num1_2b(:,t-1))];
 N_31b=[-C_32intersection*Rz_3b{1,t-1},C_32overlaping*Rz_2b{1,t-1}];
 M_3b(:,:,t-1)=-N_33b*N_31b'*inv(N_31b*N_31b');
 cz_3c{1,t-1}= (eye(4)-M_3b(:,:,t-1)*C_32intersection)*cz_3b{1,t-1} + M_3b(:,:,t-1)*C_32overlaping*cz_2b{1,t-1};
 Rz_3c{1,t-1}= N_33b + M_3b(:,:,t-1)*N_31b;      
 P1_3c(:,t-1) =sum(abs(Rz_3c{1,t-1}), 2);
 J1_3c(:,t-1)=prod(2*P1_3c(:,t-1));
 cz_3c_up(:, t-1)= cz_3c{1,t-1}  +  P1_3c(:,t-1);
 cz_3c_down(:,t-1)=cz_3c{1,t-1}  -  P1_3c(:,t-1);
 %% 融合处理（第一个估计器）
 N_11=[Rz_1a{1,t-1},zeros(4,num1_2a(:,t-1))];
 N_12=[-C_12intersection*Rz_1a{1,t-1},C_12overlaping*Rz_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    cz_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*cz_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*cz_2a{1,t-1};
    Rz_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    P1_1r(:,t-1)=sum(abs(Rz_1r{1,t-1}),2);
    J1_1r(:,t-1)=prod(2*P1_1r(:,t-1));
    cz_1r_up(:, t-1)=  cz_1r{1,t-1} + P1_1r(:,t-1);
    cz_1r_down(:,t-1)= cz_1r{1,t-1}-  P1_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[Rz_2a{1,t-1},zeros(4,num1_1a(:,t-1)),zeros(4,num1_3a(:,t-1))];
  N_21=[-C_21intersection*Rz_2a{1,t-1},C_21overlaping*Rz_1a{1,t-1},zeros(2,num1_3a(:,t-1));
                 -C_23intersection*Rz_2a{1,t-1},zeros(2,num1_1a(:,t-1)),C_23overlaping*Rz_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  cz_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*cz_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*cz_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*cz_3a{1,t-1};
  Rz_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  P1_2r(:,t-1) =sum(abs(Rz_2r{1,t-1}), 2);
  J1_2r(:,t-1)=prod(2*P1_2r(:,t-1));
  cz_2r_up(:, t-1)=  cz_2r{1,t-1} + P1_2r(:,t-1);
  cz_2r_down(:, t-1)=cz_2r{1,t-1} - P1_2r(:,t-1);
%% 融合处理（第三个估计器）
  N_33=[Rz_3a{1,t-1},zeros(4,num1_2a(:,t-1))];
  N_31=[-C_32intersection*Rz_3a{1,t-1},C_32overlaping*Rz_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  cz_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*cz_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*cz_2a{1,t-1};
  Rz_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  P1_3r(:,t-1) =sum(abs(Rz_3r{1,t-1}), 2);
  J1_3r(:,t-1)=prod(2*P1_3r(:,t-1));
  cz_3r_up(:, t-1)=cz_3r{1,t-1}  + P1_3r(:,t-1);
  cz_3r_down(:,t-1)=cz_3r{1,t-1} - P1_3r(:,t-1);
%% 跳出循环
  if t == N+1
      break;  % 立即终止循环
  end
  % 第一个估计器 在F半径下的中心对称多细胞体估计器设计
  cz_1f{1,t}= A_1*cz_1c{1,t-1}+U_1(:,t)+A_12*cz_2b{1,t-1};
  Rz_1f{1,t}= [A_1*Rz_1c{1,t-1},A_12*Rz_2b{1,t-1},QE1];
  % 第一个估计器 中心对称多细胞体估计器设计
  cz_1e{1,t} = A_1*cz_1r{1,t-1}+U_1(:,t)+A_12*cz_2a{1,t-1};
  Rz_1e{1,t}= [A_1*Rz_1r{1,t-1},A_12*Rz_2a{1,t-1},QE1];
% 先使用简单的事件触发来设计
  if  norm(y_1(:,t)-yz1,2) <= d1_1e
      T1_1(1,t)=0;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rz_1f{1,t}*Rz_1f{1,t}'*C_1'*inv(C_1*Rz_1f{1,t}*Rz_1f{1,t}'*C_1' +D_1*RE1*RE1'*D_1'+E1_11*E1_11'+E_1co*E_1co');
      cz_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cz_1f{1,t} + K_1b(:,:,t)*yz11;
      Rz_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rz_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*D_1*E_1co,K_1b(:,:,t)*E1_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rz_1e{1,t}, zeros(4,12)];
      Ps1 = [C_1*Rz_1e{1,t},D_1*RE1,-E_1co,-E1_11];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cz_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cz_1e{1,t} + K_1(:,:,t)*yz11;
      Rz_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rz_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co,K_1(:,:,t)*E1_11];
  else
      yz1=y_1(:,t);
      yz11=coder(yz1,R(1),b1,q1);
      yz11=decoder(yz11,R(1),b1,q1);
      T1_1(1,t)=1;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=Rz_1f{1,t}*Rz_1f{1,t}'*C_1'*inv(C_1*Rz_1f{1,t}*Rz_1f{1,t}'*C_1' + D_1*RE1*RE1'*D_1'+E_1co*E_1co');
      cz_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*cz_1f{1,t} + K_1b(:,:,t)*yz11;
      Rz_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*Rz_1f{1,t},-K_1b(:,:,t)*D_1*RE1,K_1b(:,:,t)*E_1co];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [Rz_1e{1,t}, zeros(4,8)];
      Ps1 = [C_1*Rz_1e{1,t},D_1*RE1,-E_1co];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      cz_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*cz_1e{1,t} + K_1(:,:,t)*yz11;
      Rz_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*Rz_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co];
  end
% F半径下的
    Rz_1b{1,t} = Reduction(Rz_1b{1,t},q);
    num1_1b(:,t)=size(Rz_1b{1,t},2);
    P1_1b =sum(abs(Rz_1b{1,t}),2);
    cz_1b_up(:, t)= cz_1b{1,t}  + P1_1b;
    cz_1b_down(:, t)=cz_1b{1,t} - P1_1b;
    J1_1b(:,t)=prod(2*P1_1b);
    % box半径下的
    Rz_1a{1,t} = Reduction(Rz_1a{1,t},q);
    num1_1a(:,t)=size(Rz_1a{1,t},2);
    P1_1a =sum(abs(Rz_1a{1,t}), 2);
    cz_1a_up(:, t)=  cz_1a{1,t} + P1_1a;
    cz_1a_down(:, t)=cz_1a{1,t} - P1_1a;
    J1_1a(:,t)=prod(2*P1_1a);
    % 第二个估计器  
    % F半径下的
    cz_2f{1,t} = A_2*cz_2c{1,t-1}+A_21*cz_1b{1,t-1}+A_23*cz_3b{1,t-1}+U_2(:,t);           
    Rz_2f{1,t} = [A_2*Rz_2c{1,t-1},A_21*Rz_1b{1,t-1},A_23*Rz_3b{1,t-1},QE2];
    % box下的
    cz_2e{1,t} = A_2*cz_2r{1,t-1}+A_21*cz_1a{1,t-1}+A_23*cz_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    Rz_2e{1,t} = [A_2*Rz_2r{1,t-1}, A_21*Rz_1a{1,t-1},A_23*Rz_3a{1,t-1}, QE2];
    % 先使用简单的事件触发来设计
    if  norm(y_2(:,t)-yz2,2) <= d1_2e
        T1_2(1,t)=0;
    % F半径下的增益矩阵设计
      K_2b(:,:,t)=Rz_2f{1,t}*Rz_2f{1,t}'*C_2'*inv(C_2*Rz_2f{1,t}*Rz_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E1_22*E1_22'+E_2co*E_2co');
      cz_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cz_2f{1,t} + K_2b(:,:,t)*yz22;
      Rz_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rz_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co,K_2b(:,:,t)*E1_22];
        % box下的增益矩阵设计
        Ph2= [Rz_2e{1,t}, zeros(4,12)];
        Ps2 = [C_2*Rz_2e{1,t},D_2*RE2,-E_2co,-E1_22];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cz_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cz_2e{1,t} + K_2(:,:,t)*yz22;
        Rz_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rz_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co,K_2(:,:,t)*E1_22];
    else
        yz2=y_2(:,t);
        yz22=coder(yz2,R(2),b2,q2);
        yz22=decoder(yz22,R(2),b2,q2);
        T1_2(1,t)=1;
        % F半径下的增益矩阵设计
        K_2b(:,:,t)=Rz_2f{1,t}*Rz_2f{1,t}'*C_2'*inv(C_2*Rz_2f{1,t}*Rz_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E_2co*E_2co');
        cz_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*cz_2f{1,t} + K_2b(:,:,t)*yz22;
        Rz_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*Rz_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co];
        % box半径下的增益矩阵设计
        Ph2= [Rz_2e{1,t}, zeros(4,8)];
        Ps2 = [C_2*Rz_2e{1,t},D_2*RE2,-E_2co];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);          % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        cz_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*cz_2e{1,t} + K_2(:,:,t)*yz22;
        Rz_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*Rz_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co];
    end
      % F半径指标下
      Rz_2b{1,t} = Reduction(Rz_2b{1,t},q);
      num1_2b(:,t)=size(Rz_2b{1,t},2);
      P1_2b =sum(abs(Rz_2b{1,t}), 2);
      cz_2b_up(:, t)= cz_2b{1,t} + P1_2b;
      cz_2b_down(:, t)=cz_2b{1,t}- P1_2b;
      J1_2b(:,t)=prod(2*P1_2b);
      % box指标下
      Rz_2a{1,t} = Reduction(Rz_2a{1,t},q);
      num1_2a(:,t)=size(Rz_2a{1,t},2);
      P1_2a =sum(abs(Rz_2a{1,t}), 2);
      cz_2a_up(:, t)=  cz_2a{1,t} + P1_2a;
      cz_2a_down(:, t)=cz_2a{1,t} - P1_2a;
      J1_2a(:,t)=prod(2*P1_2a);
     % 第三个估计器
     % F半径下的
      cz_3f{1,t}=A_3*cz_3c{1,t-1} +A_32*cz_2b{1,t-1}+ U_3(:,t) ;
      Rz_3f{1,t}=[A_3*Rz_3c{1,t-1},A_32*Rz_2b{1,t-1}, QE3];
     % box半径下的
      cz_3e{1,t}=A_3*cz_3r{1,t-1} +A_32*cz_2a{1,t-1}+ U_3(:,t) ;
      Rz_3e{1,t}=[A_3*Rz_3r{1,t-1},A_32*Rz_2a{1,t-1}, QE3];
     if  norm(y_3(:,t)-yz3,2) <= d1_3e
        T1_3(1,t)=0;
        % F半径下的增益矩阵设计
        K_3b(:,:,t)=Rz_3f{1,t}*Rz_3f{1,t}'*C_3'*inv(C_3*Rz_3f{1,t}*Rz_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3*+E1_33*E1_33'+E_3co*E_3co');
        cz_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cz_3f{1,t} + K_3b(:,:,t)*yz33;
        Rz_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rz_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co,K_3b(:,:,t)*E1_33];
        % box半径下的增益矩阵设计
        Ph3= [Rz_3e{1,t}, zeros(4,12)];
        Ps3 = [C_3*Rz_3e{1,t},D_3*RE3,-E_3co,-E1_33];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);      % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cz_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cz_3e{1,t} + K_3(:,:,t)*yz33;
        Rz_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rz_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co,K_3(:,:,t)*E1_33];
    else
        yz3=y_3(:,t);
        yz33=coder(yz3,R(3),b3,q3);
        yz33=decoder(yz33,R(3),b3,q3);
        T1_3(1,t)=1;
       % F半径下的性能指标设计
        K_3b(:,:,t)=Rz_3f{1,t}*Rz_3f{1,t}'*C_3'*inv(C_3*Rz_3f{1,t}*Rz_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3'+E_3co*E_3co');
        cz_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*cz_3f{1,t} + K_3b(:,:,t)*yz33;
        Rz_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*Rz_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co];
        % box半径下的性能指标设计
        Ph3= [Rz_3e{1,t}, zeros(4,8)];
        Ps3 = [C_3*Rz_3e{1,t},D_3*RE3,-E_3co];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);         % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        cz_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*cz_3e{1,t} + K_3(:,:,t)*yz33;
        Rz_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*Rz_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co];
    end
 %% F半径下的
    Rz_3b{1,t} = Reduction(Rz_3b{1,t},q);
    num1_3b(:,t)=size(Rz_3b{1,t},2);
    P1_3b =sum(abs(Rz_3b{1,t}), 2);
    cz_3b_up(:, t)= cz_3b{1,t} + P1_3b;
    cz_3b_down(:, t)=cz_3b{1,t}- P1_3b;
    J1_3b(:,t)=prod(2*P1_3b);
    %% box半径下的
    Rz_3a{1,t} = Reduction(Rz_3a{1,t},q);
    num1_3a(:,t)=size(Rz_3a{1,t},2);
    P1_3a =sum(abs(Rz_3a{1,t}), 2);
    cz_3a_up(:, t)= cz_3a{1,t} + P1_3a;
    cz_3a_down(:, t)=cz_3a{1,t}- P1_3a;
    J1_3a(:,t)=prod(2*P1_3a);
end
sum(T1_1);
sum(T1_2);
sum(T1_3);
%% 估计图
plot(1:N, x_2(2, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N, cz_2a_up(2, :), 'r', 'LineWidth', 1.5);
plot(1:N, cz_2a_down(2, :), 'r', 'LineWidth', 1.5);
plot(1:N, cz_2r_up(2, :), 'b', 'LineWidth', 1.5);
plot(1:N, cz_2r_down(2, :), 'b', 'LineWidth', 1.5);
legend('真实值','估计值的上界','估计值的下界','融合值的上界','融合值的下界' );
%% 性能指标图
plot(1:N,  log10(J1_3b(1, :)), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  log10(J1_3a(1, :)), 'r', 'LineWidth', 1.5);
plot(1:N,  log10(J1_3c(1, :)), 'g', 'LineWidth', 1.5);
plot(1:N,  log10(J1_3r(1, :)), 'b', 'LineWidth', 1.5);
legend('F估计','box估计','F融合','box融合');
%% 不同通信率下的性能指标图
%F半径
color60e = [0, 0.4, 0.8];      % 深蓝 - 60%估计
color60f = [0.9, 0.2, 0.2];    % 亮红 - 60%融合
color80e = [0.1, 0.7, 0.3];    % 翠绿 - 80%估计
color80f = [0.7, 0.3, 0.9];    % 紫色 - 80%融合
color100e = [1, 0.6, 0.1];     % 橙色 - 100%估计
color100f = [0.2, 0.8, 0.8];   % 青色 - 100%融合
figure('Color','white');  % 创建白色背景图形窗口
hold on;
% 绘制各曲线（使用新颜色方案）
p1 = plot(1:N, log10(J_3a(1,:)),  'Color',color60e, 'LineWidth',2.2, 'LineStyle','-');
p2 = plot(1:N, log10(J_3r(1,:)),  'Color',color60f, 'LineWidth',2.2, 'LineStyle','-');
p3 = plot(1:N, log10(Jz_3a(1,:)), 'Color',color80e, 'LineWidth',2.2, 'LineStyle','-');
p4 = plot(1:N, log10(Jz_3r(1,:)), 'Color',color80f, 'LineWidth',2.2, 'LineStyle','--');
p5 = plot(1:N, log10(J1_3a(1,:)), 'Color',color100e,'LineWidth',2.2, 'LineStyle','-');
p6 = plot(1:N, log10(J1_3r(1,:)), 'Color',color100f,'LineWidth',2.2, 'LineStyle','--');
% 添加图例（修正百分比符号位置）
legend([p1 p2 p3 p4 p5 p6], ...
    '60%估计', '60%融合', '80%估计', '80%融合', '100%估计', '100%融合', ...
    'Location', 'best', 'FontSize', 11);
% 美化图形
grid on;
box on;
set(gca, 'FontSize', 12, 'LineWidth', 1.2, ...
         'XColor', [0.3 0.3 0.3], 'YColor', [0.3 0.3 0.3]);
% 添加颜色条标识（可选）
annotation('textbox', [0.15,0.82,0.1,0.05], 'String','60%', ...
           'FitBoxToText','on', 'EdgeColor','none', 'Color',color60e,...
           'FontWeight','bold', 'FontSize',10);
annotation('textbox', [0.15,0.75,0.1,0.05], 'String','80%', ...
           'FitBoxToText','on', 'EdgeColor','none', 'Color',color80e,...
           'FontWeight','bold', 'FontSize',10);
annotation('textbox', [0.15,0.68,0.1,0.05], 'String','100%', ...
           'FitBoxToText','on', 'EdgeColor','none', 'Color',color100e,...
           'FontWeight','bold', 'FontSize',10);

plot(1:N,  log10(J2_2a(1, :)), 'y', 'LineWidth', 1.5);hold on
plot(1:N,  log10(J2_2r(1, :)), 'k--', 'LineWidth', 1.5);
plot(1:N,  log10(J_2a(1, :)), 'k', 'LineWidth', 1.5);
plot(1:N,  log10(J_2r(1, :)), 'r--', 'LineWidth', 1.5);
plot(1:N,  log10(Jz_2a(1, :)), 'g', 'LineWidth', 1.5);
plot(1:N,  log10(Jz_2r(1, :)), 'b--', 'LineWidth', 1.5);
plot(1:N,  log10(J1_2a(1, :)), 'm', 'LineWidth', 1.5);
plot(1:N,  log10(J1_2r(1, :)), 'c--', 'LineWidth', 1.5);
legend('40%估计','%40融合','60%估计','%60融合','%80估计','%80融合','%100估计','%100融合');

%% 不同速率下的图像绘制
 
print('Communication rates', '-dpng', '-r330');
plot(1:N,  log10(J1_2a(1, :)), 'g', 'LineWidth', 1.5);hold on
plot(1:N,  log10(J1_2b(1, :)), 'b', 'LineWidth', 1.5);
plot(1:N,  log10(J1_2r(1, :)), 'm--', 'LineWidth', 1.5);
plot(1:N,  log10(J1_2c(1, :)), 'c--', 'LineWidth', 1.5);
legend('box估计','F融合','box融合','F融合');
%%
figure('Position', [100, 100, 800, 600]);
hold on;
% 绘制各条曲线
plot(rates, Flocal_rmse, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Local estimate under F-raduis');
plot(rates, Ffusion_rmse, 'r-s', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Fusion estimate under F-raduis');
plot(rates, Blocal_rmse, 'g-d', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Local estimate');
plot(rates, Bfusion_rmse, 'm-*', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Fusion estimate');
% 设置 X 轴刻度
set(gca, 'XTick', rates);
% 添加 X、Y 轴标签
xlabel('Communication rates', 'FontSize', 12);
ylabel('$\log_{10}(\mathrm{AAR})$', 'Interpreter', 'latex', 'FontSize', 12);
% 显示图例并调整位置
legend('Location', 'best', 'FontSize', 10);
% 添加网格线并优化样式
grid on;
set(gca, 'GridLineStyle', '-', 'GridColor', [0.8, 0.8, 0.8], 'GridAlpha', 0.5);
% 确保图表边框完整封闭（四条边都有线）
box on;  % 启用边框
% 设置 Y 轴范围（可选，根据数据调整）
% ylim([min(min(Flocal_rmse, Ffusion_rmse, Blocal_rmse, Bfusion_rmse))-0.1, max(max(Flocal_rmse, Ffusion_rmse, Blocal_rmse, Bfusion_rmse))+0.1]);
% 设置图形背景为白色
set(gcf, 'Color', 'white'); 
hold off;
print('Communication', '-depsc', '-r330');




