%% Batch, Sequential，Weighted matricx in time and performance
clear;
clc;
%% 创建时间矩阵和性能矩阵
N=1;
T=zeros(2,7); T4=zeros(N, 1); T5=zeros(N, 1); T6=zeros(N, 1); T7=zeros(N, 1); T8=zeros(N, 1); T9=zeros(N, 1); T10=zeros(N, 1);
J=zeros(2,7); J4=zeros(N, 1); J5=zeros(N, 1); J6=zeros(N, 1); J7=zeros(N, 1); J8=zeros(N, 1); J9=zeros(N, 1); J10=zeros(N, 1);
              T41=zeros(N, 1); T51=zeros(N, 1); T61=zeros(N, 1); T71=zeros(N, 1); T81=zeros(N, 1); T91=zeros(N, 1); T101=zeros(N, 1);
              J41=zeros(N, 1); J51=zeros(N, 1); J61=zeros(N, 1); J71=zeros(N, 1); J81=zeros(N, 1); J91=zeros(N, 1); J101=zeros(N, 1);
%% 首先需要说明的是批融合不太能执行运算步骤，所有需要一个一个手巧
%% 生成1个4行4列和3个2行4列的生成矩阵，然后执行运算结果
y1=zeros(4,1);y2=zeros(2,1);y3=zeros(2,1);y4=zeros(2,1);
C2=[1,0,0,0;0,1,0,0];C3=[1,0,0,0;0,0,1,0];C4=[1,0,0,0;0,0,0,1];
P1=2*rand(4, 4)-1;  P2=2*rand(2, 4)-1; P3=2*rand(2, 4)-1; P4=2*rand(2, 4)-1;
C21=[0,0,1,0;0,0,0,1]; C31=[0,1,0,0;0,0,0,1]; C41=[0,1,0,0;0,0,1,0];
%% 再生成6个凑足七组实验
y5=zeros(2,1);y6=zeros(2,1);y7=zeros(2,1);y8=zeros(3,1);y9=zeros(3,1);y10=zeros(3,1);
C5=[0,1,0,0;1,0,0,0];C6=[0,1,0,0;0,0,1,0];C7=[0,1,0,0;0,0,0,1];C8=[1,0,0,0;0,1,0,0;0,0,1,0];C9=[1,0,0,0;0,1,0,0;0,0,0,1];C10=[0,1,0,0;0,1,0,0;0,0,0,1];
P5=1*rand(2, 4)-0.5; P6=1*rand(2, 4)-0.5; P7=1*rand(2, 4)-0.5; P8=0.6*rand(3,4)-0.3; P9=0.6*rand(3,4)-0.3; P10=0.6*rand(3,4)-0.3;
C51=[0,0,1,0;0,0,0,1]; C61=[1,0,0,0;0,0,0,1]; C71=[1,0,0,0;0,0,1,0]; C81=[0,0,0,1]; C91=[0,0,1,0]; C101=[1,0,0,0];
%% 算法开始
%% 4个生成矩阵
for k = 1:N
% tic;
B41=[P1,zeros(4,12)];
B42=[-C2*P1,P2,zeros(2,8);
     -C3*P1,zeros(2,4),P3,zeros(2,4);
     -C4*P1,zeros(2,8),P4];
 row_4 = size(B42, 1);
 col_4 = size(B41,2);
 M1_opt = zeros(4, row_4);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    tic;
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_4, 1);      % 向量λ_i
        M1_i = sdpvar(1,row_4);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            B41(i,:)' +  B42'*M1_i' >= -L1_i,
            B41(i,:)' +  B42'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  K41=M1_opt;
  PB4=B41+K41*B42;
  T(1)=toc;
  J=2*sum(abs(PB4),2);
  J4=prod(J);
end
Per=zeros(1,7); TS=zeros(1,7);
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
z1=zonotope(y1,P1);               z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);           z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);           z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);           z4=computeHRep(z4);
zf4=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A] [z1.b;z2.b;z3.b;z4.b]]); zf4=computeVRep(zf4); % The common region by H-representation and V-representation
yf4=(max(zf4.V)'+min(zf4.V)')/2;
Pf4=diag(abs(max(zf4.V)'-min(zf4.V)')/2);
TS(1)=toc;
Pe=2*sum(abs(Pf4),2);
Per(1)=prod(Pe);
%% 5个生成矩阵 
for k = 1:N
tic;
B51=[P1,zeros(4,16)];
B52=[-C2*P1,P2,zeros(2,12);
     -C3*P1,zeros(2,4),P3,zeros(2,8);
     -C4*P1,zeros(2,8),P4,zeros(2,4);
     -C5*P1,zeros(2,12),P5];
 row_5 = size(B52, 1);
 col_5 = size(B51,2);
 M2_opt = zeros(4, row_5);
 for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_5, 1);      % 向量λ_i
        M2_i = sdpvar(1,row_5);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            B51(i,:)' +  B52'*M2_i' >= -L2_i,
            B51(i,:)' +  B52'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
 end
  K51=M2_opt;
  PB5=B51+K51*B52;
  T(2)=toc;
  J=2*sum(abs(PB5),2);
  J5=prod(J);
end

%% 融合5个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
zf5=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A] [z1.b;z2.b;z3.b;z4.b;z5.b]]); zf5=computeVRep(zf5); % The common region by H-representation and V-representation
yf5=(max(zf5.V)'+min(zf5.V)')/2;
Pf5=diag(abs(max(zf5.V)'-min(zf5.V)')/2);
TS(2)=toc;
Per(2)=trace(Pf5*Pf5');
Pe2=2*sum(abs(Pf5),2);
Per(2)=prod(Pe2);


T(1,2)=T5(k);   %T(1,2)=mean(T5);
J(1,2)=J5(k);   %J(1,2)=mean(J5);
T(2,2)=T51(k);  %T(2,2)=mean(T51);
J(2,2)=J51(k);  %J(2,2)=mean(J51);

%% 6个生成矩阵 
for k = 1:N
tic;
B61=[P1,zeros(4,20)];
B62=[-C2*P1,P2,zeros(2,16);
     -C3*P1,zeros(2,4),P3,zeros(2,12);
     -C4*P1,zeros(2,8),P4,zeros(2,8);
     -C5*P1,zeros(2,12),P5,zeros(2,4);
     -C6*P1,zeros(2,16),P6];
% 计算增益矩阵
K61=-B61*B62'*inv(B62*B62');
PB6=B61+K61*B62;
T61(k)=toc;
J61(k)=trace(PB6*PB6');
end
T(1,3)=mean(T6);
J(1,3)=mean(J6);
T(2,3)=mean(T61);
J(2,3)=mean(J61);
%% 7个生成矩阵 
for k = 1:N
tic
B71=[P1,zeros(4,24)];
B72=[-C2*P1,P2,zeros(2,20);
     -C3*P1,zeros(2,4),P3,zeros(2,16);
     -C4*P1,zeros(2,8),P4,zeros(2,12);
     -C5*P1,zeros(2,12),P5,zeros(2,8);
     -C6*P1,zeros(2,16),P6,zeros(2,4);
     -C7*P1,zeros(2,20),P7];
% 计算增益矩阵
K71=-B71*B72'*inv(B72*B72');
PB7=B71+K71*B72;
T71(k)=toc;
J71(k)=trace(PB7*PB7');
end
T(1,4)=mean(T7);
J(1,4)=mean(J7);
T(2,4)=mean(T71);
J(2,4)=mean(J71);

%% 8个生成矩阵 
for k = 1:N
tic;
B81=[P1,zeros(4,28)];
B82=[-C2*P1,P2,zeros(2,24);
     -C3*P1,zeros(2,4),P3,zeros(2,20);
     -C4*P1,zeros(2,8),P4,zeros(2,16);
     -C5*P1,zeros(2,12),P5,zeros(2,12);
     -C6*P1,zeros(2,16),P6,zeros(2,8);
     -C7*P1,zeros(2,20),P7,zeros(2,4);
     -C8*P1,zeros(3,24),P8];
% 计算增益矩阵
K81=-B81*B82'*inv(B82*B82');
PB8=B81+K81*B82;
T81(k)=toc;
J81(k)=trace(PB8*PB8');
end
T(1,5)=mean(T8);
J(1,5)=mean(J8);
T(2,5)=mean(T81);
J(2,5)=mean(J81);
%% 9个生成矩阵 
for k = 1:N
tic;
B91=[P1,zeros(4,32)];
B92=[-C2*P1,P2,zeros(2,28);
     -C3*P1,zeros(2,4),P3,zeros(2,24);
     -C4*P1,zeros(2,8),P4,zeros(2,20);
     -C5*P1,zeros(2,12),P5,zeros(2,16);
     -C6*P1,zeros(2,16),P6,zeros(2,12);
     -C7*P1,zeros(2,20),P7,zeros(2,8);
     -C8*P1,zeros(3,24),P8,zeros(3,4);
     -C9*P1,zeros(3,28),P9];
% 计算增益矩阵
K91=-B91*B92'*inv(B92*B92');
PB9=B91+K91*B92;
T91(k)=toc;
J91(k)=trace(PB9*PB9');
end
T(1,6)=mean(T9);
J(1,6)=mean(J9);
T(2,6)=mean(T91);
J(2,6)=mean(J91);
%% 10个生成矩阵 
for k = 1:N
%% 执行批次融合方法10
tic;
B101=[P1,zeros(4,36)];
B102=[-C2*P1,P2,zeros(2,32);
     -C3*P1,zeros(2,4),P3,zeros(2,28);
     -C4*P1,zeros(2,8),P4,zeros(2,24);
     -C5*P1,zeros(2,12),P5,zeros(2,20);
     -C6*P1,zeros(2,16),P6,zeros(2,16);
     -C7*P1,zeros(2,20),P7,zeros(2,12);
     -C8*P1,zeros(3,24),P8,zeros(3,8);
     -C9*P1,zeros(3,28),P9,zeros(3,4);
     -C10*P1,zeros(3,32),P10];
% 计算增益矩阵
K101=-B101*B102'*inv(B102*B102');
PB10=B101+K101*B102;
T101(k)=toc;
J101(k)=trace(PB10*PB10');
end
T(1,7)=mean(T10);
J(1,7)=mean(J10);
T(2,7)=mean(T101);
J(2,7)=mean(J101);



%% 绘制图像
x = 4:10; % 横坐标 4 到 10
% 2. 颜色与样式定义
purpleColor = [0.4940, 0.1840, 0.5560]; 
orangeColor = [0.9290, 0.6940, 0.1250]; 
greenColor  = [0.4660, 0.6740, 0.1880];
lineWidth = 1.5;
markerSize = 6;
figure('Color', 'w', 'Position', [100, 100, 600, 400]);
%% ======================================================
%  图 (a)：绘制 T (时间对比)
% ======================================================
subplot(1, 2, 1); 
hold on; box on; grid on;
% 绘图
p1 = plot(x, T(2,:), '-o', 'Color', purpleColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', purpleColor);
p2 = plot(x, T(1,:), '-o', 'Color', orangeColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', 'none'); % 空心
p3 = plot(x, TS(1,:), '-*', 'Color', greenColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', greenColor);
% 设置
xlim([3.8, 10.2]); 
xticks(4:10);
ylabel('Time (s)', 'FontSize', 12);
xlabel('Number of generators', 'FontSize', 12);
% --- 添加标题 (a) ---
% 去掉了 'Position' 参数，默认显示在上方
title('(a)', 'FontSize', 14, 'FontWeight', 'normal');
legend([p1, p2, p3], ...
    {'Batch fusion', 'Sequential fusion', 'Zonotopic fusion in [27]'}, ...
    'Location', 'northwest', 'EdgeColor', 'k', 'FontSize', 8);
% --- 嵌入小图 ---
insetPos = [0.22, 0.24, 0.2, 0.2]; 
ax_inset = axes('Position', insetPos); 
box on; hold on; grid on; set(ax_inset, 'Color', 'w');
plot(x, T(2,:), '-o', 'Color', purpleColor, 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', purpleColor);
plot(x, T(1,:), '-o', 'Color', orangeColor, 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'none'); 
xlim([3.8, 10.2]); xticks(4:2:10); 
set(ax_inset, 'FontSize', 8);
%% ======================================================
%  图 (b)：绘制 J (性能对比)
% ======================================================
subplot(1, 2, 2); 
hold on; box on; grid on;
s1 = plot(x, J(1,:), '-o', 'Color', purpleColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', purpleColor);
s2 = plot(x, J(2,:), '-o', 'Color', orangeColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', 'none'); % 空心
s3 = plot(x, Per(1,:), '-*', 'Color', greenColor, ...
    'LineWidth', lineWidth, 'MarkerSize', markerSize, ...
    'MarkerFaceColor', greenColor);
xlim([3.8, 10.2]); xticks(4:10);
ylabel('Performance', 'FontSize', 14); 
xlabel('Number of generators', 'FontSize', 14);
% --- 添加标题 (b) ---
% 去掉了 'Position' 参数，默认显示在上方
title('(b)', 'FontSize', 14, 'FontWeight', 'normal');
legend([s1, s2, s3], ...
    {'Batch fusion', 'Sequential fusion', 'Zonotopic fusion in [27]'}, ...
    'Location', 'northwest', 'EdgeColor', 'k', 'FontSize', 8);
%% 全局字体
set(findall(gcf,'-property','FontSize'),'FontSize',8);

print('Time_Performance_Strip', '-dpng', '-r330');

%% 转化为条带找胞性的交集的方法的时间
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
yi71=C71'*C71*y1 + C7'*y7;        Pi71=[C71'*C71*P1,C7'*P7]; 
yi81=C81'*C81*y1 + C8'*y8;        Pi81=[C81'*C81*P1,C8'*P8]; 
yi91=C91'*C91*y1 + C9'*y9;        Pi91=[C91'*C91*P1,C9'*P9]; 
yi101=C101'*C101*y1 + C10'*y10;   Pi101=[C101'*C101*P1,C10'*P10];

z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
z7=zonotope(yi71,Pi71);    z7=computeHRep(z7);
z8=zonotope(yi81,Pi81);    z8=computeHRep(z8);
z9=zonotope(yi91,Pi91);    z9=computeHRep(z9);
z10=zonotope(yi101,Pi101); z10=computeHRep(z10);
%% 融合4个的交集
Per=zeros(1,7); TS=zeros(1,7);
% tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
z1=zonotope(y1,P1);               z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);           z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);           z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);           z4=computeHRep(z4);
zf4=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A] [z1.b;z2.b;z3.b;z4.b]]); zf4=computeVRep(zf4); % The common region by H-representation and V-representation
yf4=(max(zf4.V)'+min(zf4.V)')/2;
Pf4=diag(abs(max(zf4.V)'-min(zf4.V)')/2);
% TS(1)=toc;
Pe=2*sum(abs(Pf4),2);
Per(1)=prod(J);

%% 融合5个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
zf5=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A] [z1.b;z2.b;z3.b;z4.b;z5.b]]); zf5=computeVRep(zf5); % The common region by H-representation and V-representation
yf5=(max(zf5.V)'+min(zf5.V)')/2;
Pf5=diag(abs(max(zf5.V)'-min(zf5.V)')/2);
TS(2)=toc;
Per(2)=trace(Pf5*Pf5');
%% 融合6个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
zf6=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A;z6.A] [z1.b;z2.b;z3.b;z4.b;z5.b;z6.b]]); zf6=computeVRep(zf6); % The common region by H-representation and V-representation
yf6=(max(zf6.V)'+min(zf6.V)')/2;
Pf6=diag(abs(max(zf6.V)'-min(zf6.V)')/2);
TS(3)=toc;
Per(3)=trace(Pf6*Pf6');
%% 融合7个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
yi71=C71'*C71*y1 + C7'*y7;        Pi71=[C71'*C71*P1,C7'*P7]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
z7=zonotope(yi71,Pi71);    z7=computeHRep(z7);
z10=zonotope(yi101,Pi101); z10=computeHRep(z10);
zf7=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A;z6.A;z7.A] [z1.b;z2.b;z3.b;z4.b;z5.b;z6.b;z7.b]]); zf7=computeVRep(zf7); % The common region by H-representation and V-representation
yf7=(max(zf7.V)'+min(zf7.V)')/2;
Pf7=diag(abs(max(zf7.V)'-min(zf7.V)')/2);
TS(4)=toc;
Per(4)=trace(Pf7*Pf7');
%% 融合8个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
yi71=C71'*C71*y1 + C7'*y7;        Pi71=[C71'*C71*P1,C7'*P7]; 
yi81=C81'*C81*y1 + C8'*y8;        Pi81=[C81'*C81*P1,C8'*P8]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
z7=zonotope(yi71,Pi71);    z7=computeHRep(z7);
z8=zonotope(yi81,Pi81);    z8=computeHRep(z8);
zf8=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A;z6.A;z7.A;z8.A] [z1.b;z2.b;z3.b;z4.b;z5.b;z6.b;z7.b;z8.b]]); zf8=computeVRep(zf8); % The common region by H-representation and V-representation
yf8=(max(zf8.V)'+min(zf8.V)')/2;
Pf8=diag(abs(max(zf8.V)'-min(zf8.V)')/2);
TS(5)=toc;
Per(5)=trace(Pf8*Pf8');
%% 融合9个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
yi71=C71'*C71*y1 + C7'*y7;        Pi71=[C71'*C71*P1,C7'*P7]; 
yi81=C81'*C81*y1 + C8'*y8;        Pi81=[C81'*C81*P1,C8'*P8]; 
yi91=C91'*C91*y1 + C9'*y9;        Pi91=[C91'*C91*P1,C9'*P9]; 
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
z7=zonotope(yi71,Pi71);    z7=computeHRep(z7);
z8=zonotope(yi81,Pi81);    z8=computeHRep(z8);
z9=zonotope(yi91,Pi91);    z9=computeHRep(z9);
zf9=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A;z6.A;z7.A;z8.A;z9.A] [z1.b;z2.b;z3.b;z4.b;z5.b;z6.b;z7.b;z8.b;z9.b]]); zf9=computeVRep(zf9); % The common region by H-representation and V-representation
yf9=(max(zf9.V)'+min(zf9.V)')/2;
Pf9=diag(abs(max(zf9.V)'-min(zf9.V)')/2);
TS(6)=toc;
Per(6)=trace(Pf9*Pf9');
%% 融合10个的交集
tic;
yi21=C21'*C21*y1 + C2'*y2;        Pi21=[C21'*C21*P1,C2'*P2]; 
yi31=C31'*C31*y1 + C3'*y3;        Pi31=[C31'*C31*P1,C3'*P3]; 
yi41=C41'*C41*y1 + C4'*y4;        Pi41=[C41'*C41*P1,C4'*P4];
yi51=C51'*C51*y1 + C5'*y5;        Pi51=[C51'*C51*P1,C5'*P5]; 
yi61=C61'*C61*y1 + C6'*y6;        Pi61=[C61'*C61*P1,C6'*P6]; 
yi71=C71'*C71*y1 + C7'*y7;        Pi71=[C71'*C71*P1,C7'*P7]; 
yi81=C81'*C81*y1 + C8'*y8;        Pi81=[C81'*C81*P1,C8'*P8]; 
yi91=C91'*C91*y1 + C9'*y9;        Pi91=[C91'*C91*P1,C9'*P9]; 
yi101=C101'*C101*y1 + C10'*y10;   Pi101=[C101'*C101*P1,C10'*P10];
z1=zonotope(y1,P1);        z1=computeHRep(z1);
z2=zonotope(yi21,Pi21);    z2=computeHRep(z2);
z3=zonotope(yi31,Pi31);    z3=computeHRep(z3);
z4=zonotope(yi41,Pi41);    z4=computeHRep(z4);
z5=zonotope(yi51,Pi51);    z5=computeHRep(z5);
z6=zonotope(yi61,Pi61);    z6=computeHRep(z6);
z7=zonotope(yi71,Pi71);    z7=computeHRep(z7);
z8=zonotope(yi81,Pi81);    z8=computeHRep(z8);
z9=zonotope(yi91,Pi91);    z9=computeHRep(z9);
z10=zonotope(yi101,Pi101); z10=computeHRep(z10);
zf10=Polyhedron('H',[[z1.A;z2.A;z3.A;z4.A;z5.A;z6.A;z7.A;z8.A;z9.A;z10.A] [z1.b;z2.b;z3.b;z4.b;z5.b;z6.b;z7.b;z8.b;z9.b;z10.b]]); zf10=computeVRep(zf10); % The common region by H-representation and V-representation
yf10=(max(zf10.V)'+min(zf10.V)')/2;
Pf10=diag(abs(max(zf10.V)'-min(zf10.V)')/2);
TS(7)=toc;
Per(7)=trace(Pf10*Pf10');
%% 图像绘制
x=4:10;
figure; 
plot(x, T(1,:), '-o', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5); 
hold on; % 保留当前图层
plot(x, TS(1,:), '-o', 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.5); 
box on; grid on; % 显示边框和网
%% 按道理来说在相同维度下批次融合和矩阵加权具有相同的维度
Ba41=[P1,zeros(4,24)];
Ba42=[-P1,P21,zeros(4,16);
      -P1,zeros(4,8),P31,zeros(4,8);
      -P1,zeros(4,16),P41];
Ka41=-Ba41*Ba42'*inv(Ba42*Ba42');
PBa4=Ba41+Ka41*Ba42;
trace(PBa4*PBa4');
%% 首先先验证矩阵加权的结果是否正确 首先保持增广的列
tic;
y21=C21'*C21*y1 + C2'*y2;    P21=[C21'*C21*P1,C2'*P2]; 
y31=C31'*C31*y1 + C3'*y3;    P31=[C31'*C31*P1,C3'*P3]; 
y41=C41'*C41*y1 + C4'*y4;    P41=[C41'*C41*P1,C4'*P4]; 
[M4,PM4]=Matrix_Fusion(y1,P1,y21,P21,y31,P31,y41,P41);
T(1,1)=toc;
J(1,1)=trace(PM4*PM4');   
%% 首先先验证矩阵加权的结果是否正确 首先保持相同的列
tic;
yi21=C21'*C21*y1 + C2'*y2;    Pi21=C21'*C21*P1+C2'*P2; 
yi31=C31'*C31*y1 + C3'*y3;    Pi31=C31'*C31*P1+C3'*P3; 
yi41=C41'*C41*y1 + C4'*y4;    Pi41=C41'*C41*P1+C4'*P4; 
[MSi4,PMi4]=Matrix_Fusion(y1,P1,yi21,Pi21,yi31,Pi31,yi41,Pi41);
T(2,1)=toc;
J(2,1)=trace(PMi4*PMi4');
%% 胞性绘图
figure;
c3 = [0; 0; 0];
G3 = [1 0 0 0.5;
      0 1 0 0.5;
      0 0 1 0.5];
Z3 = zonotope(c3, G3);

plot(Z3, 'Filled', true, 'FaceAlpha', 0.5);
title('3D Zonotope 可视化');
grid on; view(3);