 % 80%触发率
%% 初始协方差矩阵和状态
G_1a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);G_1b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
G_2a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);G_2b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
G_3a{1,1}=diag([0.01, 0.01, 0.01, 0.01]);G_3b{1,1}=diag([0.01, 0.01, 0.01, 0.01]);
z_1a{1,1}=[0; v; d; v];           z_1b{1,1}=z_1a{1,1};  
z_2a{1,1}=[d; v; 2*d; v];         z_2b{1,1}=z_2a{1,1};   
z_3a{1,1}=[2*d; v; 3*d; v];       z_3b{1,1}=z_3a{1,1};     
%% 初始化边界
% box半径下的
z_1a_up(:, 1)= x_1(:, 1)+ 0.01*ones(4,1);  z_1a_down(:, 1)= x_1(:, 1)-0.01*ones(4,1); 
z_2a_up(:, 1)= x_2(:, 1)+ 0.01*ones(4,1);  z_2a_down(:, 1)= x_2(:, 1)-0.01*ones(4,1);
z_3a_up(:, 1)= x_3(:, 1)+ 0.01*ones(4,1);  z_3a_down(:, 1)= x_3(:, 1)-0.01*ones(4,1);  
% F半径下的
z_1b_up(:, 1)=z_1a_up(:, 1);   z_1b_down(:, 1)=z_1a_down(:, 1);     
z_2b_up(:, 1)=z_2a_up(:, 1);   z_2b_down(:, 1)=z_2a_down(:, 1);      
z_3b_up(:, 1)=z_3a_up(:, 1);   z_3b_down(:, 1)=z_3a_down(:, 1);      
% 性能指标
Jz_1a(:,1)=0.02^4;Jz_2a(:,1)=0.02^4;Jz_3a(:,1)=0.02^4;
Jz_1b(:,1)=0.02^4;Jz_2b(:,1)=0.02^4;Jz_3b(:,1)=0.02^4;
znum_1a(:,1)=4; znum_2a(:,1)=4; znum_3a(:,1)=4;
znum_1b(:,1)=4; znum_2b(:,1)=4; znum_3b(:,1)=4;
%% 初始化事件触发参数
dz_1e=0.48;dz_2e=0.5;dz_3e=0.5;
T_1z=zeros(1,N);T_2z=zeros(1,N);T_3z=zeros(1,N);
T_1z(1,1)=1;T_2z(1,1)=1;T_3z(1,1)=1;
y1z=y_1(:,1);  y2z=y_2(:,1);  y3z=y_3(:,1);
y11z=y_1(:,1); y22z=y_2(:,1); y33z=y_3(:,1);
%% 定义每个事件触发机制的误差矩阵
Ez_11=dz_1e*eye(4); Ez_22=dz_2e*eye(4); Ez_33=dz_3e*eye(4);
%% zonotope estimator (a和b e和f c和r)
for t=2:N+1
%% 在F半径下的融合处理
 %第一个估计器的融合中心
 N_11b=[G_1b{1,t-1},zeros(4,znum_2b(:,t-1))];
 N_12b=[-C_12intersection*G_1b{1,t-1},C_12overlaping*G_2b{1,t-1}];
 M_1b(:,:,t-1)=-N_11b*N_12b'*inv(N_12b*N_12b');
 z_1c{1,t-1}= (eye(4)-M_1b(:,:,t-1)*C_12intersection)*z_1b{1,t-1} + M_1b(:,:,t-1)*C_12overlaping*z_2b{1,t-1};
 G_1c{1,t-1}= N_11b+M_1b(:,:,t-1)*N_12b; 
 Pz_1c(:,t-1) =sum(abs(G_1c{1,t-1}), 2);
 Jz_1c(:,t-1)=prod(2*Pz_1c(:,t-1));
 z_1c_up(:, t-1)= z_1c{1,t-1} + Pz_1c(:,t-1);
 z_1c_down(:,t-1)=z_1c{1,t-1}- Pz_1c(:,t-1);
 %第二个估计器的融合中心
 N_22b=[G_2b{1,t-1},zeros(4,znum_1b(:,t-1)),zeros(4,znum_3b(:,t-1))];
 N_21b=[-C_21intersection*G_2b{1,t-1},C_21overlaping*G_1b{1,t-1},zeros(2,znum_3b(:,t-1));
        -C_23intersection*G_2b{1,t-1},zeros(2,znum_1b(:,t-1)),C_23overlaping*G_3b{1,t-1}];
 M_2b(:,:,t-1)=-N_22b*N_21b'*inv(N_21b*N_21b');
 z_2c{1,t-1}= (eye(4)-M_2b(:,1:2,t-1)*C_21intersection - M_2b(:,3:4,t-1)*C_23intersection)*z_2b{1,t-1} + M_2b(:,1:2,t-1)*C_21overlaping*z_1b{1,t-1} + M_2b(:,3:4,t-1)*C_23overlaping*z_3b{1,t-1};
 G_2c{1,t-1}= N_22b+M_2b(:,:,t-1)*N_21b;
 Pz_2c(:,t-1) =sum(abs(G_2c{1,t-1}), 2);
 Jz_2c(:,t-1)=prod(2*Pz_2c(:,t-1));
 z_2c_up(:, t-1)=  z_2c{1,t-1} + Pz_2c(:,t-1);
 z_2c_down(:, t-1)=z_2c{1,t-1} - Pz_2c(:,t-1);
 %第三个估计器的融合中心
 N_33b=[G_3b{1,t-1},zeros(4,znum_2b(:,t-1))];
 N_31b=[-C_32intersection*G_3b{1,t-1},C_32overlaping*G_2b{1,t-1}];
 M_3b(:,:,t-1)=-N_33b*N_31b'*inv(N_31b*N_31b');
 z_3c{1,t-1}= (eye(4)-M_3b(:,:,t-1)*C_32intersection)*z_3b{1,t-1} + M_3b(:,:,t-1)*C_32overlaping*z_2b{1,t-1};
 G_3c{1,t-1}= N_33b + M_3b(:,:,t-1)*N_31b;      
 Pz_3c(:,t-1) =sum(abs(G_3c{1,t-1}), 2);
 Jz_3c(:,t-1)=prod(2*Pz_3c(:,t-1));
 z_3c_up(:, t-1)=z_3c{1,t-1}  + Pz_3c(:,t-1);
 z_3c_down(:,t-1)=z_3c{1,t-1} - Pz_3c(:,t-1);
 %% 融合处理（第一个估计器）
 N_11=[G_1a{1,t-1},zeros(4,znum_2a(:,t-1))];
 N_12=[-C_12intersection*G_1a{1,t-1},C_12overlaping*G_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    z_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*z_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*z_2a{1,t-1};
    G_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    Pz_1r(:,t-1)=sum(abs(G_1r{1,t-1}),2);
    Jz_1r(:,t-1)=prod(2*Pz_1r(:,t-1));
    z_1r_up(:, t-1)=  z_1r{1,t-1} + Pz_1r(:,t-1);
    z_1r_down(:,t-1)= z_1r{1,t-1}-  Pz_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[G_2a{1,t-1},zeros(4,znum_1a(:,t-1)),zeros(4,znum_3a(:,t-1))];
  N_21=[-C_21intersection*G_2a{1,t-1},C_21overlaping*G_1a{1,t-1},zeros(2,znum_3a(:,t-1));
                 -C_23intersection*G_2a{1,t-1},zeros(2,znum_1a(:,t-1)),C_23overlaping*G_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  z_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*z_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*z_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*z_3a{1,t-1};
  G_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  Pz_2r(:,t-1) =sum(abs(G_2r{1,t-1}), 2);
  Jz_2r(:,t-1)=prod(2*Pz_2r(:,t-1));
  z_2r_up(:, t-1)= z_2r{1,t-1} + Pz_2r(:,t-1);
  z_2r_down(:, t-1)=z_2r{1,t-1}- Pz_2r(:,t-1);
  %% 融合处理（第三个估计器）
  N_33=[G_3a{1,t-1},zeros(4,znum_2a(:,t-1))];
  N_31=[-C_32intersection*G_3a{1,t-1},C_32overlaping*G_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  z_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*z_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*z_2a{1,t-1};
  G_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  Pz_3r(:,t-1) =sum(abs(G_3r{1,t-1}), 2);
  Jz_3r(:,t-1)=prod(2*Pz_3r(:,t-1));
  z_3r_up(:, t-1)=z_3r{1,t-1}  + Pz_3r(:,t-1);
  z_3r_down(:,t-1)=z_3r{1,t-1} - Pz_3r(:,t-1);
  %% 跳出循环
  if t == N+1
      break;  % 立即终止循环
  end
  % 第一个估计器 在F半径下的中心对称多细胞体估计器设计
  z_1f{1,t} = A_1*z_1c{1,t-1}+U_1(:,t)+A_12*z_2b{1,t-1};
  G_1f{1,t}= [A_1*G_1c{1,t-1},A_12*G_2b{1,t-1},QE1];
  % 第一个估计器 中心对称多细胞体估计器设计
  z_1e{1,t} = A_1*z_1r{1,t-1}+U_1(:,t)+A_12*z_2a{1,t-1};
  G_1e{1,t}= [A_1*G_1r{1,t-1},A_12*G_2a{1,t-1},QE1];
  % 先使用简单的事件触发来设计
  if  norm(y_1(:,t)-y1z,2) <= dz_1e
      T_1z(1,t)=0;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=G_1f{1,t}*G_1f{1,t}'*C_1'*inv(C_1*G_1f{1,t}*G_1f{1,t}'*C_1' +D_1*RE1*RE1'*D_1'+Ez_11*Ez_11'+E_1co*E_1co');
      z_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*z_1f{1,t} + K_1b(:,:,t)*y11z;
      G_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*G_1f{1,t},-K_1b(:,:,t)*RE1,K_1b(:,:,t)*D_1*E_1co,K_1b(:,:,t)*Ez_11];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [G_1e{1,t}, zeros(4,12)];
      Ps1 = [C_1*G_1e{1,t},D_1*RE1,-E_1co,-Ez_11];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      z_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*z_1e{1,t} + K_1(:,:,t)*y11z;
      G_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*G_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co,K_1(:,:,t)*Ez_11];
  else
      y1z=y_1(:,t);
      y11z=coder(y1z,R(1),b1,q1);
      y11z=decoder(y11z,R(1),b1,q1);
      T_1z(1,t)=1;
      % 在F半径下的增益矩阵设计
      K_1b(:,:,t)=G_1f{1,t}*G_1f{1,t}'*C_1'*inv(C_1*G_1f{1,t}*G_1f{1,t}'*C_1' + D_1*RE1*RE1'*D_1'+E_1co*E_1co');
      z_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*z_1f{1,t} + K_1b(:,:,t)*y11z;
      G_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*G_1f{1,t},-K_1b(:,:,t)*D_1*RE1,K_1b(:,:,t)*E_1co];
      % 在box为性能指标下的增益矩阵设计
      Ph1= [G_1e{1,t}, zeros(4,8)];
      Ps1 = [C_1*G_1e{1,t},D_1*RE1,-E_1co];
      row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
      col1s = size(Ph1, 2);  % 获取Phi的列数
      K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
      for i = 1:4
          % 定义决策变量
          l1_i = sdpvar(col1s, 1);      % 向量λ_i
          K1_i = sdpvar(1, 4);             % 矩阵Λ_i
          % 构建约束条件
          Constraints = [
              Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
              Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
              ];
          % 设置目标函数
          Objective = sum(l1_i);
          % 求解优化问题
          result = optimize(Constraints, Objective, options);
          % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              K1_opt(i,:) = value(K1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
          end
      end
      K_1(:,:,t) = K1_opt;
      z_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*z_1e{1,t} + K_1(:,:,t)*y11z;
      G_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*G_1e{1,t},-K_1(:,:,t)*D_1*RE1,K_1(:,:,t)*E_1co];
  end
    % F半径下的
    G_1b{1,t} = Reduction(G_1b{1,t},q);
    znum_1b(:,t)=size(G_1b{1,t},2);
    Pz_1b =sum(abs(G_1b{1,t}),2);
    z_1b_up(:, t)= z_1b{1,t} + Pz_1b;
    z_1b_down(:, t)=z_1b{1,t}-Pz_1b;
    Jz_1b(:,t)=prod(2*Pz_1b);
    % box半径下的
    G_1a{1,t} = Reduction(G_1a{1,t},q);
    znum_1a(:,t)=size(G_1a{1,t},2);
    Pz_1a =sum(abs(G_1a{1,t}), 2);
    z_1a_up(:, t)= z_1a{1,t} + Pz_1a;
    z_1a_down(:, t)=z_1a{1,t}-Pz_1a;
    Jz_1a(:,t)=prod(2*Pz_1a);
    % 第二个估计器  
    % F半径下的
    z_2f{1,t} = A_2*z_2c{1,t-1}+A_21*z_1b{1,t-1}+A_23*z_3b{1,t-1}+U_2(:,t);           
    G_2f{1,t} = [A_2*G_2c{1,t-1}, A_21*G_1b{1,t-1},A_23*G_3b{1,t-1}, QE2];
    % box下的
    z_2e{1,t} = A_2*z_2r{1,t-1}+A_21*z_1a{1,t-1}+A_23*z_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    G_2e{1,t} = [A_2*G_2r{1,t-1}, A_21*G_1a{1,t-1},A_23*G_3a{1,t-1}, QE2];
    % 先使用简单的事件触发来设计
    if  norm(y_2(:,t)-y2z,2) <= dz_2e
        T_2z(1,t)=0;
    % F半径下的增益矩阵设计
      K_2b(:,:,t)=G_2f{1,t}*G_2f{1,t}'*C_2'*inv(C_2*G_2f{1,t}*G_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+Ez_22*Ez_22'+E_2co*E_2co');
      z_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*z_2f{1,t} + K_2b(:,:,t)*y22z;
      G_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*G_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co,K_2b(:,:,t)*Ez_22];
        % box下的增益矩阵设计
        Ph2= [G_2e{1,t}, zeros(4,12)];
        Ps2 = [C_2*G_2e{1,t},D_2*RE2,-E_2co,-Ez_22];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        z_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*z_2e{1,t} + K_2(:,:,t)*y22z;
        G_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*G_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co,K_2(:,:,t)*Ez_22];
    else
        y2z=y_2(:,t);
        y22z=coder(y2z,R(2),b2,q2);
        y22z=decoder(y22z,R(2),b2,q2);
        T_2z(1,t)=1;
        % F半径下的增益矩阵设计
        K_2b(:,:,t)=G_2f{1,t}*G_2f{1,t}'*C_2'*inv(C_2*G_2f{1,t}*G_2f{1,t}'*C_2' + D_2*RE2*RE2'*D_2'+E_2co*E_2co');
        z_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*z_2f{1,t} + K_2b(:,:,t)*y22z;
        G_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*G_2f{1,t},-K_2b(:,:,t)*D_2*RE2,K_2b(:,:,t)*E_2co];
        % box半径下的增益矩阵设计
        Ph2= [G_2e{1,t}, zeros(4,8)];
        Ps2 = [C_2*G_2e{1,t},D_2*RE2,-E_2co];
        row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
        col2s = size(Ph2, 2);  % 获取Phi的列数
        K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l2_i = sdpvar(col2s, 1);      % 向量λ_i
            K2_i = sdpvar(1, 4);          % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
                Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
                ];
            % 设置目标函数
            Objective = sum(l2_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K2_opt(i,:) = value(K2_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_2(:,:,t) = K2_opt;
        z_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*z_2e{1,t} + K_2(:,:,t)*y22z;
        G_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*G_2e{1,t},-K_2(:,:,t)*D_2*RE2,K_2(:,:,t)*E_2co];
    end
   % F半径指标下
    G_2b{1,t} = Reduction(G_2b{1,t},q);
    znum_2b(:,t)=size(G_2b{1,t},2);
    Pz_2b =sum(abs(G_2b{1,t}), 2);
    z_2b_up(:, t)= z_2b{1,t} + Pz_2b;
    z_2b_down(:, t)=z_2b{1,t}- Pz_2b;
    Jz_2b(:,t)=prod(2*Pz_2b);
    % box指标下
    G_2a{1,t} = Reduction(G_2a{1,t},q);
    znum_2a(:,t)=size(G_2a{1,t},2);
    Pz_2a =sum(abs(G_2a{1,t}), 2);
    z_2a_up(:, t)=  z_2a{1,t} + Pz_2a;
    z_2a_down(:, t)=z_2a{1,t}-  Pz_2a;
    Jz_2a(:,t)=prod(2*Pz_2a);
    % 第三个估计器
    % F半径下的
    z_3f{1,t}=A_3*z_3c{1,t-1} +A_32*z_2b{1,t-1}+ U_3(:,t) ;
    G_3f{1,t}=[A_3*G_3c{1,t-1},A_32*G_2b{1,t-1}, QE3];
    % box半径下的
    z_3e{1,t}=A_3*z_3r{1,t-1} +A_32*z_2a{1,t-1}+ U_3(:,t) ;
    G_3e{1,t}=[A_3*G_3r{1,t-1},A_32*G_2a{1,t-1}, QE3];
    if  norm(y_3(:,t)-y3z,2) <= dz_3e
        T_3z(1,t)=0;
        % F半径下的增益矩阵设计
        K_3b(:,:,t)=G_3f{1,t}*G_3f{1,t}'*C_3'*inv(C_3*G_3f{1,t}*G_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3*+Ez_33*Ez_33'+E_3co*E_3co');
        z_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*z_3f{1,t} + K_3b(:,:,t)*y33z;
        G_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*G_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co,K_3b(:,:,t)*Ez_33];
        % box半径下的增益矩阵设计
        Ph3= [G_3e{1,t}, zeros(4,12)];
        Ps3 = [C_3*G_3e{1,t},D_3*RE3,-E_3co,-Ez_33];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);      % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        z_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*z_3e{1,t} + K_3(:,:,t)*y33z;
        G_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*G_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co,K_3(:,:,t)*Ez_33];
    else
        y3z=y_3(:,t);
        y33z=coder(y3z,R(3),b3,q3);
        y33z=decoder(y33z,R(3),b3,q3);
        T_3z(1,t)=1;
       % F半径下的性能指标设计
        K_3b(:,:,t)=G_3f{1,t}*G_3f{1,t}'*C_3'*inv(C_3*G_3f{1,t}*G_3f{1,t}'*C_3' + D_3*RE3*RE3'*D_3'+E_3co*E_3co');
        z_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*z_3f{1,t} + K_3b(:,:,t)*y33z;
        G_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*G_3f{1,t},-K_3b(:,:,t)*D_3*RE3,K_3b(:,:,t)*E_3co];
        % box半径下的性能指标设计
        Ph3= [G_3e{1,t}, zeros(4,8)];
        Ps3 = [C_3*G_3e{1,t},D_3*RE3,-E_3co];
        row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
        col3s = size(Ph3, 2);  % 获取Phi的列数
        K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
        for i = 1:4
            % 定义决策变量
            l3_i = sdpvar(col3s, 1);         % 向量λ_i
            K3_i = sdpvar(1, 4);             % 矩阵Λ_i
            % 构建约束条件
            Constraints = [
                Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
                Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
                ];
            % 设置目标函数
            Objective = sum(l3_i);
            % 求解优化问题
            result = optimize(Constraints, Objective, options);
            % 检查求解结果
            if result.problem == 0  % 如果问题求解成功
                K3_opt(i,:) = value(K3_i);  % 存储最优解
            else  % 如果求解失败
                disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
                disp('错误信息:');
                disp(result.info);  % 输出错误信息
                K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
            end
        end
        K_3(:,:,t) = K3_opt;
        z_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*z_3e{1,t} + K_3(:,:,t)*y33z;
        G_3a{1,t} = [(eye(4)-K_3(:,:,t)*C_3)*G_3e{1,t},-K_3(:,:,t)*D_3*RE3,K_3(:,:,t)*E_3co];
    end

    %% F半径下的
    G_3b{1,t} = Reduction(G_3b{1,t},q);
    znum_3b(:,t)=size(G_3b{1,t},2);
    Pz_3b =sum(abs(G_3b{1,t}), 2);
    z_3b_up(:, t)= z_3b{1,t} + Pz_3b;
    z_3b_down(:, t)=z_3b{1,t}- Pz_3b;
    Jz_3b(:,t)=prod(2*Pz_3b);
    %% box半径下的
    G_3a{1,t} = Reduction(G_3a{1,t},q);
    znum_3a(:,t)=size(G_3a{1,t},2);
    Pz_3a =sum(abs(G_3a{1,t}), 2);
    z_3a_up(:, t)= z_3a{1,t} + Pz_3a;
    z_3a_down(:, t)=z_3a{1,t}- Pz_3a;
    Jz_3a(:,t)=prod(2*Pz_3a);
end
%% 状态估计图
plot(1:N,  x_2(4, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  z_2a_up(4, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2a_down(4, :), 'r', 'LineWidth', 1.5);
plot(1:N,  z_2r_up(4, :), 'b--', 'LineWidth', 1.5);
plot(1:N,  z_2r_down(4, :), 'b--', 'LineWidth', 1.5);
legend('真实状态','估计上界','估计下界','融合上界','融合下界');
%% 性能指标图
plot(1:N,  log10(Jz_2a(1, :)), 'k', 'LineWidth', 1.5);hold on
plot(1:N,  log10(Jz_2b(1, :)), 'r--', 'LineWidth', 1.5);
plot(1:N,  log10(Jz_2r(1, :)), 'g', 'LineWidth', 1.5);
plot(1:N,  log10(Jz_2c(1, :)), 'b--', 'LineWidth', 1.5);
legend('box估计','F估计','box融合','F融合');
sum(T_1z);
sum(T_2z);
sum(T_3z);
sum(Jz_1c)/N;
sum(Jz_1r)/N;




