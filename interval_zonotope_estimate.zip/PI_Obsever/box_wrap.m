function [new_c, new_R] = box_wrap(c, R)
    % 获取生成矩阵 R 的行数和列数
    [n, r] = size(R);
    
    % 根据 r 和 n 的关系计算包裹后的生成矩阵
    if r > n
        % 计算 R 每列元素绝对值的和
        col_sums = sum(abs(R), 2);
        % 生成对角矩阵
        new_R = diag(col_sums);
    else
        new_R = R;
    end
    
    % 包裹后的中心保持不变
    new_c = c;
end