function [p, c] = Z_to_strips(Z)
% Input: A zonotope;
% Output: Strips;
    A=Z.A;
    b=Z.b;
    r=size(A,1)/2;
    n=size(A,2);
    A1=A./repmat(A(:,1),1,n); %  归一化处理
    b1=b./A(:,1);
    if n==2
        for i=1:2^(n-1)*r/2
            A2(2*i-1,:)=A1(i,:);
            A2(2*i,:)=A1(i+2^(n-1)*r/2,:);
            b2(2*i-1,:)=b1(i,:);
            b2(2*i,:)=b1(i+2^(n-1)*r/2,:);
        end
        A1=A2;b1=b2;
    end
    for i=1:2^(n-1)*r/2
        d(i)=abs(b1(2*i)-b1(2*i-1))/2;
    end
    for i=1:2^(n-1)*r/2
        A1(2*i-1,:)=A1(2*i-1,:)./d(i);
        A1(2*i,:)=A1(2*i,:)./d(i);
        b1(2*i-1,:)=b1(2*i-1,:)./d(i);
        b1(2*i,:)=b1(2*i,:)./d(i);
    end
    for i=1:2^(n-1)*r/2
        p(i,:)=A1(2*i,:);
        c(i,:)=(b1(2*i-1,:)+b1(2*i,:))/2;
    end
end

