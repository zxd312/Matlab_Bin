c=[0;0;0;0];
R1=2*rand(4,8)-1;
Z1=zonotope(c,R1);
[H, b] = Z_to_strips(Z1);
