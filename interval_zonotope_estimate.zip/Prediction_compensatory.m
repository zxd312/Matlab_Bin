clc
clear
close all;
N=50;   % Time steps
numbers=4; 
d=1;    %init position
v=0.1;  %init velocity
%% Overall System
k=2;
c=2;
Ts=0.05;
% car quality
for i = 1:numbers
   m(i) = 10 + 5 * rand;
end
% 定义 A 矩阵
A = [0, 1, 0, 0, 0, 0, 0, 0;
    -k/m(1), -c/m(1), k/m(1), c/m(1), 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0;
    k/m(2), c/m(2), -2*k/m(2), -2*c/m(2), k/m(2), c/m(2), 0, 0;             
    0, 0, 0, 0, 0, 1, 0, 0;
    0, 0, k/m(3), c/m(3), -2*k/m(3), -2*c/m(3), k/m(3), c/m(3);
    0, 0, 0, 0, 0, 0, 0, 1;
    0, 0, 0, 0, k/m(4), c/m(4), -2*k/m(4), -2*c/m(4)];
%% 定义重叠部分的索引矩阵(直接定义重叠索引矩阵即可)
C_12overlaping= [eye(2,2),zeros(2,2)];   C_12intersection=[zeros(2,2),eye(2,2)]; C_12=[eye(2,2),zeros(2,2)];
C_21overlaping= [zeros(2,2),eye(2,2)];   C_23overlaping= [eye(2,2),zeros(2,2)];  C_21=[zeros(2,2),eye(2,2)];
C_21intersection=[eye(2,2),zeros(2,2)];  C_23intersection=[zeros(2,2),eye(2,2)]; C_23=[eye(2,2),zeros(2,2)];
C_32overlaping= [zeros(2,2),eye(2,2)];   C_32intersection= [eye(2,2),zeros(2,2)];C_32=[zeros(2,2),eye(2,2)];
%% block discretization
%  block
A_1d=A(1:2,1:2);A_12d=A(1:2,3:4);
A_2d=A(3:4,3:4);A_21d=A(3:4,1:2);A_23d=A(3:4,5:6);
A_3d=A(5:6,5:6);A_32d=A(5:6,3:4);A_34d=A(5:6,7:8);
A_4d=A(7:8,7:8);A_43d=A(7:8,5:6);
U_11=[0;1/m(1)];U_22=[0;1/m(2)];U_33=[0;1/m(3)];U_44=[0;1/m(4)];
% discretization
A_1b = expm(A_1d*Ts);
fun_12 = @(t) expm(A_1d*t) * A_12d;
A_12b = integral(fun_12, 0, Ts, 'ArrayValued', true);

A_2b = expm(A_2d * Ts);
fun_21 = @(t) expm(A_2d*t) * A_21d;
A_21b = integral(fun_21, 0, Ts, 'ArrayValued', true);

fun_23 = @(t) expm(A_2d*t) * A_23d;
A_23b = integral(fun_23, 0, Ts, 'ArrayValued', true);

A_3b = expm(A_3d * Ts);
fun_32 = @(t) expm(A_3d * t) * A_32d;
A_32b = integral(fun_32, 0, Ts, 'ArrayValued', true);

fun_34 = @(t) expm(A_3d * t) * A_34d;
A_34b = integral(fun_34, 0, Ts, 'ArrayValued', true);

A_4b = expm(A_4d * Ts);
fun_43 = @(t) expm(A_4d * t) * A_43d;
A_43b = integral(fun_43, 0, Ts, 'ArrayValued', true);
%% 这部分还是先不考虑状态重叠，每部分都是二维分量的化比较容易求解
A_1=A_1b;   A_12=A_12b;
A_2=A_2b;   A_21=A_21b; A_23=A_23b;
A_3=A_3b;   A_32=A_32b; A_34=A_34b;
A_4=A_4b;   A_43=A_43b;
%% 系统矩阵
C=eye(2);C_1=C;C_2=C;C_3=C;C_4=C;
%% 生成噪声
w_1= 2*rand(2,N)-1; w_2= 2*rand(2,N)-1;
w_3= 2*rand(2,N)-1; w_4= 2*rand(2,N)-1;
v_1= 1*rand(2,N)-0.5; v_2= 1*rand(2,N)-0.5;
v_3= 1*rand(2,N)-0.5;v_4= 1*rand(2,N)-0.5;
%% 初始化状态（第一个估计器）
x_1a(:, 1)=[0; v];  x_1e(:, 1)=[0; v];  x_2a(:, 1)=[d; v];  x_2e(:, 1)=[d; v];    
x_3a(:, 1)=[2*d; v];x_3e(:, 1)=[2*d; v];x_4a(:, 1)=[3*d; v];x_4e(:, 1)=[3*d; v]; 
x_1(:, 1)=[0; v];   x_2(:, 1)=[d; v]; x_3(:, 1)=[2*d; v]; x_4(:, 1)=[3*d; v];
%% 初始化状态（第二个估计器）
x_1b(:, 1)=[0; v];  x_1d(:, 1)=[0; v];  x_2b(:, 1)=[d; v];  x_2d(:, 1)=[d; v];    
x_3b(:, 1)=[2*d; v];x_3d(:, 1)=[2*d; v];x_4b(:, 1)=[3*d; v];x_4d(:, 1)=[3*d; v];
%% 事件触发参数初始化（第一个系统）
x_12c=x_2a(:, 1); E_12c=zeros(2,2);  x_12b=x_2b(:, 1); E_12b=zeros(2,2); % 关于第一个估计器的事件触发
x_21c=x_1a(:, 1); E_21c=zeros(2,2);  x_21b=x_1b(:, 1); E_21b=zeros(2,2); % 关于第二个估计器的事件触发
x_23c=x_3a(:, 1); E_23c=zeros(2,2);  x_23b=x_3b(:, 1); E_23b=zeros(2,2); % 关于第二个估计器的事件触发
x_32c=x_2a(:, 1); E_32c=zeros(2,2);  x_32b=x_2b(:, 1); E_32b=zeros(2,2); % 关于第三个估计器的事件触发  
x_34c=x_4a(:, 1); E_34c=zeros(2,2);  x_34b=x_4b(:, 1); E_34b=zeros(2,2); % 关于第三个估计器的事件触发  
x_43c=x_3a(:, 1); E_43c=zeros(2,2);  x_43b=x_3b(:, 1); E_43b=zeros(2,2); % 关于第四个估计器的事件触发  
omega=1; % 阈值参数
%% 先不考虑融合
for t=2:N
 F1(:,t)=4 * rand;  F2(:,t)=4 * rand;    % 控制器部分
 F3(:,t)=4 * rand;  F4(:,t)=4 * rand;
 U_1(:,t)=F1(:,t)*U_11; U_2(:,t)=F2(:,t)*U_22; U_3(:,t)=F3(:,t)*U_33; U_4(:,t)=F4(:,t)*U_44;
 % 状态更新
 x_1(:, t) = A_1 * x_1(:, t-1) + U_1(:,t) + w_1(:, t) + A_12 * x_2(:, t-1) ;
 x_2(:, t) = A_2 * x_2(:, t-1) + U_2(:,t) + w_2(:, t) + A_21 * x_1(:, t-1) + A_23 * x_3(:, t-1);
 x_3(:, t) = A_3 * x_3(:, t-1) + U_3(:,t) + w_3(:, t) + A_32 * x_2(:, t-1) + A_34 * x_4(:, t-1);
 x_4(:, t) = A_4 * x_4(:, t-1) + U_4(:,t) + w_4(:, t) + A_43 * x_3(:, t-1);
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + v_1(:, t);    % 先考虑满秩的情况，因为满秩的时候会存在解析解
 y_2(:, t) = C_2 * x_2(:, t) + v_2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + v_3(:, t);
 y_4(:, t) = C_4 * x_4(:, t) + v_4(:, t);
 %% 第一个估计器设计
if norm(x_2a(:,t-1)-x_12c,2) <= omega
   E_12c=omega*eye(2);
   T_12(1,t-1)=0;
else
   E_12c=zeros(2,2);
   T_12(1,t-1)=1;
   x_12c=x_2a(:,t-1);
end
 x_1e(:, t) = A_1 * x_1a(:, t-1) + U_1(:,t) + A_12 * x_12c ;
 R_1e{1,t}  = A_12 *E_12c;
 x_y1(:, t)=C_1* x_1e(:, t); X_y1{1,t}=C_1* R_1e{1,t}; 
 % 用于判断y是否在Cx的范围中，如果在的话就将Cx=y，来改变x，
 % 如果不在的话，找到y距凸集最远的点b，让Cx=b。
 if( isPointInZonotope(y_1(:, t), x_y1(:, t), X_y1{1,t})==1)
  
  x_1e(:, t)=inv(C_1)*y_1(:, t);    % 让预测更加相信观测值
  x_1a(:, t)=x_1e(:, t);
 else
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
  b_1=getNearestPoint(y_1(:, t), x_y1(:, t),X_y1{1,t});
  x_1e(:, t)=inv(C_1)*b_1; 
 % 接下来需要求解一个优化问题来获得误差的上界，从而得到一个最优增益K_1
 % 定义优化变量
 K_1 = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_1 = sdpvar(1);          % λ(k) ∈ ℝ
 K_c1 = (eye(2) - K_1 * C_1) * A_1;
 K_w1 = (eye(2) - K_1 * C_1);
 K_12 = (eye(2) - K_1 * C_1) * A_12;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
K11 = [K_c1,K_1,K_w1,K_12,(1-T_12(1,t-1))*K_12];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI11 = [-eye(2), K11; K11', -lambda_1 * eye(10)] <= -1e-10 * eye(12);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI12 = [-eye(2), K_c1; K_c1', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI11, LMI12];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_1, options);

 if result.problem == 0  % 如果问题求解成功
     K1_opt{1,t} = value(K_1);  % 存储最优解
     lambda1_opt(t,:) = value(lambda_1);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息
   K1_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end

 x_1a(:, t)=x_1e(:, t)+K1_opt{1,t}*(y_1(:, t)-C_1*x_1e(:, t));
 end
%% 第二个估计器设计
if norm(x_1a(:,t-1)-x_21c,2) <= omega
   E_21c=omega*eye(2);
   T_21(1,t-1)=0;
else
   E_21c=zeros(2,2);
   T_21(1,t-1)=1;
   x_21c=x_1a(:,t-1);
end

if norm(x_3a(:,t-1)-x_23c,2) <= omega
   E_23c=omega*eye(2);
   T_23(1,t-1)=0;
else
   E_23c=zeros(2,2);
   T_23(1,t-1)=1;
   x_23c=x_3a(:,t-1);
end
 x_2e(:, t) = A_2 * x_2a(:, t-1) + U_2(:,t) + A_21 * x_21c + A_23 * x_23c ;
 R_2e{1,t}=[A_21*E_21c,A_23*E_23c];
 x_y2(:, t)=C_2* x_2e(:, t); X_y2{1,t}=C_2* R_2e{1,t}; 
 % 用于判断y是否在Cx的范围中，如果在的话就将Cx=y，来改变x，
 % 如果不在的话，找到y距凸集最远的点b，让Cx=b。
 if( isPointInZonotope(y_2(:, t), x_y2(:, t), X_y2{1,t})==1)
  x_2e(:, t)=inv(C_2)*y_2(:, t);    % 让预测更加相信观测值
  x_2a(:, t)=x_2e(:, t);
 else
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
  b_2=getNearestPoint(y_2(:, t), x_y2(:, t),X_y2{1,t});
  x_2e(:, t)=inv(C_2)*b_2; 
 % 接下来需要求解一个优化问题来获得误差的上界，从而得到一个最优增益K_2
 % 定义优化变量
 K_2 = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_2 = sdpvar(1);          % λ(k) ∈ ℝ
 K_c2 = (eye(2) - K_2 * C_2) * A_1;
 K_w2 = (eye(2) - K_2 * C_2);
 K_21 = (eye(2) - K_2 * C_2) * A_21;
 K_23 = (eye(2) - K_2 * C_2) * A_23;

% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
 K22 = [K_c2,K_2,K_w2,K_21,K_23,(1-T_21(1,t-1))*K_21,(1-T_23(1,t-1))*K_23];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI21 = [-eye(2), K22; K22', -lambda_2 * eye(14)] <= -1e-10 * eye(16);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI22 = [-eye(2), K_c2; K_c2', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI21, LMI22];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_2, options);

 if result.problem == 0  % 如果问题求解成功
     K2_opt{1,t} = value(K_2);  % 存储最优解
     lambda2_opt(t,:) = value(lambda_2);
 else  % 如果求解失败
   disp('优化问题求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息 
   K2_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_2a(:, t)=x_2e(:, t)+K2_opt{1,t}*(y_2(:, t)-C_2*x_2e(:, t));
 end
%% 第三个估计器
if norm(x_2a(:,t-1)-x_32c,2) <= omega
   E_32c=omega*eye(2);
   T_32(1,t-1)=0;
else
   E_32c=zeros(2,2);
   T_32(1,t-1)=1;
   x_32c=x_2a(:,t-1);
end

if norm(x_4a(:,t-1)-x_34c,2) <= omega
   E_34c=omega*eye(2);
   T_34(1,t-1)=0;
else
   E_34c=zeros(2,2);
   T_34(1,t-1)=1;
   x_34c=x_4a(:,t-1);
end
 x_3e(:, t) = A_3 * x_3a(:, t-1) + U_3(:,t) + A_34 * x_34c + A_32 * x_32c ;
 R_3e{1,t}=[A_32*E_32c,A_34*E_34c];
 x_y3(:, t)=C_3* x_3e(:, t); X_y3{1,t}=C_3* R_3e{1,t}; 
 % 用于判断y是否在Cx的范围中，如果在的话就将Cx=y，来改变x，
 % 如果不在的话，找到y距凸集最远的点b，让Cx=b。
 if( isPointInZonotope(y_3(:, t), x_y3(:, t), X_y3{1,t})==1)
  x_3e(:, t)=inv(C_3)*y_3(:, t);    % 让预测更加相信观测值
  x_3a(:, t)=x_3e(:, t);
 else
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
  b_3=getNearestPoint(y_3(:, t), x_y3(:, t),X_y3{1,t});
  x_3e(:, t)=inv(C_3)*b_3; 
 % 接下来需要求解一个优化问题来获得误差的上界，从而得到一个最优增益K_2
 % 定义优化变量
 K_3 = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_3 = sdpvar(1);          % λ(k) ∈ ℝ
 K_c3 = (eye(2) - K_3 * C_3) * A_3;
 K_w3 = (eye(2) - K_3 * C_3);
 K_32 = (eye(2) - K_3 * C_3) * A_32;
 K_34 = (eye(2) - K_3 * C_3) * A_34;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
 K33 = [K_c3,K_3,K_w3,K_32,K_34,(1-T_32(1,t-1))*K_32,(1-T_34(1,t-1))*K_34];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI31 = [-eye(2), K33; K33', -lambda_3 * eye(14)] <= -1e-10 * eye(16);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI32 = [-eye(2), K_c3; K_c3', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI31, LMI32];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_3, options);

 if result.problem == 0  % 如果问题求解成功
     K3_opt{1,t} = value(K_3);  % 存储最优解
     lambda3_opt(t,:) = value(lambda_3);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息 
   K3_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_3a(:, t)=x_3e(:, t)+K3_opt{1,t}*(y_3(:, t)-C_3*x_3e(:, t));
 end
%% 第四个估计器
if norm(x_3a(:,t-1)-x_43c,2) <= omega
   E_43c=omega*eye(2);
   T_43(1,t-1)=0;
else
   E_43c=zeros(2,2);
   T_43(1,t-1)=1;
   x_43c=x_3a(:,t-1);
end
 x_4e(:, t) = A_4 * x_4a(:, t-1) + U_4(:,t) + A_43 * x_43c ;
 R_4e{1,t}  = A_43 *E_43c;
 x_y4(:, t)=C_4* x_4e(:, t); X_y4{1,t}=C_4* R_4e{1,t}; 
 % 用于判断y是否在Cx的范围中，如果在的话就将Cx=y，来改变x，
 % 如果不在的话，找到y距凸集最远的点b，让Cx=b。
 if( isPointInZonotope(y_4(:, t), x_y4(:, t), X_y4{1,t})==1)
  x_4e(:, t)=inv(C_4)*y_4(:, t);    % 让预测更加相信观测值
  x_4a(:, t)=x_4e(:, t);
 else
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
  b_4=getNearestPoint(y_4(:, t), x_y4(:, t),X_y4{1,t});
  x_4e(:, t)=inv(C_4)*b_4; 
 % 接下来需要求解一个优化问题来获得误差的上界，从而得到一个最优增益K_1
 % 定义优化变量
 K_4 = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_4 = sdpvar(1);          % λ(k) ∈ ℝ
 K_c4 = (eye(2) - K_4 * C_4) * A_4;
 K_w4 = (eye(2) - K_4 * C_4);
 K_43 = (eye(2) - K_4 * C_4) * A_43;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
K44 = [K_c4,K_4,K_w4,K_43,(1-T_43(1,t-1))*K_43];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI41 = [-eye(2), K44; K44', -lambda_4 * eye(10)] <= -1e-10 * eye(12);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI42 = [-eye(2), K_c4; K_c4', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI41, LMI42];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_4, options);

 if result.problem == 0  % 如果问题求解成功
     K4_opt{1,t} = value(K_4);  % 存储最优解
     lambda4_opt(t,:) = value(lambda_4);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息
   K4_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end

 x_4a(:, t)=x_4e(:, t)+K4_opt{1,t}*(y_4(:, t)-C_4*x_4e(:, t));
 end
end

%% 不进行补偿的

for t=2:N
 %% 第一个估计器设计
if norm(x_2b(:,t-1)-x_12b,2) <= omega
   E_12b=omega*eye(2);
   T_12b(1,t-1)=0;
else
   E_12b=zeros(2,2);
   T_12b(1,t-1)=1;
   x_12b=x_2b(:,t-1);
end
 x_1d(:, t) = A_1 * x_1b(:, t-1) + U_1(:,t) + A_12 * x_12b ;
 K_1b = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_1b = sdpvar(1);          % λ(k) ∈ ℝ
 K_c1b = (eye(2) - K_1b * C_1) * A_1;
 K_w1b = (eye(2) - K_1b * C_1);
 K_12b = (eye(2) - K_1b * C_1) * A_12;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
K11b = [K_c1b,K_1b,K_w1b,K_12b];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI11b = [-eye(2), K11b; K11b', -lambda_1b * eye(8)] <= -1e-10 * eye(10);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI12b = [-eye(2), K_c1b; K_c1b', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI11b, LMI12b];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_1b, options);

 if result.problem == 0  % 如果问题求解成功
     K1b_opt{1,t} = value(K_1b);  % 存储最优解
     lambda1b_opt(t,:) = value(lambda_1b);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息
   K1b_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_1b(:, t)=x_1d(:, t)+K1b_opt{1,t}*(y_1(:, t)-C_1*x_1d(:, t));

%% 第二个估计器设计
if norm(x_1b(:,t-1)-x_21b,2) <= omega
   E_21b=omega*eye(2);
   T_21b(1,t-1)=0;
else
   E_21b=zeros(2,2);
   T_21b(1,t-1)=1;
   x_21b=x_1b(:,t-1);
end

if norm(x_3b(:,t-1)-x_23b,2) <= omega
   E_23b=omega*eye(2);
   T_23b(1,t-1)=0;
else
   E_23b=zeros(2,2);
   T_23b(1,t-1)=1;
   x_23b=x_3b(:,t-1);
end
 x_2d(:, t) = A_2 * x_2b(:, t-1) + U_2(:,t) + A_21 * x_21b + A_23 * x_23b ;
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
 K_2b = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_2b = sdpvar(1);          % λ(k) ∈ ℝ
 K_c2b = (eye(2) - K_2b * C_2) * A_1;
 K_w2b = (eye(2) - K_2b * C_2);
 K_21b = (eye(2) - K_2b * C_2) * A_21;
 K_23b = (eye(2) - K_2b * C_2) * A_23;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
 K22b = [K_c2b,K_2b,K_w2b,K_21b,K_23b];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI21b = [-eye(2), K22b; K22b', -lambda_2b * eye(10)] <= -1e-10 * eye(12);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI22b = [-eye(2), K_c2b; K_c2b', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI21b, LMI22b];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_2b, options);

 if result.problem == 0  % 如果问题求解成功
     K2b_opt{1,t} = value(K_2b);  % 存储最优解
     lambda2b_opt(t,:) = value(lambda_2b);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息 
   K2b_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_2b(:, t)=x_2d(:, t)+K2b_opt{1,t}*(y_2(:, t)-C_2*x_2d(:, t));

%% 第三个估计器
if norm(x_2b(:,t-1)-x_32b,2) <= omega
   E_32b=omega*eye(2);
   T_32b(1,t-1)=0;
else
   E_32b=zeros(2,2);
   T_32b(1,t-1)=1;
   x_32b=x_2b(:,t-1);
end

if norm(x_4b(:,t-1)-x_34b,2) <= omega
   E_34b=omega*eye(2);
   T_34b(1,t-1)=0;
else
   E_34b=zeros(2,2);
   T_34b(1,t-1)=1;
   x_34b=x_4b(:,t-1);
end
 x_3d(:, t) = A_3 * x_3b(:, t-1) + U_3(:,t) + A_34 * x_34b + A_32 * x_32b ;
 % 这种情况比较复杂需要找一个函数找到y与CX的zonotope中最远的点             
 K_3b = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_3b = sdpvar(1);          % λ(k) ∈ ℝ
 K_c3b = (eye(2) - K_3b * C_3) * A_3;
 K_w3b= (eye(2) - K_3b * C_3);
 K_32b = (eye(2) - K_3b * C_3) * A_32;
 K_34b = (eye(2) - K_3b * C_3) * A_34;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
 K33b = [K_c3b,K_3b,K_w3b,K_32b,K_34b];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI31b = [-eye(2), K33b; K33b', -lambda_3b * eye(10)] <= -1e-10 * eye(12);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI32b = [-eye(2), K_c3b; K_c3b', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI31b, LMI32b];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_3b, options);

 if result.problem == 0  % 如果问题求解成功
     K3b_opt{1,t} = value(K_3b);  % 存储最优解
     lambda3b_opt(t,:) = value(lambda_3b);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息 
   K3b_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_3b(:, t)=x_3d(:, t)+K3b_opt{1,t}*(y_3(:, t)-C_3*x_3d(:, t));
%% 第四个估计器
if norm(x_3b(:,t-1)-x_43b,2) <= omega
   E_43b=omega*eye(2);
   T_43b(1,t-1)=0;
else
   E_43b=zeros(2,2);
   T_43(1,t-1)=1;
   x_43b=x_3b(:,t-1);
end
 x_4d(:, t) = A_4 * x_4b(:, t-1) + U_4(:,t) + A_43 * x_43b ;
 K_4b = sdpvar(2, 2, 'full');  % K_c(k) ∈ ℝ^{p×n}
 lambda_4b = sdpvar(1);          % λ(k) ∈ ℝ
 K_c4b = (eye(2) - K_4b * C_4) * A_4;
 K_w4b = (eye(2) - K_4b * C_4);
 K_43b = (eye(2) - K_4b * C_4) * A_43;
% 构造 K(k) = [K_c1, K_omega, K_c, K_theta]
K44b = [K_c4b,K_4b,K_w4b,K_43b];
% 第一个约束: [-I, K11; *, -λI] ≤ 0
LMI41b = [-eye(2), K44b; K44b', -lambda_4b * eye(8)] <= -1e-10 * eye(10);
% 第二个约束: [-I, K_x; *, -I] < 0
LMI42b = [-eye(2), K_c4b; K_c4b', -eye(2)] <= -1e-10 * eye(4);  % 严格不等式近似
constraints = [LMI41b, LMI42b];
options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 求解优化问题
 result = optimize(constraints, lambda_4b, options);

 if result.problem == 0  % 如果问题求解成功
     K4b_opt{1,t} = value(K_4b);  % 存储最优解
     lambda4b_opt(t,:) = value(lambda_4b);
 else  % 如果求解失败
   disp('优化问题在求解失败');
   disp('错误信息:');
   disp(result.info);  % 输出错误信息
   K4b_opt{1,t} = NaN;  % 如果失败，设定为NaN
 end
 x_4b(:, t)=x_4d(:, t)+K4b_opt{1,t}*(y_4(:, t)-C_4*x_4d(:, t));
end
RMSE1=mean((x_1 - x_1a).^2);          
RMSE1b=mean((x_1 - x_1b).^2);
%% 绘图
subplot(1, 2, 1);
plot(1:N, x_1(1, :), 'k', 'LineWidth', 1.5);hold on
plot(1:N, x_1a(1, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b(1, :), 'm', 'LineWidth', 1.5);
plot(1:N, y_1(1, :), 'b', 'LineWidth', 1.5);
legend('真实值','补偿的估计值','不补偿的估计值','观测值');
subplot(1, 2, 2);
plot(1:N, x_1(2, :), 'k', 'LineWidth', 1.5);hold on;
plot(1:N, x_1a(2, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b(1, :), 'm', 'LineWidth', 1.5);
plot(1:N, y_1(2, :), 'b', 'LineWidth', 1.5);
legend('真实值','补偿的估计值','不补偿的估计值','观测值');
%% 误差曲线绘制
plot(1:N, RMSE1, 'k', 'LineWidth', 1.5);hold on
plot(1:N, RMSE1b, 'r', 'LineWidth', 1.5);
legend('补偿的','不带补偿的');
%% 做一个简单的扩维和不扩维之间的性能比较
c_1=[0;0];R_1=diag([1,2]);
c_2=[0;0];R_2=diag([1,1]);
c_21=0;R_21=1;
C_21=[0,1];
%% 1与2先融合
K_1r=R_1*R_1'*inv(R_1*R_1'+R_2*R_2');
c_1r=(eye(2)-K_1r)*c_1 + K_1r*c_2 ;
R_1r=[(eye(2)-K_1r)*R_1 ,K_1r*R_2]; 
Z_1r=zonotope(c_1r,R_1r);
%% 降维之后的融合
K_21r=R_1*R_1'*C_21'*inv(C_21*R_1*R_1'*C_21'+R_21*R_21');
c_21r=(eye(2)-K_1r*C_21')*c_1 + K_21r*c_21;
R_21r=[(eye(2)-K_21r*C_21)*R_1 ,K_21r*R_21]; 
Z_21r=zonotope(c_21r,R_21r);
figure(1)
hold on
plot(Z_1r,'color','k','alpha',0.3);
