clc
clear
%% 系统参数
N=100; %迭代次数
A=[1 0.1 0 0;0 1 0 0;0 0 1 0.1;0 0 0 1];
C=eye(4);
B=eye(4);
% Dw=0.01*eye(4);
% Dv=0.01*eye(2);
Hw=diag([0.1,0.01,0.1,0.01]);
Hv=0.04*eye(4);
q=10; %降维参数
%% 噪声生成
for t=1:N
    w_1(:,t)=0.1*sin(t-1);
    w_2(:,t)=0.01*cos(t-1);
    w_3(:,t)=0.1*cos(t-1);
    w_4(:,t)=0.01*sin(t-1);
    v_1(:,t)=0.02+0.02*sin(t-1);
    v_2(:,t)=0.02-0.02*sin(t-1);
    v_3(:,t)=0.02+0.02*cos(t-1);
    v_4(:,t)=0.02-0.02*sin(t-1);
    W_1(:,t)=[w_1(:,t);w_2(:,t);w_3(:,t); w_4(:,t)];
    V_1(:,t)=[v_1(:,t);v_2(:,t);v_3(:,t);v_4(:,t)];
end

%% 初始化参数
x(:, 1)=[10;0;0;2];
c_1a{1,1}=[10;0;0;2];c_1e{1,1}=[10;0;0;2];            x_1a_up(:, 1)= c_1a{1,1};
R_1a{1,1}=0.04*eye(4); R_1e{1,1}=0.04*eye(4);         x_1a_down(:, 1)= c_1a{1,1};
%% 系统迭代
for t=2:N  
    % 状态更新
    x(:, t) = A * x(:, t-1) + W_1(:, t) ;
    % 观测更新
    y(:, t) = C*x(:, t) +  V_1(:, t);
    % 估计器设计
    c_1e{1,t} = A*c_1a{1,t-1};
    R_1e{1,t}= [A*R_1a{1,t-1},Hw];
    P_1e=sum(abs(R_1e{1,t}), 2);
    %% 增益矩阵通过求解一个优化问题
    Phi = [R_1e{1,t}, zeros(4,4)];
    Psi = [C*R_1e{1,t}, Hv];
    rows = size(Phi, 1);  % 获取Phi的行数（循环次数）
    cols = size(Phi, 2);  % 获取Phi的列数
    % 预分配结果矩阵
    Lambda_opt = zeros(rows, 4);  % 存储所有Lambda_i的最优解
    % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-8, ... % 求解精度
        'sedumi.maxiter', 100); % 最大迭代次数
    % 使用循环求解优化问题
    for i = 1:rows
        % 定义决策变量
        lambda_i = sdpvar(cols, 1);      % 向量λ_i
        Lambda_i = sdpvar(1, 4);         % 矩阵Λ_i

        % 构建约束条件
        Constraints = [
            Phi(i,:)' - Psi'*Lambda_i' >= -lambda_i,
            Phi(i,:)' - Psi'*Lambda_i' <= lambda_i
            ];

        % 设置目标函数
        Objective = sum(lambda_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
              Lambda_opt(i,:) = value(Lambda_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              Lambda_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end

    % 最终结果矩阵
    Lambda = Lambda_opt;
    %%  观测更新
    c_1a{1,t}= (eye(4)-Lambda*C)*c_1e{1,t} + Lambda*y(:,t);
    R_1a{1,t}= [(eye(4)-Lambda*C)*R_1e{1,t},-Lambda*Hv];
    R_1a{1,t} = Reduction(R_1a{1,t},q);
    P_1a(:,t)=sum(abs(R_1a{1,t}), 2);
    x_1a_up(:, t)=  c_1a{1,t}+P_1a(:,t);
    x_1a_down(:, t)=c_1a{1,t}-P_1a(:,t);
end
%% F半径指标下的估计器
% 初始化估计器的参数要和第一个估计器的参数保持一致
c_1b{1,1}=[10;0;0;2];c_1c{1,1}=[10;0;0;2];             x_1b_up(:, 1)= c_1b{1,1};
R_1b{1,1}=0.04*eye(4);  R_1c{1,1}=0.04*eye(4);         x_1b_down(:, 1)= c_1b{1,1};
%% 系统迭代
for t=2:N  
% 真实状态更新和观测更新这里不再叙述，第一个估计器已经得到了
% 估计器设计
    c_1c{1,t} = A*c_1b{1,t-1};
    R_1c{1,t}= [A*R_1b{1,t-1},Hw];
    P_1c=sum(abs(R_1c{1,t}), 2);
    K_1b = R_1c{1,t}*R_1c{1,t}'*C'* inv(C*R_1c{1,t}*R_1c{1,t}'*C' + Hv*Hv');
    c_1b{1,t}= (eye(4)-K_1b*C)*c_1c{1,t} + K_1b*y(:,t);
    R_1b{1,t} = [(eye(4)-K_1b*C)*R_1c{1,t},-K_1b*Hv];
    R_1b{1,t} = Reduction(R_1b{1,t},q);
    P_1b(:,t)=sum(abs(R_1b{1,t}), 2);
    x_1b_up(:, t)=  c_1b{1,t}+P_1b(:,t);
    x_1b_down(:, t)=c_1b{1,t}-P_1b(:,t);
end


figure;
% 第一个子图
subplot(2, 2, 1);
plot(1:N, x_1b_up(1, :), 'b--', 'LineWidth', 1.5);hold on;

plot(1:N, x(1, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b_down(1, :), 'b--', 'LineWidth', 1.5);
title('子图1标题'); % 添加子图标题
xlabel('横坐标标签'); % 添加横坐标标签
ylabel('纵坐标标签'); % 添加纵坐标标签
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)'); % 添加图例说明

% 第二个子图
subplot(2, 2, 2);
plot(1:N, x_1b_up(2, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x(2, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b_down(2, :), 'b--', 'LineWidth', 1.5);
title('子图2标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');

% 第三个子图
subplot(2, 2, 3);
plot(1:N, x_1b_up(3, :), 'b--', 'LineWidth', 1.5);hold on;
plot(1:N, x(3, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b_down(3, :), 'b--', 'LineWidth', 1.5);
title('子图3标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');

% 第四个子图
subplot(2, 2, 4);
plot(1:N, x_1b_up(4, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1b_down(4, :), 'b--', 'LineWidth', 1.5);
title('子图4标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');


figure;
% 第一个子图
subplot(2, 2, 1);
plot(1:N, x_1a_up(1, :), 'b--', 'LineWidth', 1.5);hold on;
plot(1:N, x(1, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1a_down(1, :), 'b--', 'LineWidth', 1.5);
title('子图1标题'); % 添加子图标题
xlabel('横坐标标签'); % 添加横坐标标签
ylabel('纵坐标标签'); % 添加纵坐标标签
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)'); % 添加图例说明

% 第二个子图
subplot(2, 2, 2);
plot(1:N, x_1a_up(2, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x(2, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1a_down(2, :), 'b--', 'LineWidth', 1.5);
title('子图2标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');

% 第三个子图
subplot(2, 2, 3);
plot(1:N, x_1a_up(3, :), 'b--', 'LineWidth', 1.5);hold on;
plot(1:N, x(3, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1a_down(3, :), 'b--', 'LineWidth', 1.5);
title('子图3标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');

% 第四个子图
subplot(2, 2, 4);
plot(1:N, x_1a_up(4, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x(4, :), 'r', 'LineWidth', 1.5);
plot(1:N, x_1a_down(4, :), 'b--', 'LineWidth', 1.5);
title('子图4标题');
xlabel('横坐标标签');
ylabel('纵坐标标签');
legend('上限曲线 (x_1a_up)', '实际曲线 (x)', '下限曲线 (x_1a_down)');

%% 做一个假设验证 假如C=I,分别使用 带事件触发不补偿和补偿时候的区域比较，其中分别使用两种性能指标进行比较
% 已经可以看出选取区间为性能指标的结果要好于选取F半径的结果，只不过没有选择合适的控制器参数，才导致效果不是那么的好
% 现在需要做的实验是，在感知信号未触发的时刻，是否存在取交集之后的结果要好于之前的结果
% 如果使用优化方法，可以发现
clc
clear
zOO_1=[0;0]; zOO_2=[0;0];zOO_3=[0;0];
ZOO_1=diag([1,2]);
ZOO_2=diag([2,1]); 
ZOO_3=diag([1,1]);          % diag([1,1]);
ZO_1= zonotope(zOO_1, ZOO_1);
ZO_2= zonotope(zOO_2, ZOO_2);
ZO_3= zonotope(zOO_3, ZOO_3);
figure;
hold on;
plot(ZO_1, [1,2], 'EdgeColor', 'b', 'LineWidth', 1.5);  % 假设维度为[1,2]
plot(ZO_2, [1,2], 'EdgeColor', 'r', 'LineWidth', 1.5);  
plot(ZO_3, [1,2], 'EdgeColor', 'k', 'LineWidth', 1.5);  
% plot(ZO_1r, [1,2], 'EdgeColor', 'm', 'LineWidth', 1.5);  
hold off;
%% 现在需要检查1与2进行融合和1与3进行融合之后的差距
% 1与2先进行融合
Ph_1 = [ZOO_1, zeros(2,2)];
Ps_1 = [ZOO_1, -ZOO_2];
K_1opt = zeros(2, 2);  % 存储所有Lambda_i的最优解
% 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-8, ... % 求解精度
        'sedumi.maxiter', 100); % 最大迭代次数
 for i = 1:2
        % 定义决策变量
        lam_i = sdpvar(4, 1);      % 向量λ_i
        Lam_i = sdpvar(1, 2);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            Ph_1(i,:)' - Ps_1'*Lam_i' >= -lam_i,
            Ph_1(i,:)' - Ps_1'*Lam_i' <=  lam_i
            ];

        % 设置目标函数
        Objective = sum(lam_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K_1opt(i,:) = value(Lam_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K_1opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
% 最终结果矩阵
    K_1 = K_1opt;
    zoo_1r=zOO_1+K_1*(zOO_2-zOO_1);
    Zoo_1r=[(eye(2)-K_1)*ZOO_1,K_1*ZOO_2];
    ZO_1r= zonotope(zoo_1r, Zoo_1r);
hold on;
plot(ZO_1, [1,2], 'EdgeColor', 'b', 'LineWidth', 1.5);  % 假设维度为[1,2]
plot(ZO_2, [1,2], 'EdgeColor', 'r', 'LineWidth', 1.5);  
plot(ZO_1r, [1,2], 'EdgeColor', 'k', 'LineWidth', 1.5);  


%% 与3进行融合       性能指标的选定真的会比F半径的结果要好
%% 现在需要检查1与2进行融合和1与3进行融合之后的差距
% 1与2先进行融合
Ph_2 = [ZOO_1, zeros(2,2)];
Ps_2 = [ZOO_1, -ZOO_3];
K_2opt = zeros(2, 2);  % 存储所有Lambda_i的最优解
% 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-8, ... % 求解精度
        'sedumi.maxiter', 100); % 最大迭代次数
 for i = 1:2
        % 定义决策变量
        lam_i = sdpvar(4, 1);      % 向量λ_i
        Lam_i = sdpvar(1, 2);         % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            Ph_2(i,:)' - Ps_1'*Lam_i' >= -lam_i,
            Ph_2(i,:)' - Ps_1'*Lam_i' <=  lam_i
            ];

        % 设置目标函数
        Objective = sum(lam_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             K_2opt(i,:) = value(Lam_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              K_2opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
% 最终结果矩阵
    K_2 = K_2opt;
    zoo_2r=zOO_1+K_2*(zOO_3-zOO_1);
    Zoo_2r=[(eye(2)-K_2)*ZOO_1,K_2*ZOO_3];
    ZO_2r= zonotope(zoo_2r, Zoo_2r);

hold on;
plot(ZO_1, [1,2], 'EdgeColor', 'b', 'LineWidth', 1.5);  % 假设维度为[1,2]
plot(ZO_2, [1,2], 'EdgeColor', 'r', 'LineWidth', 1.5);  
plot(ZO_2r, [1,2], 'EdgeColor', 'k', 'LineWidth', 1.5);  