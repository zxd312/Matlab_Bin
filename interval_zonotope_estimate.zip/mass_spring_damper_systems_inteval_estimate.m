clc
clear
close all;
N=50;   % Time steps
numbers=4; 
d=1;    %init position
v=0.1;  %init velocity
q=6; %Reduction
%% Overall System
k=2;
c=2;
Ts=0.05;
% car quality
for i = 1:numbers
   m(i) = 10 + 5 * rand;
end


% 定义 A 矩阵
A = [0, 1, 0, 0, 0, 0, 0, 0;
    -k/m(1), -c/m(1), k/m(1), c/m(1), 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0;
    k/m(2), c/m(2), -2*k/m(2), -2*c/m(2), k/m(2), c/m(2), 0, 0;             
    0, 0, 0, 0, 0, 1, 0, 0;
    0, 0, k/m(3), c/m(3), -2*k/m(3), -2*c/m(3), k/m(3), c/m(3);
    0, 0, 0, 0, 0, 0, 0, 1;
    0, 0, 0, 0, k/m(4), c/m(4), -2*k/m(4), -2*c/m(4)];
%% 定义重叠部分的索引矩阵(直接定义重叠索引矩阵即可)
C_12overlaping= [eye(2,2),zeros(2,2)];   C_12intersection=[zeros(2,2),eye(2,2)]; C_12=[eye(2,2),zeros(2,2)];
C_21overlaping= [zeros(2,2),eye(2,2)];   C_23overlaping= [eye(2,2),zeros(2,2)];  C_21=[zeros(2,2),eye(2,2)];
C_21intersection=[eye(2,2),zeros(2,2)];  C_23intersection=[zeros(2,2),eye(2,2)]; C_23=[eye(2,2),zeros(2,2)];
C_32overlaping= [zeros(2,2),eye(2,2)];   C_32intersection= [eye(2,2),zeros(2,2)];C_32=[zeros(2,2),eye(2,2)];
%% block discretization
%  block
A_1d=A(1:2,1:2);
A_12d=A(1:2,3:4);
A_2d=A(3:4,3:4);
A_21d=A(3:4,1:2);
A_23d=A(3:4,5:6);
A_3d=A(5:6,5:6);
A_32d=A(5:6,3:4);
A_34d=A(5:6,7:8);
A_4d=A(7:8,7:8);
A_43d=A(7:8,5:6);
U_11=[0;1/m(1)];
U_22=[0;1/m(2)];
U_33=[0;1/m(3)];
U_44=[0;1/m(4)];
% discretization
A_1b = expm(A_1d*Ts);
fun_12 = @(t) expm(A_1d*t) * A_12d;
A_12b = integral(fun_12, 0, Ts, 'ArrayValued', true);

A_2b = expm(A_2d * Ts);
fun_21 = @(t) expm(A_2d*t) * A_21d;
A_21b = integral(fun_21, 0, Ts, 'ArrayValued', true);

fun_23 = @(t) expm(A_2d*t) * A_23d;
A_23b = integral(fun_23, 0, Ts, 'ArrayValued', true);

A_3b = expm(A_3d * Ts);
fun_32 = @(t) expm(A_3d * t) * A_32d;
A_32b = integral(fun_32, 0, Ts, 'ArrayValued', true);

fun_34 = @(t) expm(A_3d * t) * A_34d;
A_34b = integral(fun_34, 0, Ts, 'ArrayValued', true);

A_4b = expm(A_4d * Ts);
fun_43 = @(t) expm(A_4d * t) * A_43d;
A_43b = integral(fun_43, 0, Ts, 'ArrayValued', true);

A_1=[A_1b,A_12b;A_21b,A_2b];
A_12=[zeros(2,4);zeros(2,2),A_23b];
A_2=[A_2b,A_23b;A_32b,A_3b];
A_21=[A_21b,zeros(2,2);zeros(2,2),zeros(2,2)];
A_23=[zeros(2,2),zeros(2,2);zeros(2,2),A_34b];
A_3=[A_3b,A_34b;A_43b,A_4b];
A_32=[A_32b,zeros(2,2);zeros(2,2),zeros(2,2)];
%% 系统矩阵
C=eye(2);
C_1=mdiag(C,C);
C_2=mdiag(C,C);
C_3=mdiag(C,C); 
%% 噪声协方差矩阵调整 
Q_1 = diag([1, 1]);  % 过程噪声的协方差矩阵
Q_2 = diag([1, 1]);
Q_3 = diag([1, 1]);
Q_4 = diag([1, 1]);
R_1 = diag([1, 1]); 
R_2high = diag([1,1]);% 观测噪声协方差
R_2 = diag([0.5, 0.5]);
R_3 = diag([0.5, 0.5]);
R_3high = diag([1, 1]);
R_4 = diag([1, 1]);
QE1=mdiag(Q_1,Q_2);
QE2=mdiag(Q_2,Q_3);
QE3=mdiag(Q_3,Q_4);
RE1=mdiag(R_1,R_2high);
RE2=mdiag(R_2,R_3);
RE3=mdiag(R_3high,R_4);
%% 生成噪声的中心对称多细胞体  (噪声后期肯定是要处理的，暂时这样)(要向师兄那样类似长方形的，这样效果才能更好)
w_1= 2*rand(2,N)-1;
w_2= 2*rand(2,N)-1;
w_3= 2*rand(2,N)-1;
w_4= 2*rand(2,N)-1;
v_1= 2*rand(2,N)-1;
v_2high=2*rand(2,N)-1;
v_2= 1*rand(2,N)-0.5;
v_3= 1*rand(2,N)-0.5;
v_3high=2*rand(2,N)-1;
v_4= 2*rand(2,N)-1;
WE1=[w_1;w_2]; 
WE2=[w_2;w_3]; 
WE3=[w_3;w_4];
VE1=[v_1;v_2high];
VE2=[v_2;v_3];
VE3=[v_3high;v_4];
%% 初始协方差矩阵和状态     %% 一定要对重叠部分给定不同的边界
R_1a{1,1}=diag([1, 0.1, 1, 0.1]);                R_1b{1,1}=diag([1, 0.1, 1, 0.1]);     
R_1e{1,1}=diag([1, 0.1, 1, 0.1]);                R_1d{1,1}=diag([1, 0.1, 1, 0.1]);
R_2a{1,1}=diag([0.5, 0.2, 0.5,0.2]);             R_2b{1,1}=diag([0.5, 0.2, 0.5,0.2]);
R_2e{1,1}=diag([0.5, 0.2, 0.5, 0.2]);            R_2d{1,1}=diag([0.5, 0.2, 0.5, 0.2]);
R_3a{1,1}=diag([1, 0.12, 1, 0.12]);              R_3b{1,1}=diag([1, 0.12, 1, 0.12]);
R_3e{1,1}=diag([1, 0.12, 1, 0.12]);              R_3d{1,1}=diag([1, 0.12, 1, 0.12]);
c_1a{1,1}=[0; v; d; v];     c_1e{1,1}=[0; v; d; v];      c_1r{1,1}=[0; v; d; v];
c_2a{1,1}=[d; v; 2*d; v];   c_2e{1,1}=[d; v; 2*d; v];    c_2r{1,1}=[d; v; 2*d; v];
c_3a{1,1}=[2*d; v; 3*d; v]; c_3e{1,1}=[2*d; v; 3*d; v];  c_3r{1,1}=[2*d; v; 3*d; v];
x_1(:, 1)=[0; v; d; v]; x_2(:, 1)=[d; v; 2*d; v]; x_3(:, 1)=[2*d; v; 3*d; v];
%% 初始化边界
P_1a(:,1)=[1; 0.1; 1; 0.1];                P_1b(:,1)=[1; 0.1; 1; 0.1];
P_2a(:,1)=[0.5; 0.2; 0.5; 0.2];            P_2b(:,1)=[0.5; 0.2; 0.5; 0.2];
P_3a(:,1)= [1;0.12; 1; 0.12];              P_3b(:,1)= [1;0.12; 1; 0.12];
x_1a_up(:, 1)= x_1(:, 1)+ P_1a(:,1);       x_1b_up(:, 1)= x_1(:, 1)+ P_1b(:,1); 
x_1a_down(:, 1)= x_1(:, 1)-P_1a(:,1);      x_1b_down(:, 1)= x_1(:, 1)-P_1b(:,1);
x_2a_up(:, 1)= x_2(:, 1)+ P_2a(:,1);       x_2b_up(:, 1)= x_2(:, 1)+ P_2b(:,1);
x_2a_down(:, 1)= x_2(:, 1)-P_2a(:,1);      x_2b_down(:, 1)= x_2(:, 1)-P_2b(:,1); 
x_3a_up(:, 1)= x_3(:, 1)+ P_3a(:,1);       x_3b_up(:, 1)= x_3(:, 1)+ P_3b(:,1);
x_3a_down(:, 1)= x_3(:, 1)-P_3a(:,1);      x_3b_down(:, 1)= x_3(:, 1)-P_3b(:,1); 
%% 初始化列数
num_1a(:,1) = size(R_1a{1,1}, 2);
num_2a(:,1) = size(R_2a{1,1}, 2);
num_3a(:,1) = size(R_3a{1,1}, 2);
%% 事件触发阈值设计
T_11(1,1)=1;T_12(1,1)=1;T_13(1,1)=1;T_14(1,1)=1;
T_21(1,1)=1;T_22(1,1)=1;T_23(1,1)=1;T_24(1,1)=1;
T_31(1,1)=1;T_32(1,1)=1;T_33(1,1)=1;T_34(1,1)=1;
y_1(:, 1) = C_1 * x_1(:, 1) + VE1(:, 1);
y_2(:, 1) = C_2 * x_2(:, 1) + VE2(:, 1);
y_3(:, 1) = C_3 * x_3(:, 1) + VE3(:, 1);
y11=y_1(1, 1); y12=y_1(2, 1); y13=y_1(3, 1); y14=y_1(4, 1); 
y21=y_2(1, 1); y22=y_2(2, 1); y23=y_2(3, 1); y24=y_2(4, 1); 
y31=y_3(1, 1); y32=y_3(2, 1); y33=y_3(3, 1); y34=y_3(4, 1); 
d_e=0.6; v_e=0.4;
%% 迭代循环
for t=2:N+1                   
 F1(:,t)=5 * rand;  F2(:,t)=5 * rand;
 F3(:,t)=5 * rand;  F4(:,t)=5 * rand;
 u_1(:,t)=F1(:,t)*U_11; u_2(:,t)=F2(:,t)*U_22; u_3(:,t)=F3(:,t)*U_33; u_4(:,t)=F4(:,t)*U_44;
 U_1(:,t)=[u_1(:,t);u_2(:,t)];
 U_2(:,t)=[u_2(:,t);u_3(:,t)];
 U_3(:,t)=[u_3(:,t);u_4(:,t)];
 %% 融合处理（第一个估计器）
 N_11=[R_1a{1,t-1},zeros(4,num_2a(:,t-1))];
 N_12=[-C_12intersection*R_1a{1,t-1},C_12overlaping*R_2a{1,t-1}];
 M1_opt = zeros(4, 2);
 col_1 = size(N_11,2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L1_i = sdpvar(col_1, 1);      % 向量λ_i
        M1_i = sdpvar(1, 2);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_11(i,:)' +  N_12'*M1_i' >= -L1_i,
            N_11(i,:)' +  N_12'*M1_i' <=  L1_i
            ];
        % 设置目标函数
        Objective = sum(L1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M1_opt(i,:) = value(M1_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M1_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_1(:,:,t-1)= M1_opt;
  % 计算融合结果
    c_1r{1,t-1}= (eye(4)-M_1(:,:,t-1)*C_12intersection)*c_1a{1,t-1} + M_1(:,:,t-1)*C_12overlaping*c_2a{1,t-1};
    R_1r{1,t-1}= N_11+M_1(:,:,t-1)*N_12; 
    P_1r(:,t-1) =sum(abs(R_1r{1,t-1}), 2);
    x_1r_up(:, t-1)= c_1r{1,t-1} + P_1r(:,t-1);
    x_1r_down(:,t-1)=c_1r{1,t-1}- P_1r(:,t-1);
 %% 融合处理（第二个估计器）（重点是这部分）
  N_22=[R_2a{1,t-1},zeros(4,num_1a(:,t-1)),zeros(4,num_3a(:,t-1))];
  N_21=[-C_21intersection*R_2a{1,t-1},C_21overlaping*R_1a{1,t-1},zeros(2,num_3a(:,t-1));
                 -C_23intersection*R_2a{1,t-1},zeros(2,num_1a(:,t-1)),C_23overlaping*R_3a{1,t-1}];
  M2_opt = zeros(4, 4);
  col_2 = size(N_22,2);
  % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        L2_i = sdpvar(col_2, 1);     % 向量λ_i
        M2_i = sdpvar(1, 4);         % 矩阵Λ_i

        % 构建约束条件
        Constraints = [
            N_22(i,:)' +  N_21'*M2_i' >= -L2_i,
            N_22(i,:)' +  N_21'*M2_i' <=  L2_i
            ];
        % 设置目标函数
        Objective = sum(L2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             M2_opt(i,:) = value(M2_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              M2_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    M_2(:,:,t-1)= M2_opt;
  % 计算融合结果
  c_2r{1,t-1}= (eye(4)-M_2(:,1:2,t-1)*C_21intersection  - M_2(:,3:4,t-1)*C_23intersection)*c_2a{1,t-1} + M_2(:,1:2,t-1)*C_21overlaping*c_1a{1,t-1} + M_2(:,3:4,t-1)*C_23overlaping*c_3a{1,t-1};
  R_2r{1,t-1}= N_22+M_2(:,:,t-1)*N_21;
  P_2r(:,t-1) =sum(abs(R_2r{1,t-1}), 2);
  x_2r_up(:, t-1)= c_2r{1,t-1} + P_2r(:,t-1);
  x_2r_down(:, t-1)=c_2r{1,t-1}- P_2r(:,t-1);
  %% 融合处理（第三个估计器）
  N_33=[R_3a{1,t-1},zeros(4,num_2a(:,t-1))];
  N_31=[-C_32intersection*R_3a{1,t-1},C_32overlaping*R_2a{1,t-1}];
  M3_opt = zeros(4, 2);
  col_3 = size(N_33,2);
  % 使用循环求解优化问题
  for i = 1:4
      % 定义决策变量
      L3_i = sdpvar(col_3, 1);    % 向量λ_i
      M3_i = sdpvar(1, 2);        % 矩阵Λ_i
      % 构建约束条件
      Constraints = [
          N_33(i,:)' +  N_31'*M3_i' >= -L3_i,
          N_33(i,:)' +  N_31'*M3_i' <=  L3_i
          ];
      % 设置目标函数
      Objective = sum(L3_i);
      % 求解优化问题
      result = optimize(Constraints, Objective, options);
      % 检查求解结果
      if result.problem == 0  % 如果问题求解成功
          M3_opt(i,:) = value(M3_i);  % 存储最优解
      else  % 如果求解失败
          disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
          disp('错误信息:');
          disp(result.info);  % 输出错误信息
          M3_opt(i,:) = NaN;  % 如果失败，设定为NaN
      end
  end
  % 最终结果矩阵
  M_3(:,:,t-1)= M3_opt;
  % 计算融合结果
  c_3r{1,t-1}= (eye(4)-M_3(:,:,t-1)*C_32intersection)*c_3a{1,t-1} + M_3(:,:,t-1)*C_32overlaping*c_2a{1,t-1};
  R_3r{1,t-1}= N_33 + M_3(:,:,t-1)*N_31;                                                                                         %[(eye(4)-M_3(:,:,t-1)*C_32intersection)*R_3a{1,t-1}, M_3(:,:,t-1)*C_32overlaping*R_2a{1,t-1}];
  P_3r(:,t-1) =sum(abs(R_3r{1,t-1}), 2);
  x_3r_up(:, t-1)=c_3r{1,t-1}  + P_3r(:,t-1);
  x_3r_down(:,t-1)=c_3r{1,t-1} - P_3r(:,t-1);
  %% 跳出循环
   if t == N+1
        break;  % 立即终止循环
    end
 %%
 % 状态更新
 x_1(:, t) = A_1 * x_1(:, t-1) + U_1(:,t) + WE1(:, t) + A_12 * x_2(:, t-1);
 x_2(:, t) = A_2 * x_2(:, t-1) + U_2(:,t) + WE2(:, t) + A_21 * x_1(:, t-1) + A_23 * x_3(:, t-1);
 x_3(:, t) = A_3 * x_3(:, t-1) + U_3(:,t) + WE3(:, t) + A_32 * x_2(:, t-1);
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + VE1(:, t);
 y_2(:, t) = C_2 * x_2(:, t) + VE2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + VE3(:, t);

    %% 第一个估计器 中心对称多细胞体估计器设计
    c_1e{1,t} = A_1*c_1r{1,t-1}+U_1(:,t)+A_12 *c_2a{1,t-1};
    R_1e{1,t}= [A_1*R_1r{1,t-1},A_12*R_2a{1,t-1},QE1];
    %% 采用单个分量的事件触发装置  使用交集的补偿策略计算量太大了
    if  norm(y_1(1, t)-y11,2) <= d_e
        E_11=d_e;
        T_11(1,t)=0;
    else
        y11=y_1(1, t);    
        E_11=0;
        T_11(1,t)=1;
    end
     if  norm(y_1(2, t)-y12,2) <= v_e
        E_12=v_e;
        T_12(1,t)=0;
    else
        y12=y_1(2, t);    
        E_12=0;
        T_12(1,t)=1;
     end
   if  norm(y_1(3, t)-y13,2) <= d_e
        E_13=d_e;
        T_13(1,t)=0;
    else
        y13=y_1(3, t);    
        E_13=0;
        T_13(1,t)=1;
   end
   if  norm(y_1(4, t)-y14,2) <= v_e
        E_14=d_e;
        T_14(1,t)=0;
    else
        y14=y_1(4, t);    
        E_14=0;
        T_14(1,t)=1;
    end
    E_1=diag([E_11,E_12,E_13,E_14]);
    y1c=[y11;y12;y13;y14];
  % 增益矩阵通过求解一个优化问题
    Ph1= [R_1e{1,t}, zeros(4,8)]; 
    Ps1 = [C_1*R_1e{1,t},RE1,-E_1];
    row1s = size(Ph1, 1);  % 获取Phi的行数（循环次数）
    col1s = size(Ph1, 2);  % 获取Phi的列数
    % 预分配结果矩阵
    K1_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
    % 使用循环求解优化问题
    for i = 1:4
        % 定义决策变量
        l1_i = sdpvar(col1s, 1);      % 向量λ_i
        K1_i = sdpvar(1, 4);             % 矩阵Λ_i

        % 构建约束条件
        Constraints = [
            Ph1(i,:)' - Ps1'*K1_i' >= -l1_i,
            Ph1(i,:)' - Ps1'*K1_i' <=  l1_i
            ];
        % 设置目标函数
        Objective = sum(l1_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
        if result.problem == 0  % 如果问题求解成功
            K1_opt(i,:) = value(K1_i);  % 存储最优解
        else  % 如果求解失败
            disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
            disp('错误信息:');
            disp(result.info);  % 输出错误信息
            K1_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
        end
    end
    % 最终结果矩阵  %加入补偿机制
    K_1(:,:,t) = K1_opt;
    c_1a{1,t} = (eye(4)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y1c;
    R_1a{1,t} = [(eye(4)-K_1(:,:,t)*C_1)*R_1e{1,t},-K_1(:,:,t)*RE1,K_1(:,:,t)*E_1];
    % 只有当列数足够大的时候才执行降维
    R_1a{1,t} = Reduction(R_1a{1,t},q);
    num_1a(:,t)=size(R_1a{1,t},2);
    P_1a(:,t)=sum(abs(R_1a{1,t}), 2);
    x_1a_up(:, t)= c_1a{1,t} + P_1a(:,t);
    x_1a_down(:, t)=c_1a{1,t}-P_1a(:,t);
  %%  第二个估计器  中心对称多细胞体估计器设计
    c_2e{1,t} = A_2*c_2r{1,t-1} + A_21*c_1a{1,t-1} + A_23*c_3a{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
    R_2e{1,t} = [A_2*R_2r{1,t-1}, A_21*R_1a{1,t-1} , A_23*R_3a{1,t-1}, QE2];
  %% 采用单个分量的事件触发装置  使用交集的补偿策略计算量太大了
    if  norm(y_2(1, t)-y21,2) <= d_e
        E_21=d_e;
        T_21(1,t)=0;
    else
        y21=y_2(1, t);    
        E_21=0;
        T_21(1,t)=1;
    end
     if  norm(y_2(2, t)-y22,2) <= v_e
        E_22=v_e;
        T_22(1,t)=0;
    else
        y22=y_2(2, t);    
        E_22=0;
        T_22(1,t)=1;
     end
   if  norm(y_2(3, t)-y23,2) <= d_e
        E_23=d_e;
        T_23(1,t)=0;
    else
        y23=y_2(3, t);    
        E_23=0;
        T_23(1,t)=1;
   end
   if  norm(y_2(4, t)-y24,2) <= v_e
        E_24=d_e;
        T_24(1,t)=0;
    else
        y24=y_2(4, t);    
        E_24=0;
        T_24(1,t)=1;
    end
    E_2=diag([E_21,E_22,E_23,E_24]);
    y2c=[y21;y22;y23;y24];
    % 增益矩阵通过求解一个优化问题
    Ph2= [R_2e{1,t}, zeros(4,8)]; 
    Ps2 =[C_2*R_2e{1,t}, RE2,-E_2];
    row2s = size(Ph2, 1);  % 获取Phi的行数（循环次数）
    col2s = size(Ph2, 2);  % 获取Phi的列数
    % 预分配结果矩阵
    K2_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
    for i = 1:4
        % 定义决策变量
        l2_i = sdpvar(col2s, 1);      % 向量λ_i
        K2_i = sdpvar(1, 4);             % 矩阵Λ_i

        % 构建约束条件
        Constraints = [
            Ph2(i,:)' - Ps2'*K2_i' >= -l2_i,
            Ph2(i,:)' - Ps2'*K2_i' <=  l2_i
            ];
        % 设置目标函数
        Objective = sum(l2_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
        if result.problem == 0  % 如果问题求解成功
            K2_opt(i,:) = value(K2_i);  % 存储最优解
        else  % 如果求解失败
            disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
            disp('错误信息:');
            disp(result.info);  % 输出错误信息
            K2_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
        end
    end
    % 最终结果矩阵
    K_2(:,:,t) = K2_opt;
    % 观测更新
    c_2a{1,t}= (eye(4)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y2c;
    R_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*R_2e{1,t},-K_2(:,:,t)*RE2,K_2(:,:,t)*E_2];
    % 只有当列数足够大的时候才执行降维
    R_2a{1,t} = Reduction(R_2a{1,t},q);
    num_2a(:,t)=size(R_2a{1,t},2);
    P_2a(:,t) =sum(abs(R_2a{1,t}), 2);
    x_2a_up(:, t)= c_2a{1,t} + P_2a(:,t);
    x_2a_down(:, t)=c_2a{1,t}- P_2a(:,t);
   %%  第三个估计器  
    c_3e{1,t}=A_3*c_3r{1,t-1} +A_32*c_2a{1,t-1}+ U_3(:,t) ;
    R_3e{1,t}=[A_3*R_3r{1,t-1},A_32*R_2a{1,t-1},QE3];
 %% 采用单个分量的事件触发装置  使用交集的补偿策略计算量太大了
    if  norm(y_3(1, t)-y31,2) <= d_e
        E_31=d_e;
        T_31(1,t)=0;
    else
        y31=y_3(1, t);    
        E_31=0;
        T_31(1,t)=1;
    end
     if  norm(y_3(2, t)-y32,2) <= v_e+0.1
        E_32=v_e+0.1;
        T_32(1,t)=0;
    else
        y32=y_2(2, t);    
        E_32=0;
        T_32(1,t)=1;
     end
   if  norm(y_3(3, t)-y33,2) <= d_e
        E_33=d_e;
        T_33(1,t)=0;
    else
        y33=y_3(3, t);    
        E_33=0;
        T_33(1,t)=1;
   end
   if  norm(y_3(4, t)-y34,2) <= v_e
        E_34=d_e;
        T_34(1,t)=0;
    else
        y34=y_3(4, t);    
        E_34=0;
        T_34(1,t)=1;
    end
    E_3=diag([E_31,E_32,E_33,E_34]);
    y3c=[y31;y32;y33;y34];
    % 增益矩阵通过求解一个优化问题    
    Ph3= [R_3e{1,t}, zeros(4,8)]; 
    Ps3 =[C_3*R_3e{1,t}, RE3 ,-E_3];
    row3s = size(Ph3, 1);  % 获取Phi的行数（循环次数）
    col3s = size(Ph3, 2);  % 获取Phi的列数
    % 预分配结果矩阵
    K3_opt = zeros(4, 4);  % 存储所有Lambda_i的最优解
    for i = 1:4
        % 定义决策变量
        l3_i = sdpvar(col3s, 1);      % 向量λ_i
        K3_i = sdpvar(1, 4);          % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            Ph3(i,:)' - Ps3'*K3_i' >= -l3_i,
            Ph3(i,:)' - Ps3'*K3_i' <=  l3_i
            ];
        % 设置目标函数
        Objective = sum(l3_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
        if result.problem == 0  % 如果问题求解成功
            K3_opt(i,:) = value(K3_i);  % 存储最优解
        else  % 如果求解失败
            disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
            disp('错误信息:');
            disp(result.info);  % 输出错误信息
            K3_opt(i,:) = NaN;  % 如果失败，设定为NaNZ`
        end
    end
    % 最终结果矩阵
    K_3(:,:,t) = K3_opt;
    c_3a{1,t}=(eye(4)-K_3(:,:,t)*C_3)*c_3e{1,t}+K_3(:,:,t)*y3c;
    R_3a{1,t}=[(eye(4)-K_3(:,:,t)*C_3)*R_3e{1,t}, -K_3(:,:,t)*RE3 ,K_3(:,:,t)*E_3];
    % 只有当列数足够大的时候才执行降维
    R_3a{1,t} = Reduction(R_3a{1,t},q);
    num_3a(:,t)=size(R_3a{1,t},2);
    P_3a(:,t) =sum(abs(R_3a{1,t}), 2);
    x_3a_up(:, t)= c_3a{1,t} + P_3a(:,t);
    x_3a_down(:, t)=c_3a{1,t}- P_3a(:,t);
end   
%% box 部分拿出来单独循环（每个循环对应一个估计器，要不然容易使matlab卡死）
for t=1:N  
 % 融合之后要考虑其存在的相关性，现在还不知道具体的将超平面转化为zonotope的方法，所以只观察结果，先不作为迭代输入。
 % (第一个估计器)
    Z1r=zonotope(c_1r{1,t},R_1r{1,t}); Z1r=computeHRep(Z1r);
    Z11=zonotope(c_1a{1,t},R_1a{1,t}); Z11=computeHRep(Z11);
    Z12=zonotope(C_12overlaping*c_2a{1,t},C_12overlaping*R_2a{1,t}); Z12=computeHRep(Z12);
    n_1=size(Z12.A,1); Z12_A=[zeros(n_1,2),Z12.A];
    z1_2=Polyhedron('H',[[Z11.A;Z12_A] [Z11.b;Z12.b]]); z1_2=computeVRep(z1_2);
%     %% 这部分先注释掉，后续找到转化方法再使用这部分代码
    H1_new = [];
    b1_new = [];
    num1_constraints = size(Z1r.A,1);   % 约束数 = zr.A的行数
    num1_vertices = size(z1_2.V,1);     % 顶点数 = z3.V的行数
    b1 = zeros(num1_constraints, num1_vertices); % 预先分配内存
    for i=1:size(Z1r.A,1)
    for j=1:size(z1_2.V,1)
        b1(i,j)=Z1r.A(i,:)*z1_2.V(j,:)';
    end
       b1_diff1(i,:)=b1(i,:)-Z1r.b(i);
       b1_diff(i,:)=abs(b1(i,:)-Z1r.b(i));
       [~,I1(i,:)]=max(b1_diff(i,:));  
       b_1(i,:)= b1(i,I1(i,:));  
       H1_new = [H1_new; -Z1r.A(i,:)];                 % 对称法向量
       b1_new = [b1_new; -b1(i,I1(i,:))];              % 对称边界
end
P1_tight = Polyhedron('A', H1_new, 'b', b1_new); P1_tight=computeVRep(P1_tight);
g_box1{1,t}=(max(P1_tight.V)'+min(P1_tight.V)')/2;
G_box1{1,t}=diag(abs(max(P1_tight.V)'-min(P1_tight.V)')/2);
P_box1(:,t)=sum(G_box1{1,t}, 2);
x_1box_up(:, t)  = g_box1{1,t} + P_box1(:,t);
x_1box_down(:,t)= g_box1{1,t} + P_box1(:,t);
% % 改进后的融合先使用box包裹来替代（第二个估计器）(采用序贯的方式看看能不能行)
% Z2r=zonotope(c_2r{1,t},R_2r{1,t}); Z2r=computeHRep(Z2r);
% Z22=zonotope(c_2a{1,t},R_2a{1,t}); Z11=computeHRep(Z22);
% Z21=zonotope(C_21overlaping*c_1a{1,t},C_21overlaping*R_1a{1,t}); Z21=computeHRep(Z21);
% Z23=zonotope(C_23overlaping*c_3a{1,t},C_23overlaping*R_3a{1,t}); Z23=computeHRep(Z23);
% n_2=size(Z21.A,1); Z21_A=[Z21.A,zeros(n_2,2)];
% z2_1=Polyhedron('H',[[Z22.A;Z21_A] [Z22.b;Z21.b]]); z2_1=computeVRep(z2_1);
% n_23=size(Z23.A,1); Z23_A=[zeros(n_23,2),Z23.A];
% z2_3=Polyhedron('H',[[z2_1.A;Z23_A] [z2_1.b;Z23.b]]); z2_3=computeVRep(z2_3);
% g_box2{1,t}=(max(z2_3.V)'+min(z2_3.V)')/2;
% G_box2{1,t}=diag(abs(max(z2_3.V)'-min(z2_3.V)')/2);
% P_box2(:,t)=sum(G_box2{1,t}, 2);
% x_2box_up(:, t)  = g_box2{1,t} + P_box2(:,t);
% x_2box_down(:,t)= g_box2{1,t} + P_box2(:,t);
% % 改进后的融合先使用box包裹来替代（第三个估计器）
% Z3r=zonotope(c_3r{1,t},R_3r{1,t}); Z3r=computeHRep(Z3r);
% Z33=zonotope(c_3a{1,t},R_3a{1,t}); Z33=computeHRep(Z33);
% Z32=zonotope(C_32overlaping*c_2a{1,t},C_32overlaping*R_2a{1,t}); Z32=computeHRep(Z32);
% n_32=size(Z32.A,1); Z32_A=[Z32.A,zeros(n_32,2)];
% z3_2=Polyhedron('H',[[Z33.A;Z32_A] [Z33.b;Z32.b]]); z3_2=computeVRep(z3_2);
% g_box3{1,t}=(max(z3_2.V)'+min(z3_2.V)')/2;
% G_box3{1,t}=diag(abs(max(z3_2.V)'-min(z3_2.V)')/2);
% P_box3(:,t)=sum(G_box3{1,t}, 2);
% x_3box_up(:, t)  = g_box3{1,t} + P_box3(:,t);
% x_3box_down(:,t)= g_box3{1,t} + P_box3(:,t);
end
%% 为了防止程序出错，所以把第二个估计器的融合部分拆成两部分（第一部分）
for t=1:N  
    Z2r=zonotope(c_2r{1,t},R_2r{1,t}); Z2r=computeHRep(Z2r);
    Z22=zonotope(c_2a{1,t},R_2a{1,t}); Z22=computeHRep(Z22);
    Z21=zonotope(C_21overlaping*c_1a{1,t},C_21overlaping*R_1a{1,t}); Z21=computeHRep(Z21);
    n_21=size(Z21.A,1); Z21_A=[Z21.A,zeros(n_21,2)];
    z2_1=Polyhedron('H',[[Z22.A;Z21_A] [Z22.b;Z21.b]]); z2_1=computeVRep(z2_1);
%   %% 这部分先注释掉，后续找到转化方法再使用这部分代码
    H21_new = [];
    b21_new = [];
    num21_constraints = size(Z2r.A,1);   % 约束数 = zr.A的行数
    num21_vertices = size(z2_1.V,1);     % 顶点数 = z3.V的行数
    b21 = zeros(num21_constraints, num21_vertices); % 预先分配内存
    for i=1:size(Z2r.A,1)
    for j=1:size(z2_1.V,1)
        b21(i,j)=Z2r.A(i,:)*z2_1.V(j,:)';
    end
       b21_diff1(i,:)=b21(i,:)-Z2r.b(i);
       b21_diff(i,:)=abs(b21(i,:)-Z2r.b(i));
       [~,I21(i,:)]=max(b21_diff(i,:));  
       b_21(i,:)= b21(i,I21(i,:));  
       H21_new = [H21_new; -Z2r.A(i,:)];                 % 对称法向量
       b21_new = [b21_new; -b21(i,I21(i,:))];              % 对称边界
end
P21_tight = Polyhedron('A', H21_new, 'b', b21_new); P21_tight=computeVRep(P21_tight);
g_box21{1,t}=(max(P21_tight.V)'+min(P21_tight.V)')/2;
G_box21{1,t}=diag(abs(max(P21_tight.V)'-min(P21_tight.V)')/2);
P_box21(:,t)=sum(G_box21{1,t}, 2);
x_21box_up(:, t)  = g_box21{1,t} + P_box21(:,t);
x_21box_down(:,t) = g_box21{1,t}  +  P_box21(:,t);
end
%% 第二个估计器的第二部分
for t=1:N  
    Z21r=zonotope(g_box21{1,t},G_box21{1,t}); Z21r=computeHRep(Z21r);
    Z22=zonotope(c_2a{1,t},R_2a{1,t}); Z22=computeHRep(Z22);
    Z23=zonotope(C_23overlaping*c_3a{1,t},C_23overlaping*R_3a{1,t}); Z23=computeHRep(Z23);
    n_23=size(Z23.A,1); Z23_A=[zeros(n_23,2),Z23.A];
    z2_3=Polyhedron('H',[[Z22.A;Z23_A] [Z22.b;Z23.b]]); z2_3=computeVRep(z2_3);
%   %% 这部分先注释掉，后续找到转化方法再使用这部分代码
    H23_new = [];
    b23_new = [];
    num23_constraints = size(Z21r.A,1);   % 约束数 = zr.A的行数
    num23_vertices = size(z2_3.V,1);     % 顶点数 = z3.V的行数
    b21 = zeros(num23_constraints, num23_vertices); % 预先分配内存
    for i=1:size(Z21r.A,1)
    for j=1:size(z2_3.V,1)
        b23(i,j)=Z21r.A(i,:)*z2_3.V(j,:)';
    end
       b23_diff1(i,:)=b23(i,:)-Z21r.b(i);
       b23_diff(i,:)=abs(b23(i,:)-Z21r.b(i));
       [~,I23(i,:)]=max(b23_diff(i,:));  
       b_23(i,:)= b23(i,I23(i,:));  
       H23_new = [H23_new; -Z21r.A(i,:)];                 % 对称法向量
       b23_new = [b23_new; -b23(i,I23(i,:))];              % 对称边界
end
P23_tight = Polyhedron('A', H23_new, 'b', b23_new); P23_tight=computeVRep(P23_tight);
g_box23{1,t}=(max(P23_tight.V)'+min(P23_tight.V)')/2;
G_box23{1,t}=diag(abs(max(P23_tight.V)'-min(P23_tight.V)')/2);
P_box2(:,t)=sum(G_box23{1,t}, 2);
x_2box_up(:, t)  = g_box23{1,t} + P_box2(:,t);
x_2box_down(:,t) = g_box23{1,t}  +  P_box2(:,t);
end
for t=1:N  
 % (第三个估计器的)
    Z3r=zonotope(c_3r{1,t},R_3r{1,t}); Z3r=computeHRep(Z3r);
    Z33=zonotope(c_3a{1,t},R_3a{1,t}); Z33=computeHRep(Z33);
    Z32=zonotope(C_32overlaping*c_2a{1,t},C_32overlaping*R_2a{1,t}); Z32=computeHRep(Z32);
    n_1=size(Z32.A,1);  Z32_A=[Z32.A,zeros(n_1,2)];
    z3_2=Polyhedron('H',[[Z33.A;Z32_A] [Z33.b;Z32.b]]); z3_2=computeVRep(z3_2);
%     %% 这部分先注释掉，后续找到转化方法再使用这部分代码
    H3_new = [];
    b3_new = [];
    num3_constraints = size(Z3r.A,1);   % 约束数 = zr.A的行数
    num3_vertices = size(z3_2.V,1);     % 顶点数 = z3.V的行数
    b3 = zeros(num3_constraints, num3_vertices); % 预先分配内存
    for i=1:size(Z3r.A,1)
    for j=1:size(z3_2.V,1)
        b3(i,j)=Z3r.A(i,:)*z3_2.V(j,:)';
    end
       b3_diff1(i,:)=b3(i,:)-Z3r.b(i);
       b3_diff(i,:)=abs(b3(i,:)-Z3r.b(i));
       [~,I3(i,:)]=max(b3_diff(i,:));  
       b_3(i,:)= b3(i,I3(i,:));  
       H3_new = [H3_new; -Z3r.A(i,:)];                 % 对称法向量
       b3_new = [b3_new; -b3(i,I3(i,:))];              % 对称边界
end
P3_tight = Polyhedron('A', H3_new, 'b', b3_new); P3_tight=computeVRep(P3_tight);
g_box3{1,t}=(max(P3_tight.V)'+min(P3_tight.V)')/2;
G_box3{1,t}=diag(abs(max(P3_tight.V)'-min(P3_tight.V)')/2);
P_box3(:,t)=sum(G_box3{1,t}, 2);
x_3box_up(:, t)  = g_box3{1,t} + P_box3(:,t);
x_3box_down(:,t)= g_box3{1,t} + P_box3(:,t);
end

Z2r=zonotope(c_2r{1,t},R_2r{1,t}); Z2r=computeHRep(Z2r);
Z22=zonotope(c_2a{1,t},R_2a{1,t}); Z22=computeHRep(Z22);
Z21=zonotope(C_21overlaping*c_1a{1,t},C_21overlaping*R_1a{1,t}); Z21=computeHRep(Z21);
Z23=zonotope(C_23overlaping*c_3a{1,t},C_23overlaping*R_3a{1,t}); Z23=computeHRep(Z23);
n_21=size(Z21.A,1); Z21_A=[Z21.A,zeros(n_21,2)];
n_23=size(Z23.A,1); Z23_A=[zeros(n_23,2),Z23.A];
z2_13=Polyhedron('H',[[Z22.A;Z21_A] [Z22.b;Z21.b]]); z2_13=computeVRep(z2_13);
z2_13=Polyhedron('H',[[Z22.A;Z23_A] [Z22.b;Z23.b]]); z2_13=computeVRep(z2_13);
g_box2{1,t}=(max(z2_13.V)'+min(z2_13.V)')/2;
G_box2{1,t}=diag(abs(max(z2_13.V)'-min(z2_13.V)')/2);
P_box2(:,t)=sum(G_box2{1,t}, 2);
x_2box_up(:, t)  = g_box2{1,t} + P_box2(:,t);
x_2box_down(:,t)= g_box2{1,t} + P_box2(:,t);



plot(z_1y,'color','w','alpha',0.3)
plot(z_y1,'color','w','alpha',0.3)
plot(z_y1c,'color','w','alpha',0.3)

sum(T_32)
sum(T_14)



%%  绘制F半径下的zonotope估计器
 for t=2:N+1
 %% 融合处理
 %  第一个估计器 使用box来实现
 %首先进行增广
 c_12=C_12intersection'*C_12overlaping*c_2b{1,t-1}+ C_12'*C_12*c_1b{1,t-1};
 R_12=[C_12intersection'*C_12overlaping*R_2b{1,t-1},C_12'*C_12*R_1b{1,t-1}];
 z_11=zonotope(c_1b{1,t-1},R_1b{1,t-1}); z11=computeHRep(z_11);
 z_12=zonotope(c_12,R_12); z12=computeHRep(z_12);
 z_1r=Polyhedron('H',[[z11.A;z12.A] [z11.b;z12.b]]); z1r=computeVRep(z_1r);
 c_11r{1,t-1}=(max(z1r.V)'+min(z1r.V)')/2;
 R_11r{1,t-1}=diag(abs(max(z1r.V)'-min(z1r.V)')/2);
 P_11r(:,t-1) =sum(abs(R_11r{1,t-1}), 2);
 x_11r_up(:, t-1)= c_11r{1,t-1} + P_11r(:,t-1);
 x_11r_down(:,t-1)=c_11r{1,t-1}-  P_11r(:,t-1);
 %第二个估计器 使用box来实现
 % 首先增广
 c_21=C_21intersection'*C_21overlaping*c_1b{1,t-1} +C_21'*C_21*c_2b{1,t-1};   
 R_21=[C_21intersection'*C_21overlaping*R_1b{1,t-1},C_21'*C_21*R_2b{1,t-1}];
 c_23=C_23intersection'*C_23overlaping*c_3b{1,t-1} +C_23'*C_23*c_2b{1,t-1};   
 R_23=[C_23intersection'*C_23overlaping*R_3b{1,t-1},C_23'*C_23*R_2b{1,t-1}];
 z_22=zonotope(c_2b{1,t-1},R_2b{1,t-1}); z22=computeHRep(z_22);
 z_21=zonotope(c_21,R_21); z21=computeHRep(z_21);
 z_23=zonotope(c_23,R_23); z23=computeHRep(z_23);
 z_2r=Polyhedron('H',[[z22.A;z21.A;z23.A] [z22.b;z21.b;z23.b]]); z2r=computeVRep(z_2r);
 c_22r{1,t-1}=(max(z2r.V)'+min(z2r.V)')/2;
 R_22r{1,t-1}=diag(abs(max(z2r.V)'-min(z2r.V)')/2);
 P_22r(:,t-1) =sum(abs(R_22r{1,t-1}), 2);
 x_22r_up(:, t-1)= c_22r{1,t-1} + P_22r(:,t-1);
 x_22r_down(:,t-1)=c_22r{1,t-1} - P_22r(:,t-1);
 %第三个估计器 使用box来实现
 % 首先增广
 c_32=C_32intersection'*C_32overlaping*c_2b{1,t-1} +C_32'*C_32*c_3b{1,t-1};   
 R_32=[C_32intersection'*C_32overlaping*R_2b{1,t-1},C_32'*C_32*R_3b{1,t-1}];
 z_33=zonotope(c_3b{1,t-1},R_3b{1,t-1}); z33=computeHRep(z_33);
 z_32=zonotope(c_32,R_32); z32=computeHRep(z_32);
 z_3r=Polyhedron('H',[[z33.A;z32.A] [z33.b;z32.b]]); z3r=computeVRep(z_3r);
 c_33r{1,t-1}=(max(z3r.V)'+min(z3r.V)')/2;
 R_33r{1,t-1}=diag(abs(max(z3r.V)'-min(z3r.V)')/2);
 P_33r(:,t-1) =sum(abs(R_33r{1,t-1}), 2);
 x_33r_up(:, t-1)= c_33r{1,t-1} + P_33r(:,t-1);
 x_33r_down(:,t-1)=c_33r{1,t-1}-  P_33r(:,t-1);
  %% 跳出循环
   if t == N+1
        break;  % 立即终止循环
    end
%% 估计器设计
 % 第一个估计器 中心对称多细胞体估计器设计
 c_1d{1,t} = A_1*c_11r{1,t-1}+U_1(:,t)+A_12 *c_2b{1,t-1};
 R_1d{1,t}= [A_1*R_11r{1,t-1},A_12*R_2b{1,t-1},QE1];
 K_11 = R_1d{1,t}*R_1d{1,t}'*C_1'*inv(C_1*R_1d{1,t}*R_1d{1,t}'*C_1' + RE1*RE1');
 c_1b{1,t} = (eye(4)-K_11*C_1)*c_1d{1,t} + K_11*y_1(:, t);
 R_1b{1,t} = [(eye(4)-K_11*C_1)*R_1d{1,t},-K_11*RE1];
 R_1b{1,t} = Reduction(R_1b{1,t},5);
 P_1b(:,t)=sum(abs(R_1b{1,t}), 2);
 x_1b_up(:, t)= c_1b{1,t} + P_1b(:,t);
 x_1b_down(:, t)=c_1b{1,t}-P_1b(:,t);
 % 第二个估计器 中心对称多细胞体估计器设计
 c_2d{1,t} = A_2*c_22r{1,t-1}+A_21*c_1b{1,t-1}+A_23*c_3b{1,t-1}+U_2(:,t);                %c_1a{1,t-1}
 R_2d{1,t} = [A_2*R_22r{1,t-1},A_21*R_2b{1,t-1},A_23*R_3b{1,t-1}, QE2];
 K_22 = R_2d{1,t}*R_2d{1,t}'*C_2'* inv(C_2*R_2d{1,t}*R_2d{1,t}'*C_2' + RE2*RE2');
 c_2b{1,t}= (eye(4)-K_22*C_2)*c_2d{1,t} + K_22*y_2(:, t);
 R_2b{1,t} = [(eye(4)-K_22*C_2)*R_2d{1,t},-K_22*RE2];
 R_2b{1,t} = Reduction(R_2b{1,t},5);
 P_2b(:,t)=sum(abs(R_2b{1,t}), 2);
 x_2b_up(:, t)= c_2b{1,t} + P_2b(:,t);
 x_2b_down(:, t)=c_2b{1,t}-P_2b(:,t);
 % 第三个估计器 中心对称多细胞体估计器设计
 c_3d{1,t}=A_3*c_33r{1,t-1} +A_32*c_2b{1,t-1}+ U_3(:,t);
 R_3d{1,t}=[A_3*R_33r{1,t-1},A_32*R_2b{1,t-1}, QE3];
 K_33 = R_3d{1,t}*R_3d{1,t}'*C_3'*inv(C_3*R_3d{1,t}*R_3d{1,t}'*C_3' + RE3*RE3');
 c_3b{1,t}=(eye(4)-K_33*C_3)*c_3d{1,t}+K_33*y_3(:, t);
 R_3b{1,t}=[(eye(4)-K_33*C_3)*R_3d{1,t}, -K_33*RE3 ];
 R_3b{1,t} = Reduction(R_3b{1,t},5);
 P_3b(:,t)=sum(abs(R_3b{1,t}), 2);
 x_3b_up(:, t)= c_3b{1,t} + P_3b(:,t);
 x_3b_down(:, t)=c_3b{1,t}-P_3b(:,t);
 end

%%  改进的中心对称多细胞体（test）
clc
clear
n=2;r1=4;r2=4;
R1=2*rand(n,r1)-1;
c1=2*rand(n,1)-1;
R2=2*rand(n,r2)-1;
c2=2*rand(n,1)-1;
z1=zonotope(c1,R1); z1=computeHRep(z1);
z2=zonotope(c2,R2); z2=computeHRep(z2);
K_r=R1*R1'*inv(R1*R1'+R2*R2');
c_r=(eye(2)-K_r)*c1+K_r*c2;
R_r=[(eye(2)-K_r)*R1,K_r*R2];  
zr=zonotope(c_r,R_r); zr=computeHRep(zr);
z3=Polyhedron('H',[[z1.A;z2.A] [z1.b;z2.b]]); z3=computeVRep(z3); % The common region by H-representation and V-representation
H_new = [];
b_new = [];
num_constraints = size(zr.A,1);  % 约束数 = zr.A的行数
num_vertices = size(z3.V,1);     % 顶点数 = z3.V的行数
b0 = zeros(num_constraints, num_vertices); % 预先分配内存
%% impoved Zonotopic estimate 1 (只有转化为条带之后才能转化为zonotope，所以先转化条带吧)
%% 代码感觉还是不太智能, 应该先排序先让其生成
for i=1:size(zr.A,1)
    for j=1:size(z3.V,1)
        b0(i,j)=zr.A(i,:)*z3.V(j,:)';
    end
       b0_diff1(i,:)=b0(i,:)-zr.b(i);
       b0_diff(i,:)=abs(b0(i,:)-zr.b(i));
       [~,I(i,:)]=max(b0_diff(i,:));  
       b_r(i,:)= b0(i,I(i,:));  
       H_new = [H_new; -zr.A(i,:)];                 % 对称法向量
       b_new = [b_new; -b0(i,I(i,:))];              % 对称边界
end
P_tight = Polyhedron('A', H_new, 'b', b_new); P_tight=computeVRep(P_tight);
 % 去除冗余超平面

c5=(max(z3.V)'+min(z3.V)')/2;
R5=diag(abs(max(z3.V)'-min(z3.V)')/2);
zib=zonotope(c5,R5);
c6=(max(zr.V)'+min(zr.V)')/2;
R6=diag(abs(max(zr.V)'-min(zr.V)')/2);
z6=zonotope(c6,R6);
c7=(max(P_tight.V)'+min(P_tight.V)')/2;
R7=diag(abs(max(P_tight.V)'-min(P_tight.V)')/2);
z7=zonotope(c7,R7);

figure(1)
hold on
plot(zr,'color','k','alpha',0.3);
plot(z3,'color','w','alpha',0.3);
plot(z3.V(:,1),z3.V(:,2),'ro');
plot(zib,'color','b','alpha',0.1);
plot(P_tight,'color','r','alpha',0.1);
plot(z7,'color','c','alpha',0.3);




%% 绘图只看 重叠部分的
subplot(1, 2, 1);
plot(1:N, x_1a_up(3, :), 'b--', 'LineWidth', 1.5);hold on;
plot(1:N, x_1r_up(3, :), 'r--', 'LineWidth', 1.5);
plot(1:N, x_1(3, :), 'k', 'LineWidth', 1.5);
plot(1:N, x_1a_down(3, :), 'b--', 'LineWidth', 1.5);
plot(1:N, x_1r_down(3, :), 'r--', 'LineWidth', 1.5);
xlabel('K');
ylabel('m/s');
legend('(x_1a_up)','(x_1r_up)','实际曲线 (x)', '(x_1a_down)','(x_1r_down)');

subplot(1, 2, 2);
plot(1:N, x_1a_up(4, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x_1r_up(4, :), 'r--', 'LineWidth', 1.5);
plot(1:N, x_1(4, :), 'k', 'LineWidth', 1.5);
plot(1:N, x_1a_down(4, :), 'b--', 'LineWidth', 1.5);
plot(1:N, x_1r_down(4, :), 'r--', 'LineWidth', 1.5);
xlabel('k');
ylabel('m/s');
legend('(x_1a_up)','(x_1r_up)','实际曲线 (x)', '(x_1a_down)','(x_1r_down)');

subplot(1, 2, 1);
plot(1:N, x_3a_up(1, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x_3r_up(1, :), 'r--', 'LineWidth', 1.5);
plot(1:N, x_3(1, :), 'k', 'LineWidth', 1.5);
plot(1:N, x_3a_down(1, :), 'b--', 'LineWidth', 1.5);
plot(1:N, x_3r_down(1, :), 'r--', 'LineWidth', 1.5);
xlabel('k');
ylabel('m/s');
legend('(x_3a_up)','(x_3r_up)','实际曲线 (x)', '(x_3a_down)','(x_3r_down)');


plot(1:N, x_3a_up(2, :), 'b--', 'LineWidth', 1.5); hold on;
plot(1:N, x_3r_up(2, :), 'r--', 'LineWidth', 1.5);
plot(1:N, x_3(2, :), 'k', 'LineWidth', 1.5);
plot(1:N, x_3a_down(2, :), 'b--', 'LineWidth', 1.5);
plot(1:N, x_3r_down(2, :), 'r--', 'LineWidth', 1.5);
xlabel('k');
ylabel('m/s');
legend('(x_3a_up)','(x_3r_up)','实际曲线 (x)', '(x_3a_down)','(x_3r_down)');

%% 找两个可视化的中心对称多细胞体看看效果  
zOO_1=[0;0]; ZOO_1=diag([1,1]);
zOO_2=[0;1]; ZOO_2=diag([1,1]);
zOO_3=[0;0.5];  ZOO_3=diag([1,0.5]);
ZO_1= zonotope(zOO_1, ZOO_1);
ZO_2= zonotope(zOO_2, ZOO_2);
ZO_3= zonotope(zOO_3, ZOO_3);
%% 现在需要考虑融合之后的中心对称多细胞体在不同性能指标下的性能效果
%  F半径下的
K_1=ZOO_1*ZOO_1'*inv(ZOO_1*ZOO_1'+ZOO_2*ZOO_2');
zOO_F1=(eye(2)-K_1)*zOO_1+K_1*zOO_2;
ZOO_F1=[(eye(2)-K_1)*ZOO_1,K_1*ZOO_2];
ZO_F1= zonotope(zOO_F1, ZOO_F1);
% 以区间为性能指标的
N_1r=[ZOO_1,zeros(2,2)];
N_2r=[-ZOO_1,ZOO_2];
Mr_opt = zeros(2, 2);
 % 配置求解器选项（只需设置一次）
    options = sdpsettings('solver', 'sedumi', ...
        'verbose', 1, ...
        'sedumi.eps', 1e-10, ... % 求解精度
        'sedumi.maxiter', 200); % 最大迭代次数
 % 使用循环求解优化问题
    for i = 1:2
        % 定义决策变量
        Lr_i = sdpvar(4, 1);      % 向量λ_i
        Mr_i = sdpvar(1, 2);      % 矩阵Λ_i
        % 构建约束条件
        Constraints = [
            N_1r(i,:)' +  N_2r'*Mr_i' >= -Lr_i,
            N_1r(i,:)' +  N_2r'*Mr_i' <=  Lr_i
            ];
        % 设置目标函数
        Objective = sum(Lr_i);
        % 求解优化问题
        result = optimize(Constraints, Objective, options);
        % 检查求解结果
          if result.problem == 0  % 如果问题求解成功
             Mr_opt(i,:) = value(Mr_i);  % 存储最优解
          else  % 如果求解失败
              disp(['优化问题在第 ' num2str(i) ' 行求解失败。']);
              disp('错误信息:');
              disp(result.info);  % 输出错误信息
              Mr_opt(i,:) = NaN;  % 如果失败，设定为NaN
          end
    end
  % 最终结果矩阵
    K_r= Mr_opt;
  % 计算融合结果
   zOO_B1= (eye(2)-K_r)*zOO_1 + K_r*zOO_2;
   ZOO_B1= N_1r+K_r*N_2r; 
   ZO_B1= zonotope(zOO_B1, ZOO_B1);
