clc
clear;
%% 系统参数
T=100; %迭代步长
A=[0 1 0; 0 -0.5 1; 0 0.3 -1];
B=[1 0 0 ; 0 1 0 ; 0 0 1 ];
C=[1 0 0]; a=0.2;
B_w=zeros(3,3); D_v=1; v_upper=0.1;
B_d=[B_w,zeros(3,1)]; D_d=[zeros(1,3),D_v];
M=[1 1 1 0 0 0 0 0 0; 0 0 0 1 1 1 0 0 0; 0 0 0 0 0 0 1 1 1];
N = [0.01 0 0  0.001 0 0 0.001 0 0; 0 0.01 0 0 0.01 0 0 0.001 0 ; 0 0 0.001 0 0 0.01 0 0 0.01]';
%% 初始状态的生成
x(:,1)=[0;0;0];x_e(:,1)=[0;0;0]; X_e(:,:,1)=diag([0.01,5,5]);
Delta_A{1,1}=[0.01*cos(1) 0.01 0.001;0.001 0.01*sin(1) 0.01*cos(2*1);0.001 0.001*cos(2*1) 0.01*sin(1)];
v(:,1)=0;Sigma{1,1}=zeros(3,3); 
y(:,1)=C*x(:, 1)+D_v*v(:,1);
u(:,1)=[3*(cos(y(:,1))+cos(y(:,1))*cos(0.1)) ; sin(1)+0.1 ; -cos(1)+0.1];
Q(:,:,1)=zeros(3,3); e(:,1)=[0.01,5,5]; d_infinite=v_upper*v_upper;
f(1,1)=(N*x_e(:,1))'*N*x_e(:,1);
%% 时变矩阵的生成，观测方程和状态方程的生成
for i=2:T   
    Delta_A{1,i}=[0.01*cos(i) 0.01 0.001;0.001 0.01*sin(i) 0.01*cos(2*i);0.001 0.001*cos(2*i) 0.01*sin(i)];
    v(:,i)=0.05*(sin(5*i)+cos(3*i));
     Sigma{1,i}=diag([cos(i),1,1,1,sin(i),cos(2*i),1,cos(2*i),0.01*sin(i)]);
     x(:,i)=(A+Delta_A{1,i-1})*x(:, i-1)+B*u(:,i-1);
     y(:,i)=C*x(:,i)+D_v*v(:,i);
     u(:,i)=[3*(cos(y(:,i))+cos(y(:,i))*cos(0.1)) ; sin(i)+0.1 ; -cos(i)+0.1];
end
%% 使用自带的工具箱求解
setlmis([]); % 初始化LMI系统
% ======== 定义变量 ========
% 对称矩阵 P ∈ R^(3×3)
P = lmivar(1, [3 1]);  % Type 1: 对称矩阵
% 矩阵 W ∈ R^(3×1)
W = lmivar(2, [3 1]);  % Type 2: 普通矩阵
% 标量 epsilon
epsilon = lmivar(1, [1 0]); % Type 1: 标量
% 标量 gamma
gamma = lmivar(1, [1 0]); % Type 1: 标量
% ======== 主LMI约束 ========
% Block (1,1): He(A*P - W*C) + a*P + ε*N'*N
lmiterm([1 1 1 P], A, 1, 's');       % PA + A'P
lmiterm([1 1 1 W], -1, C, 's');      % -WC - C'W'
lmiterm([1 1 1 P], a, 1);            % a*P
lmiterm([1 1 1 epsilon], N'*N, 1);   % ε*N'*N (标量系数)
% Block (1,2): P*M
lmiterm([1 1 2 P], 1, M);            % P*M
% Block (1,3): P*B_d - W*D_d
lmiterm([1 1 3 P], 1, B_d);          % P*B_d
lmiterm([1 1 3 W], -1, D_d);         % -W*D_d
% Block (1,4): P*M
lmiterm([1 1 4 P], 1, M);            % P*M
% Block (2,2): -a*I (维度9×9)
lmiterm([1 2 2 0], -a*eye(9));       % -a*I
% Block (3,3): -a*I (维度4×4)
lmiterm([1 3 3 0], -a*eye(4));       % -a*I
% Block (4,4): -ε*I (维度9×9)
lmiterm([1 4 4 epsilon], -1, 1);     % -ε*I (标量系数)
% ======== 辅助约束 P > γI ========
lmiterm([-2 1 1 P], 1, 1);            % P
lmiterm([-2 1 1 gamma], -1, eye(3));  % -γI
% 定义两个正标量
lmiterm([-3 1 1 epsilon], 1, 1);            % P
lmiterm([-4 1 1 gamma], 1, 1);  % -γI
% ======== 定义优化目标 ========
lmisys = getlmis; % 完成LMI系统定义
c = [zeros(1,decnbr(lmisys)-1), -1];    % 目标函数：min -γ
% ======== 求解LMI ========
%定义options参数 
options=[1e-100 0 0 0 0]; 
[tmin, xfeas] = mincx(lmisys, c,options);
% ======== 提取结果 ========
if ~isempty(xfeas)
    P_val = dec2mat(lmisys, xfeas, P);
    W_val = dec2mat(lmisys, xfeas, W);
    gamma_val = dec2mat(lmisys, xfeas, gamma);
    epsilon_val = dec2mat(lmisys, xfeas, epsilon);
    L = inv(P_val) * W_val;
    disp('LMI求解成功，观测器增益L为：');
    disp(L);
else
    disp('LMI不可行');
end

eigenvalues = eig(P_val);
lamada= max(eigenvalues);
%% 书写全局的两个估计器
for t=2:T

x_e(:,t)=A*x_e(:,t-1)+ B*u(:,i) + L*(y(:,t)-C*x_e(:,t-1));
%提取τ=1到τ=t的数据
taus = 1:t;
x_subset = x_e(:,taus);
f(1,t)=(N*x_e(:,t))'*N*x_e(:,t);
weights=zeros(1,t);
for i = 1:t
    weights(1,t) = a*exp(-a*(t-i)); % 若x_hat是标量，直接计算
end
Z=weights*f';
Q(:,:,t)=inv(P_val)*(lamada*exp(-a*t)*e(:,1)'*e(:,1) + Z +(1-exp(-a*t)*d_infinite));
X(:,:,t)=(lamada*exp(-a*t)*e(:,1)'*e(:,1) + inv(gamma_val)*(Z +(1-exp(-a*t)*d_infinite)) )*eye(3);
end
X(:,:,15)
diag_elements = diag(X(:,:,15));
%% 绘制图像
% 定义椭球中心和形状矩阵
c = x_e(:,15);        % 3×1中心向量
Q_t = Q(:,:,t);       % 3×3形状矩阵
% 特征分解获取旋转和缩放因子
[V, D] = eig(Q_t);
scaling = sqrt(diag(D));

% 生成单位球面网格
[u, v] = meshgrid(linspace(0, 2*pi, 50), linspace(0, pi, 50));
x = cos(u) .* sin(v);
y = sin(u) .* sin(v);
z = cos(v);

% 应用缩放、旋转和平移
points = [x(:), y(:), z(:)] * diag(scaling) * V';
x_new = reshape(points(:,1), size(x)) + c(1);
y_new = reshape(points(:,2), size(y)) + c(2);
z_new = reshape(points(:,3), size(z)) + c(3);
x_min=x_e(1,15)-diag_elements(1); x_max=x_e(1,15)+diag_elements(1);
y_min=x_e(2,15)-diag_elements(1); y_max=x_e(1,15)+diag_elements(1);
z_min=x_e(3,15)-diag_elements(1); z_max=x_e(1,15)+diag_elements(1);
% 绘制椭球
figure;
surf(x_new, y_new, z_new, 'EdgeColor', 'none', 'FaceAlpha', 0.5);
axis equal;
hold on;
plot3([x_min x_max], [y_min y_max], [z_min z_max], 'k', 'LineWidth', 2);
xlabel('X'); ylabel('Y'); zlabel('Z');
title(['椭球形状 (t=', num2str(t), ')']);

















% %% 使用sedumi进行求解
% P = sdpvar(3, 3, 'symmetric');
% W = sdpvar(3, 1, 'full');
% gamma = sdpvar(1, 1);
% epsilon = sdpvar(1, 1);
% He_PA_WC = A*P - W*C;
% term11 = He_PA_WC + He_PA_WC' + epsilon*(N')*N + a*P;
% term12 = P*M;
% term13 = P*B_d - W*D_d;
% term14 = P*M;
% LMI = [term11,     term12,     term13,      term14;
%        term12',   -a*eye(9),   zeros(9,4),  zeros(9,9);
%        term13',   zeros(4,9),  -a*eye(4,4), zeros(4,9);
%        term14',   zeros(9,9),   zeros(9,4), -epsilon*eye(9,9)];
% 
% 
% Constraints = [P >= gamma*eye(3), epsilon >= 0.00000000000000000001, gamma >= 0.00000000000001, LMI <= 0];
% 
% Objective = -gamma;
% options = sdpsettings('solver', 'sedumi', 'verbose', 1);
% sol = optimize(Constraints, Objective, options);
% % 判断并提取结果
% if sol.problem == 0
%     % 成功求解
%     P_val = value(P);
%     W_val = value(W);
%     gamma_val = value(gamma);
%     epsilon_val = value(epsilon);
%     L = inv(P_val) * W_val;
% else
%     disp('Problem encountered:');
%     disp(sol.info);
% end

%% 求解全局的L，来方便后续的迭代，L只需求解一次
a=1.1;
setlmis([]);
% 定义变量P为对称矩阵
P = lmivar(1, [size(A, 1) 1]); 
% 定义变量gamma为标量
gamma = lmivar(1, [1 1]);
epsilon = lmivar(1, [1 1]);
% 定义变量W，假设其维度与问题匹配
W = lmivar(2, [3  1]); 
He_PA_WC = P*A - W*C + (P*A - W*C)';
% 定义LMI
lmi1 = newlmi;
lmiterm([lmi1 1 1 P], A', 1, 's');                   % PA + (PA)'
lmiterm([lmi1 1 1 W], -1, C, 's');                  % -WC - C'*W'
lmiterm([lmi1 1 1 P], a*eye(3), 1);                         % a*P
lmiterm([lmi1 1 1 epsilon], N'*N, 1);                % epsilon*N'*N
% Block (1,2): P*M
lmiterm([lmi1 1 2 P], 1, M);
% Block (1,3): P*B_d - W*D_d
lmiterm([lmi1 1 3 P], 1, B_d);
lmiterm([lmi1 1 3 W], -1, D_d);
% Block (1,4): P*M
lmiterm([lmi1 1 4 P], 1, M);
% Block (2,2): -a*I
lmiterm([lmi1 2 2 0], -a * eye(9));
% Block (3,3): -a*I
lmiterm([lmi1 3 3 0], -a * eye(4));
% Block (4,4): -epsilon*I
lmiterm([lmi1 4 4 epsilon], -1, eye(9));
lmi2 = newlmi;
lmiterm([lmi2 1 1 P], 1, 1);           % P
lmiterm([lmi2 1 1 gamma], -1, eye(3));
lmisys = getlmis;
obj = -gamma;
% 求解LMI
[tmin, xfeas] = mincx(obj,lmisys);
% 提取P,W,gama，eosilon的值
P_value = dec2mat(lmisys, xfeas, P);
W_value = dec2mat(lmisys, xfeas, W);
gamma_value = dec2mat(lmisys, xfeas, gamma);
epsilon_value = dec2mat(lmisys, xfeas, epsilon);
% 计算L
L = inv(P_value)*W_value;
%%
setlmis([]);
% 定义变量P为对称矩阵
P = lmivar(1, [size(A, 1) 1]); 
% 定义变量gamma为标量
gamma = lmivar(1, [1 1]);
epsilon = lmivar(1, [1 1]);
% 定义变量W，假设其维度与问题匹配
W = lmivar(2, [3  1]); 
He_PA_WC = P*A - W*C + (P*A - W*C)';
% 定义LMI
lmi1 = newlmi;
% Block (1,1): He(PA - WC) + epsilon*N'*N + a*P
lmiterm([lmi1 1 1 P], A', 1, 's');                   % PA + A'*P
lmiterm([lmi1 1 1 W], -C', 1, 's');                  % -WC - C'*W
lmiterm([lmi1 1 1 P], a, 1);                         % a*P
lmiterm([lmi1 1 1 epsilon], N'*N, 1);                % epsilon*N'*N
% Block (1,2): P*M
lmiterm([lmi1 1 2 P], 1, M);
% Block (1,3): P*B_d - W*D_d
lmiterm([lmi1 1 3 P], 1, B_d);
lmiterm([lmi1 1 3 W], -1, D_d);
% Block (1,4): P*M
lmiterm([lmi1 1 4 P], 1, M);
% Block (2,2): -a*I
lmiterm([lmi1 2 2 0], -a * eye(3));
% Block (3,3): -a*I
lmiterm([lmi1 3 3 0], -a * eye(3));
% Block (4,4): -epsilon*I
lmiterm([lmi1 4 4 epsilon], -1, eye(9));
lmi2 = newlmi;
lmiterm([lmi2 1 1 P], 1, 1);           % P
lmiterm([lmi2 1 1 gamma], -1, eye(3));
lmisys = getlmis;
% 其余块对称
% getlmis to finalize
obj = -gamma;
% 求解LMI
[tmin, xfeas] = mincx(obj, lmisys);
% 提取P,W,gama，eosilon的值
P_value = dec2mat(lmisys, xfeas, P);
W_value = dec2mat(lmisys, xfeas, W);
gamma_value = dec2mat(lmisys, xfeas, gamma);
epsilon_value = dec2mat(lmisys, xfeas, epsilon);
% 计算L
L = inv(P_value)*W_value;
