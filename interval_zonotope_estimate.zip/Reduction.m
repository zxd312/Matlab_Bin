function [ Reduced_R ] = Reduction( R,q )
    n=size(R,1);
    r=size(R,2);
    for i=1:r
        size_R(i)=norm(R(:,i));
    end
    [M,N]=sort(size_R,'descend');
    for i=1:r
        tilde_R(:,i)=R(:,N(i));
    end
    if q>r
        Reduced_R=tilde_R;
    else
        R1=tilde_R(:,1:q-n);
        R2=tilde_R(:,q-n+1:r);
        R2=diag(sum(abs(R2)')');
        Reduced_R=[R1 R2];
    end
end

