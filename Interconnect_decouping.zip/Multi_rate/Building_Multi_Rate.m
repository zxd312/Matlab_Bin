%% 四个互联的建筑物    解耦和不解耦的性能比较
clc
clear
close all;
N=250;   % Time steps
q=15;    % Reduction parameter
%% System parameter
s_p=600;  c_p=1.012;
u_1=0.25; u_2=0.3;
u_3=0.35; u_4=0.3;
R_12=120; R_21=120;
R_13=150; R_31=150;
R_24=100; R_42=100;
R_34=90;  R_43=90;
c_1=1600; c_2=1800;
c_3=1500; c_4=1900;
T_01=23.5; T_02=24;
T_03=23.5; T_04=24;
%% System modeling (每个区域部署四个传感器,而且每个分别安装二倍速,三倍速,三倍速和四倍速,二倍速) 假设倍速高的精度高一点.
A_1=1-(s_p*u_1*c_p/c_1)-(s_p/c_1)*(1/R_12 + 1/R_13);
A_12=s_p/(c_1*R_12); A_13=s_p/(c_1*R_13); Gamma_1=s_p/c_1;
A_2=1-(s_p*u_2*c_p/c_2)-(s_p/c_2)*(1/R_21 + 1/R_24);
A_21=s_p/(c_2*R_21); A_24=s_p/(c_2*R_24); Gamma_2=s_p/c_2;
A_3=1-(s_p*u_3*c_p/c_3)-(s_p/c_3)*(1/R_31 + 1/R_34);
A_31=s_p/(c_3*R_31); A_34=s_p/(c_3*R_34); Gamma_3=s_p/c_3;
A_4=1-(s_p*u_4*c_p/c_4)-(s_p/c_4)*(1/R_42 + 1/R_43);
A_42=s_p/(c_4*R_42); A_43=s_p/(c_4*R_43); Gamma_4=s_p/c_4;
C_11=1; C_12=1; C_13=1; C_14=1; C_15=1;
C_21=1; C_22=1; C_23=1; C_24=1; C_25=1;
C_31=1; C_32=1; C_33=1; C_34=1; C_35=1;
C_41=1; C_42=1; C_43=1; C_44=1; C_45=1;
U_1=s_p*u_1*c_p*T_01/c_1;
U_2=s_p*u_2*c_p*T_02/c_2;
U_3=s_p*u_3*c_p*T_03/c_3;
U_4=s_p*u_4*c_p*T_04/c_4;
%% noise
Q_1=0.2; Q_2=0.1; Q_3=0.3; Q_4=0.1;
w_1= 0.4*rand(1,N)-0.2; w_2= 0.2*rand(1,N)-0.1;
w_3= 0.6*rand(1,N)-0.3; w_4= 0.2*rand(1,N)-0.1;
R_11=0.4; R_12=0.3; R_13=0.3; R_14=0.2; R_15=0.4;
R_21=0.4; R_22=0.3; R_23=0.3; R_24=0.2; R_25=0.4;
R_31=0.4; R_32=0.3; R_33=0.3; R_34=0.2; R_35=0.4;
R_41=0.4; R_42=0.3; R_43=0.3; R_44=0.2; R_45=0.4;
v_11= 0.8*rand(1,N)-0.4; v_12= 0.6*rand(1,N)-0.3; v_13= 0.6*rand(1,N)-0.3; v_14= 0.4*rand(1,N)-0.2; v_15= 0.8*rand(1,N)-0.4;
v_21= 0.8*rand(1,N)-0.4; v_22= 0.6*rand(1,N)-0.3; v_23= 0.6*rand(1,N)-0.3; v_24= 0.4*rand(1,N)-0.2; v_25= 0.8*rand(1,N)-0.4;
v_31= 0.8*rand(1,N)-0.4; v_32= 0.6*rand(1,N)-0.3; v_33= 0.6*rand(1,N)-0.3; v_34= 0.4*rand(1,N)-0.2; v_35= 0.8*rand(1,N)-0.4;
v_41= 0.8*rand(1,N)-0.4; v_42= 0.6*rand(1,N)-0.3; v_43= 0.6*rand(1,N)-0.3; v_44= 0.4*rand(1,N)-0.2; v_45= 0.8*rand(1,N)-0.4;
%% 初始状态
x_1(:, 1)=25; x_2(:, 1)=25; x_3(:, 1)=25; x_4(:, 1)=25;
y_11(:,1)=C_11 * x_1(:, 1) + v_11(:, 1);  y_12(:,1)=C_12 * x_1(:, 1) + v_12(:, 1); 
y_13(:,1)=C_13 * x_1(:, 1) + v_13(:, 1);  y_14(:,1)=C_14 * x_1(:, 1) + v_14(:, 1); y_15(:,1)=C_15 * x_1(:, 1) + v_15(:, 1);
y_21(:,1)=C_21 * x_2(:, 1) + v_21(:, 1);  y_22(:,1)=C_22 * x_2(:, 1) + v_22(:, 1);
y_23(:,1)=C_23 * x_2(:, 1) + v_23(:, 1);  y_24(:,1)=C_24 * x_2(:, 1) + v_24(:, 1); y_25(:,1)=C_25 * x_2(:, 1) + v_25(:, 1);
y_31(:,1)=C_31 * x_3(:, 1) + v_31(:, 1);  y_32(:,1)=C_32 * x_3(:, 1) + v_32(:, 1);
y_33(:,1)=C_33 * x_3(:, 1) + v_33(:, 1);  y_34(:,1)=C_34 * x_3(:, 1) + v_34(:, 1); y_35(:,1)=C_35 * x_3(:, 1) + v_35(:, 1);
y_41(:,1)=C_41 * x_4(:, 1) + v_41(:, 1);  y_42(:,1)=C_42 * x_4(:, 1) + v_42(:, 1);
y_43(:,1)=C_43 * x_4(:, 1) + v_43(:, 1);  y_44(:,1)=C_44 * x_4(:, 1) + v_44(:, 1); y_45(:,1)=C_45 * x_4(:, 1) + v_45(:, 1);
%% 生成关于多速率的句子MR;
MR_11=zeros(1,N);   MR_12=zeros(1,N);   MR_13=zeros(1,N);  MR_14=zeros(1,N);  MR_15=zeros(1,N); 
MR_21=zeros(1,N);   MR_22=zeros(1,N);   MR_23=zeros(1,N);  MR_24=zeros(1,N);  MR_25=zeros(1,N); 
MR_31=zeros(1,N);   MR_32=zeros(1,N);   MR_33=zeros(1,N);  MR_34=zeros(1,N);  MR_35=zeros(1,N);
MR_41=zeros(1,N);   MR_42=zeros(1,N);   MR_43=zeros(1,N);  MR_44=zeros(1,N);  MR_45=zeros(1,N);
%% 赋值
% 第一个子系统
MR_11=assign_rate_vector(2,MR_11,2,N);  MR_12=assign_rate_vector(2,MR_12,3,N); 
MR_13=assign_rate_vector(4,MR_13,3,N);  MR_14=assign_rate_vector(2,MR_14,4,N); MR_15=assign_rate_vector(3,MR_15,2,N);
% 第二个子系统
MR_21=assign_rate_vector(2,MR_21,2,N);  MR_22=assign_rate_vector(2,MR_22,3,N); 
MR_23=assign_rate_vector(4,MR_23,3,N);  MR_24=assign_rate_vector(2,MR_24,4,N); MR_25=assign_rate_vector(3,MR_25,2,N);
% 第三个子系统
MR_31=assign_rate_vector(2,MR_31,2,N);  MR_32=assign_rate_vector(2,MR_32,3,N); 
MR_33=assign_rate_vector(4,MR_33,3,N);  MR_34=assign_rate_vector(2,MR_34,4,N); MR_35=assign_rate_vector(3,MR_35,2,N);
% 第四个子系统
MR_41=assign_rate_vector(2,MR_41,2,N);  MR_42=assign_rate_vector(2,MR_42,3,N); 
MR_43=assign_rate_vector(4,MR_43,3,N);  MR_44=assign_rate_vector(2,MR_44,4,N); MR_45=assign_rate_vector(3,MR_45,2,N);
%% 初始协方差矩阵和状态  A的可以表示为解耦的，B的可以表示为序贯的即不解耦的
R_1a{1,1}=0.5;R_1b{1,1}=0.5; R_1{1,1}=0.1;
R_2a{1,1}=0.5;R_2b{1,1}=0.5; R_2{1,1}=0.1;
R_3a{1,1}=0.5;R_3b{1,1}=0.5; R_3{1,1}=0.1;
R_4a{1,1}=0.5;R_4b{1,1}=0.5; R_4{1,1}=0.1;
R_1e{1,1}=0.5;R_1f{1,1}=0.5;
R_2e{1,1}=0.5;R_2f{1,1}=0.5;
R_3e{1,1}=0.5;R_3f{1,1}=0.5;
R_4e{1,1}=0.5;R_4f{1,1}=0.5;
c_1a{1,1}=25; c_2a{1,1}=25; c_3a{1,1}=25; c_4a{1,1}=25; 
c_1b{1,1}=25; c_2b{1,1}=25; c_3b{1,1}=25; c_4b{1,1}=25; 
J_1(1,1)=trace(R_1a{1,1}*R_1a{1,1}');  J_1b(1,1)=trace(R_1b{1,1}*R_1b{1,1}'); 
J_2(1,1)=trace(R_2a{1,1}*R_2a{1,1}');  J_2b(1,1)=trace(R_2b{1,1}*R_2b{1,1}');
J_3(1,1)=trace(R_3a{1,1}*R_3a{1,1}');  J_3b(1,1)=trace(R_3b{1,1}*R_3b{1,1}');
J_4(1,1)=trace(R_4a{1,1}*R_4a{1,1}');  J_4b(1,1)=trace(R_4b{1,1}*R_4b{1,1}');
x_1a_up(:,1)=c_1a{1,1}+0.5*ones(1,1);  x_1a_down(:,1)=c_1a{1,1}-0.5*ones(1,1);
x_2a_up(:,1)=c_2a{1,1}+0.5*ones(1,1);  x_2a_down(:,1)=c_2a{1,1}-0.5*ones(1,1);
x_3a_up(:,1)=c_3a{1,1}+0.5*ones(1,1);  x_3a_down(:,1)=c_3a{1,1}-0.5*ones(1,1);
x_4a_up(:,1)=c_4a{1,1}+0.5*ones(1,1);  x_4a_down(:,1)=c_4a{1,1}-0.5*ones(1,1);
x_1b_up(:,1)=c_1b{1,1}+0.5*ones(1,1);  x_1b_down(:,1)=c_1b{1,1}-0.5*ones(1,1);
x_2b_up(:,1)=c_2b{1,1}+0.5*ones(1,1);  x_2b_down(:,1)=c_2b{1,1}-0.5*ones(1,1);
x_3b_up(:,1)=c_3b{1,1}+0.5*ones(1,1);  x_3b_down(:,1)=c_3b{1,1}-0.5*ones(1,1);
x_4b_up(:,1)=c_4b{1,1}+0.5*ones(1,1);  x_4b_down(:,1)=c_4b{1,1}-0.5*ones(1,1);
%% 真实状态和观测状态的迭代
for t=2:N
 % 系统的真实状态
 x_1(:, t) = A_1 * x_1(:, t-1) + U_1 + A_12 * x_2(:, t-1) + A_13 * x_3(:, t-1) + Gamma_1 * w_1(:, t);
 x_2(:, t) = A_2 * x_2(:, t-1) + U_2 + A_21 * x_1(:, t-1) + A_24 * x_4(:, t-1) + Gamma_2 * w_2(:, t);
 x_3(:, t) = A_3 * x_3(:, t-1) + U_3 + A_31 * x_1(:, t-1) + A_34 * x_4(:, t-1) + Gamma_3 * w_3(:, t);
 x_4(:, t) = A_4 * x_4(:, t-1) + U_4 + A_42 * x_2(:, t-1) + A_43 * x_3(:, t-1) + Gamma_4 * w_4(:, t) ;
 % 观测更新
 y_11(:, t) = C_11 * x_1(:, t) + v_11(:, t);  y_12(:, t) = C_12 * x_1(:, t) + v_12(:, t); y_13(:, t) = C_13 * x_1(:, t) + v_13(:, t);
 y_14(:, t) = C_14 * x_1(:, t) + v_14(:, t);  y_15(:, t) = C_15 * x_1(:, t) + v_15(:, t); 

 y_21(:, t) = C_21 * x_2(:, t) + v_21(:, t);  y_22(:, t) = C_22 * x_2(:, t) + v_22(:, t); y_23(:, t) = C_23 * x_2(:, t) + v_23(:, t);
 y_24(:, t) = C_24 * x_2(:, t) + v_24(:, t);  y_25(:, t) = C_25 * x_2(:, t) + v_25(:, t); 

 y_31(:, t) = C_31 * x_3(:, t) + v_31(:, t);  y_32(:, t) = C_32 * x_3(:, t) + v_32(:, t); y_33(:, t) = C_33 * x_3(:, t) + v_33(:, t);
 y_34(:, t) = C_34 * x_3(:, t) + v_34(:, t);  y_35(:, t) = C_35 * x_3(:, t) + v_35(:, t); 

 y_41(:, t) = C_41 * x_4(:, t) + v_41(:, t);  y_42(:, t) = C_42 * x_4(:, t) + v_42(:, t); y_43(:, t) = C_43 * x_4(:, t) + v_43(:, t);
 y_44(:, t) = C_44 * x_4(:, t) + v_44(:, t);  y_45(:, t) = C_45 * x_3(:, t) + v_45(:, t); 
end

%% 多速率采样
for t=2:N
 % 多速率生成
 y_11(:, t)=MR_11(t)* y_11(:, t); y_12(:, t)=MR_12(t)* y_12(:, t); y_13(:, t)=MR_13(t)* y_13(:, t);
 y_14(:, t)=MR_14(t)* y_14(:, t); y_15(:, t)=MR_15(t)* y_15(:, t);
 y_21(:, t)=MR_21(t)* y_21(:, t); y_22(:, t)=MR_22(t)* y_22(:, t); y_23(:, t)=MR_23(t)* y_23(:, t);
 y_24(:, t)=MR_24(t)* y_24(:, t); y_25(:, t)=MR_15(t)* y_25(:, t);
 y_31(:, t)=MR_31(t)* y_31(:, t); y_32(:, t)=MR_32(t)* y_32(:, t); y_33(:, t)=MR_33(t)* y_33(:, t);
 y_34(:, t)=MR_34(t)* y_34(:, t); y_35(:, t)=MR_35(t)* y_35(:, t);
 y_41(:, t)=MR_41(t)* y_41(:, t); y_42(:, t)=MR_42(t)* y_42(:, t); y_43(:, t)=MR_43(t)* y_43(:, t);
 y_44(:, t)=MR_44(t)* y_44(:, t); y_45(:, t)=MR_45(t)* y_45(:, t);
end
%% 观测融合
MR1=zeros(1,N); MR2=zeros(1,N);  MR3=zeros(1,N); MR4=zeros(1,N);
% for t=2:N
% [y_1(:, t),R_1, MR1(t), C_1] = S_Msf(y_11(:, t), R_11, C_11, MR_11(t), y_12(:, t), R_12, C_12, MR_12(t));
% [y_1(:, t),R_1, MR1(t), C_1] = S_Msf(y_1(:, t), R_1, C_1, MR1(t), y_13(:, t), R_13, C_13, MR_13(t));
% [y_1(:, t),R_1, MR1(t), C_1] = S_Msf(y_1(:, t), R_1, C_1, MR1(t), y_14(:, t), R_14, C_14, MR_14(t));
% [y_1(:, t),R_1, MR1(t), C_1] = S_Msf(y_1(:, t), R_1, C_1, MR1(t), y_15(:, t), R_15, C_15, MR_15(t));
% end
% 
% for t=2:N
% [y_2(:, t),R_2, MR2(t), C_2] = S_Msf(y_21(:, t), R_21, C_21, MR_21(t), y_22(:, t), R_22, C_22, MR_22(t));
% [y_2(:, t),R_2, MR2(t), C_2] = S_Msf(y_2(:, t), R_2, C_2, MR2(t), y_23(:, t), R_23, C_23, MR_23(t));
% [y_2(:, t),R_2, MR2(t), C_2] = S_Msf(y_2(:, t), R_2, C_2, MR2(t), y_24(:, t), R_24, C_24, MR_24(t));
% [y_2(:, t),R_2, MR2(t), C_2] = S_Msf(y_2(:, t), R_2, C_2, MR2(t), y_25(:, t), R_25, C_25, MR_25(t));
% end
% 
% for t=2:N
% [y_3(:, t),R_3, MR3(t), C_3] = S_Msf(y_31(:, t), R_31, C_31, MR_31(t), y_32(:, t), R_32, C_32, MR_32(t));
% [y_3(:, t),R_3, MR3(t), C_3] = S_Msf(y_3(:, t), R_3, C_3, MR3(t), y_33(:, t), R_33, C_33, MR_33(t));
% [y_3(:, t),R_3, MR3(t), C_3] = S_Msf(y_3(:, t), R_3, C_3, MR3(t), y_34(:, t), R_34, C_34, MR_34(t));
% [y_3(:, t),R_3, MR3(t), C_3] = S_Msf(y_3(:, t), R_3, C_3, MR3(t), y_35(:, t), R_35, C_35, MR_35(t));
% end
% 
% for t=2:N
% [y_4(:, t),R_4, MR4(t), C_4] = S_Msf(y_41(:, t), R_41, C_41, MR_41(t), y_42(:, t), R_42, C_42, MR_42(t));
% [y_4(:, t),R_4, MR4(t), C_4] = S_Msf(y_4(:, t), R_4, C_4, MR4(t), y_43(:, t), R_43, C_43, MR_43(t));
% [y_4(:, t),R_4, MR4(t), C_4] = S_Msf(y_4(:, t), R_4, C_4, MR4(t), y_44(:, t), R_44, C_44, MR_44(t));
% [y_4(:, t),R_4, MR4(t), C_4] = S_Msf(y_4(:, t), R_4, C_4, MR4(t), y_45(:, t), R_45, C_45, MR_45(t));
% end
%% 解耦增益阵 (假设C是不变的)
% C_1K = inv(C_1'*C_1)*C_1';
% C_2K = inv(C_2'*C_2)*C_2';
% C_3K = inv(C_3'*C_3)*C_3';
% C_4K = inv(C_4'*C_4)*C_4';
% Ups_12 = A_12*C_2K;   
% Ups_13 = A_13*C_3K;  
% Ups_21 = A_21*C_1K; 
% Ups_24 = A_24*C_4K;
% Ups_31 = A_31*C_1K; 
% Ups_34 = A_34*C_4K;
% Ups_42 = A_42*C_2K; 
% Ups_43 = A_43*C_3K; 
%% Estimator Design with decoupling
for t=2:N
% 观测融合 传感器1
[y_1(:, t),R_1{1,t}, MR1(t), C_1] = S_Msf(y_11(:, t), R_11, C_11, MR_11(t), y_12(:, t), R_12, C_12, MR_12(t));
[y_1(:, t),R_1{1,t}, MR1(t), C_1] = S_Msf(y_1(:, t), R_1{1,t}, C_1, MR1(t), y_13(:, t), R_13, C_13, MR_13(t));
[y_1(:, t),R_1{1,t}, MR1(t), C_1] = S_Msf(y_1(:, t), R_1{1,t}, C_1, MR1(t), y_14(:, t), R_14, C_14, MR_14(t));
[y_1(:, t),R_1{1,t}, MR1(t), C_1] = S_Msf(y_1(:, t), R_1{1,t}, C_1, MR1(t), y_15(:, t), R_15, C_15, MR_15(t));
% 观测融合 传感器2
[y_2(:, t),R_2{1,t}, MR2(t), C_2] = S_Msf(y_21(:, t), R_21, C_21, MR_21(t), y_22(:, t), R_22, C_22, MR_22(t));
[y_2(:, t),R_2{1,t}, MR2(t), C_2] = S_Msf(y_2(:, t), R_2{1,t}, C_2, MR2(t), y_23(:, t), R_23, C_23, MR_23(t));
[y_2(:, t),R_2{1,t}, MR2(t), C_2] = S_Msf(y_2(:, t), R_2{1,t}, C_2, MR2(t), y_24(:, t), R_24, C_24, MR_24(t));
[y_2(:, t),R_2{1,t}, MR2(t), C_2] = S_Msf(y_2(:, t), R_2{1,t}, C_2, MR2(t), y_25(:, t), R_25, C_25, MR_25(t));
% 观测融合 传感器3
[y_3(:, t),R_3{1,t}, MR3(t), C_3] = S_Msf(y_31(:, t), R_31, C_31, MR_31(t), y_32(:, t), R_32, C_32, MR_32(t));
[y_3(:, t),R_3{1,t}, MR3(t), C_3] = S_Msf(y_3(:, t), R_3{1,t}, C_3, MR3(t), y_33(:, t), R_33, C_33, MR_33(t));
[y_3(:, t),R_3{1,t}, MR3(t), C_3] = S_Msf(y_3(:, t), R_3{1,t}, C_3, MR3(t), y_34(:, t), R_34, C_34, MR_34(t));
[y_3(:, t),R_3{1,t}, MR3(t), C_3] = S_Msf(y_3(:, t), R_3{1,t}, C_3, MR3(t), y_35(:, t), R_35, C_35, MR_35(t));
% 观测融合 传感器4
[y_4(:, t),R_4{1,t}, MR4(t), C_4] = S_Msf(y_41(:, t), R_41, C_41, MR_41(t), y_42(:, t), R_42, C_42, MR_42(t));
[y_4(:, t),R_4{1,t}, MR4(t), C_4] = S_Msf(y_4(:, t), R_4{1,t}, C_4, MR4(t), y_43(:, t), R_43, C_43, MR_43(t));
[y_4(:, t),R_4{1,t}, MR4(t), C_4] = S_Msf(y_4(:, t), R_4{1,t}, C_4, MR4(t), y_44(:, t), R_44, C_44, MR_44(t));
[y_4(:, t),R_4{1,t}, MR4(t), C_4] = S_Msf(y_4(:, t), R_4{1,t}, C_4, MR4(t), y_45(:, t), R_45, C_45, MR_45(t));

 C_1K = inv(C_1'*C_1)*C_1';
 C_2K = inv(C_2'*C_2)*C_2';
 C_3K = inv(C_3'*C_3)*C_3';
 C_4K = inv(C_4'*C_4)*C_4';
 Ups_12 = A_12*C_2K;   
 Ups_13 = A_13*C_3K;  
 Ups_21 = A_21*C_1K; 
 Ups_24 = A_24*C_4K;
 Ups_31 = A_31*C_1K; 
 Ups_34 = A_34*C_4K;
 Ups_42 = A_42*C_2K; 
 Ups_43 = A_43*C_3K; 
 % DZF1 
 c_1e{1,t} = A_1 * c_1a{1,t-1} + U_1 + A_12 * c_2a{1,t-1} + A_13 * c_3a{1,t-1};
 R_1e{1,t} = [A_1 * R_1a{1,t-1}, A_12 * R_2a{1,t-1}, A_13 * R_3a{1,t-1}, Gamma_1*Q_1];
 K_1(:,:,t)= (A_1*R_1a{1,t-1}*R_1a{1,t-1}'*A_1'+Gamma_1*Q_1*Q_1'*Gamma_1'+Ups_12*R_2{1,t-1}*R_2{1,t-1}'*Ups_12'+Ups_13*R_3{1,t-1}*R_3{1,t-1}'*Ups_13')*C_1'...
             *inv(R_1{1,t}*R_1{1,t}'+C_1*A_1*R_1a{1,t-1}*R_1a{1,t-1 }'*A_1'*C_1'+C_1*Gamma_1*Q_1*Q_1'*Gamma_1'*C_1'+C_1*Ups_12*R_2{1,t-1}*R_2{1,t-1}'*Ups_12'*C_1'+C_1*Ups_13*R_3{1,t-1}*R_3{1,t-1}'*Ups_13'*C_1');
 K_12(:,:,t)= (eye(1)-K_1(:,:,t)*C_1)*Ups_12;
 K_13(:,:,t)= (eye(1)-K_1(:,:,t)*C_1)*Ups_13;
 c_1a{1,t}  = (eye(1)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y_1(:,t)+K_12(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1})+K_13(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
 R_1a{1,t}  =[(eye(1)-K_1(:,:,t)*C_1)*A_1*R_1a{1,t-1},(eye(1)-K_1(:,:,t)*C_1)*Gamma_1*Q_1,-K_1(:,:,t)*R_1{1,t},-K_12(:,:,t)*R_2{1,t-1},-K_13(:,:,t)*R_3{1,t-1}];
 R_1a{1,t}=Reduction(R_1a{1,t},q);
 P_1a =sum(abs(R_1a{1,t}), 2);
 x_1a_up(:,t)=   c_1a{1,t}+P_1a;
 x_1a_down(:,t)= c_1a{1,t}-P_1a;
 J_1(:,t)=trace(R_1a{1,t}*R_1a{1,t}');      
 % DZF2 
 c_2e{1,t} = A_2 * c_2a{1,t-1} + U_2 + A_21 * c_1a{1,t-1} + A_24 * c_4a{1,t-1};
 R_2e{1,t} = [A_2*R_2a{1,t-1},A_21*R_1a{1,t-1},A_24*R_4a{1,t-1},Gamma_2*Q_2];
 K_2(:,:,t)= (A_2*R_2a{1,t-1}*R_2a{1,t-1}'*A_2'+Gamma_2 *Q_2*Q_2'*Gamma_2'+Ups_21*R_1{1,t-1}*R_1{1,t-1}'*Ups_21'+Ups_24*R_4{1,t-1}*R_4{1,t-1}'*Ups_24')*C_2'...
             *inv(R_2{1,t}*R_2{1,t}'+C_2*A_2*R_2a{1,t-1}*R_2a{1,t-1 }'*A_2'*C_2'+C_2*Gamma_2*Q_2*Q_2'*Gamma_2'*C_2'+C_2*Ups_21*R_1{1,t-1}*R_1{1,t-1}'*Ups_21'*C_2'+C_2*Ups_24*R_4{1,t-1}*R_4{1,t-1}'*Ups_24'*C_2');
 K_21(:,:,t)= (eye(1)-K_2(:,:,t)*C_2)*Ups_21;
 K_24(:,:,t)= (eye(1)-K_2(:,:,t)*C_2)*Ups_24;
 c_2a{1,t} = (eye(1)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y_2(:,t)+K_21(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1})+K_24(:,:,t)*(y_4(:,t-1)-C_4*c_4a{1,t-1});
 R_2a{1,t} = [(eye(1)-K_2(:,:,t)*C_2)*A_2*R_2a{1,t-1},(eye(1)-K_2(:,:,t)*C_2)*Gamma_2*Q_2,-K_2(:,:,t)*R_2{1,t},-K_21(:,:,t)*R_1{1,t-1},-K_24(:,:,t)*R_4{1,t-1}];
 R_2a{1,t}=Reduction(R_2a{1,t},q);
 P_2a =sum(abs(R_2a{1,t}), 2);
 x_2a_up(:,t)=   c_2a{1,t}+P_2a;
 x_2a_down(:,t)= c_2a{1,t}-P_2a;
 J_2(:,t)=trace(R_2a{1,t}*R_2a{1,t}');
 % DZF3 
 c_3e{1,t} = A_3 * c_3a{1,t-1} + U_3 + A_31 * c_1a{1,t-1} + A_34 * c_4a{1,t-1};
 R_3e{1,t}= [A_3*R_3a{1,t-1},A_31*R_1a{1,t-1},A_34*R_4a{1,t-1},Gamma_3*Q_3];
 K_3(:,:,t)= (A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'+Gamma_3*Q_3*Q_3'*Gamma_3'+Ups_31*R_1{1,t-1}*R_1{1,t-1}'*Ups_31'+Ups_34*R_4{1,t-1}*R_4{1,t-1}'*Ups_34')*C_3'...
            *inv(R_3{1,t}*R_3{1,t}'+C_3*A_3*R_3a{1,t-1}*R_3a{1,t-1 }'*A_3'*C_3'+C_3*Gamma_3*Q_3*Q_3'*Gamma_3'*C_3'+C_3*Ups_31*R_1{1,t-1}*R_1{1,t-1}'*Ups_31'*C_3'+C_3*Ups_34*R_4{1,t-1}*R_4{1,t-1}'*Ups_34'*C_3');
 K_31(:,:,t)= (eye(1)-K_3(:,:,t)*C_3)*Ups_31;
 K_34(:,:,t)= (eye(1)-K_3(:,:,t)*C_3)*Ups_34;
 c_3a{1,t} = (eye(1)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y_3(:,t)+K_31(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1})+K_34(:,:,t)*(y_4(:,t-1)-C_4*c_4a{1,t-1});
 R_3a{1,t}=[(eye(1)-K_3(:,:,t)*C_3)*A_3*R_3a{1,t-1},(eye(1)-K_3(:,:,t)*C_3)*Gamma_3*Q_3,-K_3(:,:,t)*R_3{1,t},-K_31(:,:,t)*R_1{1,t-1},-K_34(:,:,t)*R_4{1,t-1}];

 R_3a{1,t}=Reduction(R_3a{1,t},q);
 P_3a =sum(abs(R_3a{1,t}), 2);
 x_3a_up(:,t)=   c_3a{1,t}+P_3a;
 x_3a_down(:,t)= c_3a{1,t}-P_3a;
 J_3(:,t)=trace(R_3a{1,t}*R_3a{1,t}');
      
 % DZF4 
 c_4e{1,t} = A_4 * c_4a{1,t-1} + U_4 + A_42 * c_2a{1,t-1} + A_43 * c_3a{1,t-1};
 R_4e{1,t} = [A_4*R_4a{1,t-1}, A_42*R_2a{1,t-1}, A_43*R_3a{1,t-1}, Gamma_4*Q_4];
 K_4(:,:,t)= (A_4*R_4a{1,t-1}*R_4a{1,t-1}'*A_4'+Gamma_4*Q_4*Q_4'*Gamma_4'+Ups_42*R_2{1,t-1}*R_2{1,t-1}'*Ups_42'+Ups_43*R_3{1,t-1}*R_3{1,t-1}'*Ups_43')*C_4'...
             *inv(R_4{1,t}*R_4{1,t}'+C_4*A_4*R_4a{1,t-1}*R_4a{1,t-1 }'*A_4'*C_4'+C_4*Gamma_4*Q_4*Q_4'*Gamma_4'*C_4'+C_4*Ups_42*R_2{1,t-1}*R_2{1,t-1}'*Ups_42'*C_4'+C_4*Ups_43*R_3{1,t-1}*R_3{1,t-1}'*Ups_43'*C_4');
 K_42(:,:,t)= (eye(1)-K_4(:,:,t)*C_4)*Ups_42;
 K_43(:,:,t)= (eye(1)-K_4(:,:,t)*C_4)*Ups_43;
 c_4a{1,t} = (eye(1)-K_4(:,:,t)*C_4)*c_4e{1,t} + K_4(:,:,t)*y_4(:,t)+K_42(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1})+K_43(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
 R_4a{1,t}=[(eye(1)-K_4(:,:,t)*C_4)*A_4*R_4a{1,t-1},(eye(1)-K_4(:,:,t)*C_4)*Gamma_4*Q_4,-K_4(:,:,t)*R_4{1,t},-K_42(:,:,t)*R_2{1,t-1},-K_43(:,:,t)*R_3{1,t-1}];
 R_4a{1,t}=Reduction(R_4a{1,t},q);
 P_4a =sum(abs(R_4a{1,t}), 2);
 x_4a_up(:,t)=   c_4a{1,t}+P_4a;
 x_4a_down(:,t)= c_4a{1,t}-P_4a;
 J_4(:,t)=trace(R_4a{1,t}*R_4a{1,t}');         
end

%% 从Cell中提取每个矩阵的信息
x_1a = zeros(1, N); x_2a = zeros(1, N); x_3a = zeros(1, N); x_4a = zeros(1, N);
x_1b = zeros(1, N); x_2b = zeros(1, N); x_3b = zeros(1, N); x_4b = zeros(1, N);
for i=1:N 
    x_1a(:,i)=c_1a{1,i};
    x_2a(:,i)=c_2a{1,i};
    x_3a(:,i)=c_3a{1,i};
    x_4a(:,i)=c_4a{1,i};
end

%% 关于温度的绘图
% 假设 N 已经被定义，t = 1:N，以及所有信号变量都已存在。
% ====== 高级统一绘图风格设置 ======
lw = 2.0;                 % DZF线宽
lw_signal = 1.8;          % 信号线的新线宽 (略微增加，以凸显)
fs = 14;                  % 字体大小
t = 1:N;
cols = lines(4);          % 默认高级配色，用于信号线
% ----------------------------------------------------
% **淡蓝色阴影区域颜色设置**
fill_color = [0.678 0.847 0.902]; % 淡蓝色 (Light Sky Blue)，RGB值
fill_alpha = 0.6;                  % 透明度设置为 60%
% 调整图窗大小，使用较大的尺寸
figure('Color','w','Position',[100 100 1200 800]); 
% 准备填充区域的 X 坐标
X_fill = [t, fliplr(t)]; 
% ================= Subplot 1 : T1 ===================
subplot(2,2,1); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 (最底层) ---
Y_fill_1 = [x_1a_up(1,:), fliplr(x_1a_down(1,:))];
fill(X_fill, Y_fill_1, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
% DZF信号作为背景参考，使用虚线和标记，但不放在最上层
plot(t, x_1a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_1 (原始信号) (最上层，确保不被遮挡) ---
plot(t, x_1(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(a) Signal $T_1$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_1$','$T_1$'}, ...
    'FontSize',fs-2,'Location','best', 'Interpreter', 'latex'); % 注意图例顺序与绘制顺序一致
% ================= Subplot 2 : T2 ===================
subplot(2,2,2); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(1,:), fliplr(x_2a_down(1,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_2a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_2 (最上层) ---
plot(t, x_2(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(b) Signal $T_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_2$','$T_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 3 : T3 ===================
subplot(2,2,3); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_3 = [x_3a_up(1,:), fliplr(x_3a_down(1,:))];
fill(X_fill, Y_fill_3, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_3a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_3 (最上层) ---
plot(t, x_3(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(c) Signal $T_3$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_3$','$T_3$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 4 : T4 ===================
subplot(2,2,4); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_4 = [x_4a_up(1,:), fliplr(x_4a_down(1,:))];
fill(X_fill, Y_fill_4, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_4a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_4 (最上层) ---
plot(t, x_4(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(d) Signal $T_4$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_4$','$T_4$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');