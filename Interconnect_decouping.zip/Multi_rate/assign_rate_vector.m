% 3. 定义倍率赋值函数（避免重复代码，高效复用）
function vec_out = assign_rate_vector(position, vec_in, step, N)
    vec_out = vec_in;  % 先复制输入向量（避免直接修改输入）
    col_idx = position;  % 初始列索引（从position开始）
    while col_idx <= N
        vec_out(col_idx) = 1;  % 对应列赋值为1
        col_idx = col_idx + step;  % 加法更新（等步长）
    end
end