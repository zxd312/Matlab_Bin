%% 三个个序贯互联的小车   解耦和不解耦的性能比较
clc
clear
close all;
N=200;   % Time steps
q=10;    % Reduction parameter
%% System parameter
C_1=[1 0 0 0;0 0 1 0];C_2=eye(4);
C_3=[1 0 0 0;0 0 1 0];
A_21=diag([0,-0.009,0,-0.006]);
A_32=diag([0,-0.009,0,-0.01]);
for k = 1:N
    S_T = 0.3 + 0.2*sin(k);  % 计算当前t对应的采样周期
    % 构造A_i(t)
    A_i = [
        1,  S_T, 0,    0;
        0,  1,    0,    0;
        0,  0,    1,  S_T;
        0,  0,    0,    1
    ];
    % 构造Gamma_i(t)
    Gamma_i = [
        S_T^2 / 2;
        S_T;
        S_T^2 / 2;
        S_T
    ];
    % （可选）存储每个时刻的矩阵，例如存入单元格数组
    A{k} = A_i;
    Gamma{k} = Gamma_i;
end
%% 生成噪声
Q_1=0.9; Q_2=1; Q_3=0.8;
R_1=diag([1.2,0.9]); 
R_2=diag([0.6,1,0.5,1]); 
R_3=diag([0.7,1]); 
w_1= 1.8*rand(1,N)-0.9; 
w_2= 2*rand(1,N)-1;
w_3= 1.6*rand(1,N)-0.8; 
v_1= [2.4*rand(1,N)-1.2;1.8*rand(1,N)-0.9];
v_2= [1.2*rand(1,N)-0.6;2*rand(1,N)-1;1*rand(1,N)-0.5;2*rand(1,N)-1];
v_3= [1.4*rand(1,N)-0.7;2*rand(1,N)-1];
%% 初始状态
x_1(:, 1)=[0, 2, 0, 1]';
x_2(:, 1)=[0, 2, 0, 1]'; 
x_3(:, 1)=[0, 2, 0, 1]';
y_1(:,1)=C_1 * x_1(:, 1) + v_1(:, 1);
y_2(:,1)=C_2 * x_2(:, 1) + v_2(:, 1);
y_3(:,1)=C_3 * x_3(:, 1) + v_3(:, 1);
%% 初始协方差矩阵和状态  A的可以表示为解耦的，B的可以表示为序贯的即不解耦的
R_1a{1,1}=0.2*eye(4);  R_1b{1,1}=0.2*eye(4);
R_2a{1,1}=0.2*eye(4);  R_2b{1,1}=0.2*eye(4);
R_3a{1,1}=0.2*eye(4);  R_3b{1,1}=0.2*eye(4);
R_4a{1,1}=0.2*eye(4);  R_4b{1,1}=0.2*eye(4);
R_1e{1,1}=0.2*eye(4);  R_1f{1,1}=0.2*eye(4);
R_2e{1,1}=0.2*eye(4);  R_2f{1,1}=0.2*eye(4);
R_3e{1,1}=0.2*eye(4);  R_3f{1,1}=0.2*eye(4);
R_4e{1,1}=0.2*eye(4);  R_4f{1,1}=0.2*eye(4);
c_1a{1,1}=[-40, 1.2, -20, 1.0]'; c_2a{1,1}=[-38, 1.3, -18, 1.1]'; c_3a{1,1}=[-36, 1.1, -16, 0.9]'; 
c_1b{1,1}=[-40, 1.2, -20, 1.0]'; c_2b{1,1}=[-38, 1.3, -18, 1.1]'; c_3b{1,1}=[-36, 1.1, -16, 0.9]'; 
J_1(1,1)=trace(R_1a{1,1}*R_1a{1,1}');  J_1b(1,1)=trace(R_1b{1,1}*R_1b{1,1}'); 
J_2(1,1)=trace(R_2a{1,1}*R_2a{1,1}');  J_2b(1,1)=trace(R_2b{1,1}*R_2b{1,1}');
J_3(1,1)=trace(R_3a{1,1}*R_3a{1,1}');  J_3b(1,1)=trace(R_3b{1,1}*R_3b{1,1}');
x_1a_up(:,1)=c_1a{1,1}+0.2*ones(4,1);  x_1a_down(:,1)=c_1a{1,1}-0.2*ones(4,1);
x_2a_up(:,1)=c_2a{1,1}+0.2*ones(4,1);  x_2a_down(:,1)=c_2a{1,1}-0.2*ones(4,1);
x_3a_up(:,1)=c_3a{1,1}+0.2*ones(4,1);  x_3a_down(:,1)=c_3a{1,1}-0.2*ones(4,1);
x_1b_up(:,1)=c_1b{1,1}+0.2*ones(4,1);  x_1b_down(:,1)=c_1b{1,1}-0.2*ones(4,1);
x_2b_up(:,1)=c_2b{1,1}+0.2*ones(4,1);  x_2b_down(:,1)=c_2b{1,1}-0.2*ones(4,1);
x_3b_up(:,1)=c_3b{1,1}+0.2*ones(4,1);  x_3b_down(:,1)=c_3b{1,1}-0.2*ones(4,1);
%% 真实状态和观测状态的迭代
for t=2:N
 % 系统的真实状态
 x_1(:, t) = A{t-1} * x_1(:, t-1) + Gamma{t-1} * w_1(:, t-1);
 x_2(:, t) = A{t-1} * x_2(:, t-1) + A_21 * x_1(:, t-1) + Gamma{t-1} * w_2(:, t-1);
 x_3(:, t) = A{t-1} * x_3(:, t-1) + A_32 * x_1(:, t-1) + Gamma{t-1} * w_3(:, t-1);
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + v_1(:, t);
 y_2(:, t) = C_2 * x_2(:, t) + v_2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + v_3(:, t);  
end
%% 解耦增益阵 (假设C是不变的)
C_1K = C_1'*inv(C_1*C_1');
C_2K = inv(C_2'*C_2)*C_2';
C_3K = C_3'*inv(C_3*C_3');  
Ups_2 = A_21*C_1K; 
Ups_3 = A_32*C_2K; 
Phi_2 = A_21*(eye(4)-C_1K*C_1); 
%% Estimator Design with decoupling
for t=2:N 
 % DZF1 
 c_1e{1,t} = A{t-1} * c_1a{1,t-1};
 R_1e{1,t} = [A{t-1} * R_1a{1,t-1}, Gamma{t-1}*Q_1];
 K_1(:,:,t)= (A{t-1}*R_1a{1,t-1}*R_1a{1,t-1}'*A{t-1}'+Gamma{t-1}*Q_1*Q_1'*Gamma{t-1}')*C_1'...
             *inv(R_1*R_1'+C_1*A{t-1}*R_1a{1,t-1}*R_1a{1,t-1 }'*A{t-1}'*C_1'+C_1*Gamma{t-1}*Q_1*Q_1'*Gamma{t-1}'*C_1');
 c_1a{1,t}  = (eye(4)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y_1(:,t);
 R_1a{1,t}  =[(eye(4)-K_1(:,:,t)*C_1)*A{t-1}*R_1a{1,t-1},(eye(4)-K_1(:,:,t)*C_1)*Gamma{t-1}*Q_1,-K_1(:,:,t)*R_1];
 R_1a{1,t}=Reduction(R_1a{1,t},q);
 P_1a =sum(abs(R_1a{1,t}), 2);
 x_1a_up(:,t)=   c_1a{1,t}+P_1a;
 x_1a_down(:,t)= c_1a{1,t}-P_1a;
 J_1(:,t)=trace(R_1a{1,t}*R_1a{1,t}');      
 % DZF2 
 c_2e{1,t} = A{t-1} * c_2a{1,t-1} + A_21 * c_1a{1,t-1};
 R_2e{1,t} = [A{t-1}*R_2a{1,t-1},A_21*R_1a{1,t-1},Gamma{t-1}*Q_2];
 K_2(:,:,t)= (A{t-1}*R_2a{1,t-1}*R_2a{1,t-1}'*A{t-1}'+ Gamma{t-1}*Q_2*Q_2'*Gamma{t-1}'+ Ups_2*R_1*R_1'*Ups_2'+Phi_2*R_1a{1,t-1}*R_1a{1,t-1}'*Phi_2')*C_2'...
             *inv(R_2*R_2'+C_2*A{t-1}*R_2a{1,t-1}*R_2a{1,t-1 }'*A{t-1}'*C_2'+C_2*Gamma{t-1}*Q_2*Q_2'*Gamma{t-1}'*C_2'+C_2*Ups_2*R_1*R_1'*Ups_2'*C_2'+C_2*Phi_2*R_1a{1,t-1}*R_1a{1,t-1}'*Phi_2'*C_2');
 K_21(:,:,t)= (eye(4)-K_2(:,:,t)*C_2)*Ups_2;
 c_2a{1,t} = (eye(4)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y_2(:,t)+K_21(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1});
 R_2a{1,t} = [(eye(4)-K_2(:,:,t)*C_2)*A{t-1}*R_2a{1,t-1},(eye(4)-K_2(:,:,t)*C_2)*Gamma{t-1}*Q_2,-K_2(:,:,t)*R_2,-K_21(:,:,t)*R_1,(eye(4)-K_2(:,:,t)*C_2)*Phi_2*R_1a{1,t-1}];
 R_2a{1,t}=Reduction(R_2a{1,t},q);
 P_2a =sum(abs(R_2a{1,t}), 2);
 x_2a_up(:,t)=   c_2a{1,t}+P_2a;
 x_2a_down(:,t)= c_2a{1,t}-P_2a;
 J_2(:,t)=trace(R_2a{1,t}*R_2a{1,t}');
 % DZF3 
 c_3e{1,t} = A{t-1} * c_3a{1,t-1} + A_32 * c_2a{1,t-1};
 R_3e{1,t}= [A{t-1}*R_3a{1,t-1},A_32*R_2a{1,t-1},Gamma{t-1}*Q_3];
 K_3(:,:,t)= (A{t-1}*R_3a{1,t-1}*R_3a{1,t-1}'*A{t-1}'+Gamma{t-1}*Q_3*Q_3'*Gamma{t-1}'+Ups_3*R_2*R_2'*Ups_3')*C_3'...
             *inv(R_3*R_3'+C_3*A{t-1}*R_3a{1,t-1}*R_3a{1,t-1 }'*A{t-1}'*C_3'+C_3*Gamma{t-1}*Q_3*Q_3'*Gamma{t-1}'*C_3'+C_3*Ups_3*R_2*R_2'*Ups_3'*C_3');
 K_32(:,:,t)= (eye(4)-K_3(:,:,t)*C_3)*Ups_3;
 c_3a{1,t} = (eye(4)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y_3(:,t)+K_32(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1});
 R_3a{1,t}=[(eye(4)-K_3(:,:,t)*C_3)*A{t-1}*R_3a{1,t-1},(eye(4)-K_3(:,:,t)*C_3)*Gamma{t-1}*Q_3,-K_3(:,:,t)*R_3,-K_32(:,:,t)*R_2];
 R_3a{1,t}=Reduction(R_3a{1,t},q);
 P_3a =sum(abs(R_3a{1,t}), 2);
 x_3a_up(:,t)=   c_3a{1,t}+P_3a;
 x_3a_down(:,t)= c_3a{1,t}-P_3a;
 J_3(:,t)=trace(R_3a{1,t}*R_3a{1,t}');   
end

%% Estimator Design without decoupling
for t=2:N 
 % DZF1 
 c_1f{1,t} = A{t-1} * c_1b{1,t-1};
 R_1f{1,t} = [A{t-1} * R_1b{1,t-1}, Gamma{t-1}*Q_1];
 K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1'+R_1*R_1');
 c_1b{1,t} = (eye(4)-K_1b(:,:,t)*C_1)*c_1f{1,t} + K_1b(:,:,t)*y_1(:,t);
 R_1b{1,t} = [(eye(4)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*R_1];
 R_1b{1,t}=Reduction(R_1b{1,t},q);
 P_1b =sum(abs(R_1b{1,t}), 2);
 x_1b_up(:,t)=   c_1b{1,t}+P_1b;
 x_1b_down(:,t)= c_1b{1,t}-P_1b;
 J_1b(:,t)=trace(R_1b{1,t}*R_1b{1,t}');    
 % DZF2 
 c_2f{1,t} = A{t-1} * c_2b{1,t-1} + A_21 * c_1b{1,t-1};
 R_2f{1,t} = [A{t-1}*R_2b{1,t-1},A_21*R_1b{1,t-1},Gamma{t-1}*Q_2];
 K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2'+R_2*R_2');
 c_2b{1,t} = (eye(4)-K_2b(:,:,t)*C_2)*c_2f{1,t} + K_2b(:,:,t)*y_2(:,t);
 R_2b{1,t} = [(eye(4)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*R_2];
 R_2b{1,t}=Reduction(R_2b{1,t},q);
 P_2b =sum(abs(R_2b{1,t}), 2);
 x_2b_up(:,t)=   c_2b{1,t}+P_2b;
 x_2b_down(:,t)= c_2b{1,t}-P_2b;
 J_2b(:,t)=trace(R_2b{1,t}*R_2b{1,t}');
 % DZF3 
 c_3f{1,t} = A{t-1} * c_3b{1,t-1} + A_32 * c_2b{1,t-1};
 R_3f{1,t}= [A{t-1}*R_3b{1,t-1},A_32*R_2b{1,t-1},Gamma{t-1}*Q_3];
 K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3'+R_3*R_3');
 c_3b{1,t} = (eye(4)-K_3b(:,:,t)*C_3)*c_3f{1,t} + K_3b(:,:,t)*y_3(:,t);
 R_3b{1,t} = [(eye(4)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*R_3];
 R_3b{1,t}=Reduction(R_3b{1,t},q);
 P_3b =sum(abs(R_3b{1,t}), 2);
 x_3b_up(:,t)=   c_3b{1,t}+P_3b;
 x_3b_down(:,t)= c_3b{1,t}-P_3b;
 J_3b(:,t)=trace(R_3b{1,t}*R_3b{1,t}');
end


x_1a = zeros(4, N); x_2a = zeros(4, N); x_3a = zeros(4, N); 
x_1b = zeros(4, N); x_2b = zeros(4, N); x_3b = zeros(4, N); 
for i=1:N 
    x_1a(:,i)=c_1a{1,i};
    x_2a(:,i)=c_2a{1,i};
    x_3a(:,i)=c_3a{1,i};
    x_1b(:,i)=c_1b{1,i};
    x_2b(:,i)=c_2b{1,i};
    x_3b(:,i)=c_3b{1,i};
end



% 关于性能指标的比较
figure('Color', [1 1 1]); % 白色背景，简约高级
set(gcf, 'Units', 'normalized', 'Position', [0.1 0.1 0.8 0.4]); % 调整图窗大小，使其更宽
% 绘制子图 1: J_1/J_1b
subplot(3, 1, 1);
% DZF with decoupling: 蓝色线条，实线，加圆圈标记
plot(1:N, J_1(1,:), 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 橙色线条，虚线
plot(1:N, J_1b(1,:), 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.5, 'LineStyle', '--');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on; % 添加网格，增加专业感
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 2: J_2/J_2b
subplot(3, 1, 2);
% DZF with decoupling: 绿色线条，实线，加方块标记
plot(1:N, J_2(1,:), 'Color', [0.4660 0.6740 0.1880], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 紫色线条，点划线
plot(1:N, J_2b(1,:), 'Color', [0.4940 0.1840 0.5560], 'LineWidth', 1.5, 'LineStyle', '-.');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 3: J_3/J_3b
subplot(3, 1, 3);
% DZF with decoupling: 青色线条，实线
plot(1:N, J_3(1,:), 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 红色线条，双虚线
plot(1:N, J_3b(1,:), 'Color', [0.6350 0.0780 0.1840], 'LineWidth', 1.5, 'LineStyle', ':');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 3: J_3/J_3b
