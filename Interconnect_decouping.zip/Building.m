%% 四个互联的建筑物    解耦和不解耦的性能比较
clc
clear
close all;
N=500;   % Time steps
q=12;    % Reduction parameter
%% System parameter
s_p=600;  c_p=1.012;
u_1=0.25; u_2=0.3;
u_3=0.35; u_4=0.3;
R_12=120; R_21=120;
R_13=150; R_31=150;
R_24=100; R_42=100;
R_34=90;  R_43=90;
c_1=1600; c_2=1800;
c_3=1500; c_4=1900;
T_01=23.5; T_02=24;
T_03=23.5; T_04=24;
%% System modeling
A_1=1-(s_p*u_1*c_p/c_1)-(s_p/c_1)*(1/R_12 + 1/R_13);
A_12=s_p/(c_1*R_12); A_13=s_p/(c_1*R_13); Gamma_1=s_p/c_1;
A_2=1-(s_p*u_2*c_p/c_2)-(s_p/c_2)*(1/R_21 + 1/R_24);
A_21=s_p/(c_2*R_21); A_24=s_p/(c_2*R_24); Gamma_2=s_p/c_2;
A_3=1-(s_p*u_3*c_p/c_3)-(s_p/c_3)*(1/R_31 + 1/R_34);
A_31=s_p/(c_3*R_31); A_34=s_p/(c_3*R_34); Gamma_3=s_p/c_3;
A_4=1-(s_p*u_4*c_p/c_4)-(s_p/c_4)*(1/R_42 + 1/R_43);
A_42=s_p/(c_4*R_42); A_43=s_p/(c_4*R_43); Gamma_4=s_p/c_4;
C_1=[1;1]; C_2=[1;1]; C_3=[1;1]; C_4=[1;1];
U_1=s_p*u_1*c_p*T_01/c_1;
U_2=s_p*u_2*c_p*T_02/c_2;
U_3=s_p*u_3*c_p*T_03/c_3;
U_4=s_p*u_4*c_p*T_04/c_4;
%% noise
Q_1=0.2; Q_2=0.1; Q_3=0.3; Q_4=0.4;
w_1= 0.4*rand(1,N)-0.2; w_2= 0.2*rand(1,N)-0.1;
w_3= 0.6*rand(1,N)-0.3; w_4= 0.8*rand(1,N)-0.4;
R_1=diag([0.4,0.4]); R_2=diag([0.4,0.4]);
R_3=diag([0.4,0.4]); R_4=diag([0.4,0.4]);
v_1= 0.8*rand(2,N)-0.4; v_2= 0.8*rand(2,N)-0.4;
v_3= 0.8*rand(2,N)-0.4; v_4= 0.8*rand(2,N)-0.4;
%% 初始状态
x_1(:, 1)=25; x_2(:, 1)=25; x_3(:, 1)=25; x_4(:, 1)=25;
y_1(:,1)=C_1 * x_1(:, 1) + v_1(:, 1);
y_2(:,1)=C_2 * x_2(:, 1) + v_2(:, 1);
y_3(:,1)=C_3 * x_3(:, 1) + v_3(:, 1);
y_4(:,1)=C_4 * x_4(:, 1) + v_4(:, 1);
%% 初始协方差矩阵和状态  A的可以表示为解耦的，B的可以表示为序贯的即不解耦的
R_1a{1,1}=0.5;R_1b{1,1}=0.5;
R_2a{1,1}=0.5;R_2b{1,1}=0.5;
R_3a{1,1}=0.5;R_3b{1,1}=0.5;
R_4a{1,1}=0.5;R_4b{1,1}=0.5;
R_1e{1,1}=0.5;R_1f{1,1}=0.5;
R_2e{1,1}=0.5;R_2f{1,1}=0.5;
R_3e{1,1}=0.5;R_3f{1,1}=0.5;
R_4e{1,1}=0.5;R_4f{1,1}=0.5;
c_1a{1,1}=25; c_2a{1,1}=25; c_3a{1,1}=25; c_4a{1,1}=25; 
c_1b{1,1}=25; c_2b{1,1}=25; c_3b{1,1}=25; c_4b{1,1}=25; 
J_1(1,1)=trace(R_1a{1,1}*R_1a{1,1}');  J_1b(1,1)=trace(R_1b{1,1}*R_1b{1,1}'); 
J_2(1,1)=trace(R_2a{1,1}*R_2a{1,1}');  J_2b(1,1)=trace(R_2b{1,1}*R_2b{1,1}');
J_3(1,1)=trace(R_3a{1,1}*R_3a{1,1}');  J_3b(1,1)=trace(R_3b{1,1}*R_3b{1,1}');
J_4(1,1)=trace(R_4a{1,1}*R_4a{1,1}');  J_4b(1,1)=trace(R_4b{1,1}*R_4b{1,1}');
x_1a_up(:,1)=c_1a{1,1}+0.5*ones(1,1);  x_1a_down(:,1)=c_1a{1,1}-0.5*ones(1,1);
x_2a_up(:,1)=c_2a{1,1}+0.5*ones(1,1);  x_2a_down(:,1)=c_2a{1,1}-0.5*ones(1,1);
x_3a_up(:,1)=c_3a{1,1}+0.5*ones(1,1);  x_3a_down(:,1)=c_3a{1,1}-0.5*ones(1,1);
x_4a_up(:,1)=c_4a{1,1}+0.5*ones(1,1);  x_4a_down(:,1)=c_4a{1,1}-0.5*ones(1,1);
x_1b_up(:,1)=c_1b{1,1}+0.5*ones(1,1);  x_1b_down(:,1)=c_1b{1,1}-0.5*ones(1,1);
x_2b_up(:,1)=c_2b{1,1}+0.5*ones(1,1);  x_2b_down(:,1)=c_2b{1,1}-0.5*ones(1,1);
x_3b_up(:,1)=c_3b{1,1}+0.5*ones(1,1);  x_3b_down(:,1)=c_3b{1,1}-0.5*ones(1,1);
x_4b_up(:,1)=c_4b{1,1}+0.5*ones(1,1);  x_4b_down(:,1)=c_4b{1,1}-0.5*ones(1,1);
%% 真实状态和观测状态的迭代
for t=2:N
 % 系统的真实状态
 x_1(:, t) = A_1 * x_1(:, t-1) + U_1 + A_12 * x_2(:, t-1) + A_13 * x_3(:, t-1) + Gamma_1 * w_1(:, t);
 x_2(:, t) = A_2 * x_2(:, t-1) + U_2 + A_21 * x_1(:, t-1) + A_24 * x_4(:, t-1) + Gamma_2 * w_2(:, t);
 x_3(:, t) = A_3 * x_3(:, t-1) + U_3 + A_31 * x_1(:, t-1) + A_34 * x_4(:, t-1) + Gamma_3 * w_3(:, t);
 x_4(:, t) = A_4 * x_4(:, t-1) + U_4 + A_42 * x_2(:, t-1) + A_43 * x_3(:, t-1) + Gamma_4 * w_4(:, t) ;
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + v_1(:, t);
 y_2(:, t) = C_2 * x_2(:, t) + v_2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + v_3(:, t);  
 y_4(:, t) = C_4 * x_4(:, t) + v_4(:, t); 
end

%% 解耦增益阵 (假设C是不变的)
C_1K = inv(C_1'*C_1)*C_1';
C_2K = inv(C_2'*C_2)*C_2';
C_3K = inv(C_3'*C_3)*C_3';
C_4K = inv(C_4'*C_4)*C_4';
Ups_12 = A_12*C_2K;   
Ups_13 = A_13*C_3K;  
Ups_21 = A_21*C_1K; 
Ups_24 = A_24*C_4K;
Ups_31 = A_31*C_1K; 
Ups_34 = A_34*C_4K;
Ups_42 = A_42*C_2K; 
Ups_43 = A_43*C_3K; 
%% Estimator Design with decoupling
for t=2:N
 % DZF1 
 c_1e{1,t} = A_1 * c_1a{1,t-1} + U_1 + A_12 * c_2a{1,t-1} + A_13 * c_3a{1,t-1};
 R_1e{1,t} = [A_1 * R_1a{1,t-1}, A_12 * R_2a{1,t-1}, A_13 * R_3a{1,t-1}, Gamma_1*Q_1];
 K_1(:,:,t)= (A_1*R_1a{1,t-1}*R_1a{1,t-1}'*A_1'+Gamma_1*Q_1*Q_1'*Gamma_1'+Ups_12*R_2*R_2'*Ups_12'+Ups_13*R_3*R_3'*Ups_13')*C_1'...
             *inv(R_1*R_1'+C_1*A_1*R_1a{1,t-1}*R_1a{1,t-1 }'*A_1'*C_1'+C_1*Gamma_1*Q_1*Q_1'*Gamma_1'*C_1'+C_1*Ups_12*R_2*R_2'*Ups_12'*C_1'+C_1*Ups_13*R_3*R_3'*Ups_13'*C_1');
 K_12(:,:,t)= (eye(1)-K_1(:,:,t)*C_1)*Ups_12;
 K_13(:,:,t)= (eye(1)-K_1(:,:,t)*C_1)*Ups_13;
 c_1a{1,t}  = (eye(1)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y_1(:,t)+K_12(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1})+K_13(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
 R_1a{1,t}  =[(eye(1)-K_1(:,:,t)*C_1)*A_1*R_1a{1,t-1},(eye(1)-K_1(:,:,t)*C_1)*Gamma_1*Q_1,-K_1(:,:,t)*R_1,-K_12(:,:,t)*R_2,-K_13(:,:,t)*R_3];
 R_1a{1,t}=Reduction(R_1a{1,t},q);
 P_1a =sum(abs(R_1a{1,t}), 2);
 x_1a_up(:,t)=   c_1a{1,t}+P_1a;
 x_1a_down(:,t)= c_1a{1,t}-P_1a;
 J_1(:,t)=trace(R_1a{1,t}*R_1a{1,t}');      
 % DZF2 
 c_2e{1,t} = A_2 * c_2a{1,t-1} + U_2 + A_21 * c_1a{1,t-1} + A_24 * c_4a{1,t-1};
 R_2e{1,t} = [A_2*R_2a{1,t-1},A_21*R_1a{1,t-1},A_24*R_4a{1,t-1},Gamma_2*Q_2];
 K_2(:,:,t)= (A_2*R_2a{1,t-1}*R_2a{1,t-1}'*A_2'+Gamma_2 *Q_2*Q_2'*Gamma_2'+Ups_21*R_1*R_1'*Ups_21'+Ups_24*R_4*R_4'*Ups_24')*C_2'...
             *inv(R_2*R_2'+C_2*A_2*R_2a{1,t-1}*R_2a{1,t-1 }'*A_2'*C_2'+C_2*Gamma_2*Q_2*Q_2'*Gamma_2'*C_2'+C_2*Ups_21*R_1*R_1'*Ups_21'*C_2'+C_2*Ups_24*R_4*R_4'*Ups_24'*C_2');
 K_21(:,:,t)= (eye(1)-K_2(:,:,t)*C_2)*Ups_21;
 K_24(:,:,t)= (eye(1)-K_2(:,:,t)*C_2)*Ups_24;
 c_2a{1,t} = (eye(1)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y_2(:,t)+K_21(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1})+K_24(:,:,t)*(y_4(:,t-1)-C_4*c_4a{1,t-1});
 R_2a{1,t} = [(eye(1)-K_2(:,:,t)*C_2)*A_2*R_2a{1,t-1},(eye(1)-K_2(:,:,t)*C_2)*Gamma_2*Q_2,-K_2(:,:,t)*R_2,-K_21(:,:,t)*R_1,-K_24(:,:,t)*R_4];
 R_2a{1,t}=Reduction(R_2a{1,t},q);
 P_2a =sum(abs(R_2a{1,t}), 2);
 x_2a_up(:,t)=   c_2a{1,t}+P_2a;
 x_2a_down(:,t)= c_2a{1,t}-P_2a;
 J_2(:,t)=trace(R_2a{1,t}*R_2a{1,t}');
 % DZF3 
 c_3e{1,t} = A_3 * c_3a{1,t-1} + U_3 + A_31 * c_1a{1,t-1} + A_34 * c_4a{1,t-1};
 R_3e{1,t}= [A_3*R_3a{1,t-1},A_31*R_1a{1,t-1},A_34*R_4a{1,t-1},Gamma_3*Q_3];
 K_3(:,:,t)= (A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'+Gamma_3*Q_3*Q_3'*Gamma_3'+Ups_31*R_1*R_1'*Ups_31'+Ups_34*R_4*R_4'*Ups_34')*C_3'...
            *inv(R_3*R_3'+C_3*A_3*R_3a{1,t-1}*R_3a{1,t-1 }'*A_3'*C_3'+C_3*Gamma_3*Q_3*Q_3'*Gamma_3'*C_3'+C_3*Ups_31*R_1*R_1'*Ups_31'*C_3'+C_3*Ups_34*R_4*R_4'*Ups_34'*C_3');
 K_31(:,:,t)= (eye(1)-K_3(:,:,t)*C_3)*Ups_31;
 K_34(:,:,t)= (eye(1)-K_3(:,:,t)*C_3)*Ups_34;
 c_3a{1,t} = (eye(1)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y_3(:,t)+K_31(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1})+K_34(:,:,t)*(y_4(:,t-1)-C_4*c_4a{1,t-1});
 R_3a{1,t}=[(eye(1)-K_3(:,:,t)*C_3)*A_3*R_3a{1,t-1},(eye(1)-K_3(:,:,t)*C_3)*Gamma_3*Q_3,-K_3(:,:,t)*R_3,-K_31(:,:,t)*R_1,-K_34(:,:,t)*R_4];

 R_3a{1,t}=Reduction(R_3a{1,t},q);
 P_3a =sum(abs(R_3a{1,t}), 2);
 x_3a_up(:,t)=   c_3a{1,t}+P_3a;
 x_3a_down(:,t)= c_3a{1,t}-P_3a;
 J_3(:,t)=trace(R_3a{1,t}*R_3a{1,t}');
      
 % DZF4 
 c_4e{1,t} = A_4 * c_4a{1,t-1} + U_4 + A_42 * c_2a{1,t-1} + A_43 * c_3a{1,t-1};
 R_4e{1,t} = [A_4*R_4a{1,t-1}, A_42*R_2a{1,t-1}, A_43*R_3a{1,t-1}, Gamma_4*Q_4];
 K_4(:,:,t)= (A_4*R_4a{1,t-1}*R_4a{1,t-1}'*A_4'+Gamma_4*Q_4*Q_4'*Gamma_4'+Ups_42*R_2*R_2'*Ups_42'+Ups_43*R_3*R_3'*Ups_43')*C_4'...
             *inv(R_4*R_4'+C_4*A_4*R_4a{1,t-1}*R_4a{1,t-1 }'*A_4'*C_4'+C_4*Gamma_4*Q_4*Q_4'*Gamma_4'*C_4'+C_4*Ups_42*R_2*R_2'*Ups_42'*C_4'+C_4*Ups_43*R_3*R_3'*Ups_43'*C_4');
 K_42(:,:,t)= (eye(1)-K_4(:,:,t)*C_4)*Ups_42;
 K_43(:,:,t)= (eye(1)-K_4(:,:,t)*C_4)*Ups_43;
 c_4a{1,t} = (eye(1)-K_4(:,:,t)*C_4)*c_4e{1,t} + K_4(:,:,t)*y_4(:,t)+K_42(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1})+K_43(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
 R_4a{1,t}=[(eye(1)-K_4(:,:,t)*C_4)*A_4*R_4a{1,t-1},(eye(1)-K_4(:,:,t)*C_4)*Gamma_4*Q_4,-K_4(:,:,t)*R_4,-K_42(:,:,t)*R_2,-K_43(:,:,t)*R_3];
 R_4a{1,t}=Reduction(R_4a{1,t},q);
 P_4a =sum(abs(R_4a{1,t}), 2);
 x_4a_up(:,t)=   c_4a{1,t}+P_4a;
 x_4a_down(:,t)= c_4a{1,t}-P_4a;
 J_4(:,t)=trace(R_4a{1,t}*R_4a{1,t}');         
end

%% 估计器设计 不带解耦的
for t=2:N
%% DZF1
c_1f{1,t} = A_1 * c_1b{1,t-1} + U_1 + A_12 * c_2b{1,t-1} + A_13 * c_3b{1,t-1};
R_1f{1,t}= [A_1*R_1b{1,t-1},A_12*R_2b{1,t-1},A_13*R_3b{1,t-1},Gamma_1*Q_1];
K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1'+R_1*R_1');
c_1b{1,t} = (eye(1)-K_1b(:,:,t)*C_1)*c_1f{1,t} + K_1b(:,:,t)*y_1(:,t);
R_1b{1,t} = [(eye(1)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*R_1];
R_1b{1,t}=Reduction(R_1b{1,t},q);
P_1b =sum(abs(R_1b{1,t}), 2);
x_1b_up(:,t)=   c_1b{1,t}+P_1b;
x_1b_down(:,t)= c_1b{1,t}-P_1b;
J_1b(:,t)=trace(R_1b{1,t}*R_1b{1,t}');
%% DZF2
c_2f{1,t} = A_2 * c_2b{1,t-1} + U_2 + A_21 * c_1b{1,t-1} + A_24*c_4b{1,t-1};
R_2f{1,t}= [A_2*R_2b{1,t-1},A_21*R_1b{1,t-1},A_24*R_4b{1,t-1},Gamma_2*Q_2];
K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2'+R_2*R_2');
c_2b{1,t} = (eye(1)-K_2b(:,:,t)*C_2)*c_2f{1,t} + K_2b(:,:,t)*y_2(:,t);
R_2b{1,t} = [(eye(1)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*R_2];
R_2b{1,t}=Reduction(R_2b{1,t},q);
P_2b =sum(abs(R_2b{1,t}), 2);
x_2b_up(:,t)=   c_2b{1,t}+P_2b;
x_2b_down(:,t)= c_2b{1,t}-P_2b;
J_2b(:,t)=trace(R_2b{1,t}*R_2b{1,t}');
%% DZF3
c_3f{1,t} = A_3 * c_3b{1,t-1} + U_3 + A_31 * c_1b{1,t-1} + A_34 * c_4b{1,t-1};
R_3f{1,t}= [A_3*R_3b{1,t-1},A_31*R_2b{1,t-1},A_34*R_4b{1,t-1},Gamma_3*Q_3];
K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3'+R_3*R_3');
c_3b{1,t} = (eye(1)-K_3b(:,:,t)*C_3)*c_3f{1,t} + K_3b(:,:,t)*y_3(:,t);
R_3b{1,t} = [(eye(1)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*R_3];
R_3b{1,t}=Reduction(R_3b{1,t},q);
P_3b =sum(abs(R_3b{1,t}), 2);
x_3b_up(:,t)=   c_3b{1,t}+P_3b;
x_3b_down(:,t)= c_3b{1,t}-P_3b;
J_3b(:,t)=trace(R_3b{1,t}*R_3b{1,t}');
%% DZF4
c_4e{1,t} = A_4 * c_4a{1,t-1} + U_4 + A_42 * c_2a{1,t-1} + A_43 * c_3a{1,t-1};
c_4f{1,t} = A_4 * c_4b{1,t-1} + U_4 + A_42 * c_2b{1,t-1} + A_43 * c_3b{1,t-1};
R_4f{1,t}= [A_4*R_4b{1,t-1},A_42*R_2b{1,t-1},A_43*R_3b{1,t-1},Gamma_4*Q_4];
K_4b(:,:,t)=R_4f{1,t}*R_4f{1,t}'*C_4'*inv(C_4*R_4f{1,t}*R_4f{1,t}'*C_4'+R_4*R_4');
c_4b{1,t} = (eye(1)-K_4b(:,:,t)*C_4)*c_4f{1,t} + K_4b(:,:,t)*y_4(:,t);
R_4b{1,t} = [(eye(1)-K_4b(:,:,t)*C_4)*R_4f{1,t},-K_4b(:,:,t)*R_4];
R_4b{1,t}=Reduction(R_4b{1,t},q);
P_4b =sum(abs(R_4b{1,t}), 2);
x_4b_up(:,t)=   c_4b{1,t}+P_4b;
x_4b_down(:,t)= c_4b{1,t}-P_4b;
J_4b(:,t)=trace(R_4b{1,t}*R_4b{1,t}');
end


%% 从Cell中提取每个矩阵的信息
x_1a = zeros(1, N); x_2a = zeros(1, N); x_3a = zeros(1, N); x_4a = zeros(1, N);
x_1b = zeros(1, N); x_2b = zeros(1, N); x_3b = zeros(1, N); x_4b = zeros(1, N);
for i=1:N 
    x_1a(:,i)=c_1a{1,i};
    x_2a(:,i)=c_2a{1,i};
    x_3a(:,i)=c_3a{1,i};
    x_4a(:,i)=c_4a{1,i};
    x_1b(:,i)=c_1b{1,i};
    x_2b(:,i)=c_2b{1,i};
    x_3b(:,i)=c_3b{1,i};
    x_4b(:,i)=c_4b{1,i};
end

%%
% 关于性能指标的比较
figure('Color', [1 1 1]); % 白色背景，简约高级
set(gcf, 'Units', 'normalized', 'Position', [0.1 0.1 0.8 0.4]); % 调整图窗大小，使其更宽
% 绘制子图 1: J_1/J_1b
subplot(2, 2, 1);
% DZF with decoupling: 蓝色线条，实线，加圆圈标记
plot(1:N, J_1(1,:), 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 橙色线条，虚线
plot(1:N, J_1b(1,:), 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.5, 'LineStyle', '--');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on; % 添加网格，增加专业感
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 2: J_2/J_2b
subplot(2, 2, 2);
% DZF with decoupling: 绿色线条，实线，加方块标记
plot(1:N, J_2(1,:), 'Color', [0.4660 0.6740 0.1880], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 紫色线条，点划线
plot(1:N, J_2b(1,:), 'Color', [0.4940 0.1840 0.5560], 'LineWidth', 1.5, 'LineStyle', '-.');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 3: J_3/J_3b
subplot(2, 2, 3);
% DZF with decoupling: 青色线条，实线
plot(1:N, J_3(1,:), 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 红色线条，双虚线
plot(1:N, J_3b(1,:), 'Color', [0.6350 0.0780 0.1840], 'LineWidth', 1.5, 'LineStyle', ':');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 3: J_3/J_3b
subplot(2, 2, 4);
% DZF with decoupling: 青色线条，实线
plot(1:N, J_4(1,:), 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 红色线条，双虚线
plot(1:N, J_4b(1,:), 'Color', [0.6350 0.0780 0.1840], 'LineWidth', 1.5, 'LineStyle', ':');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% ----------------------------------------------------
% 增加一个总标题（可选）
sgtitle('DZF Performance Comparison Over Time', 'FontSize', 14, 'FontWeight', 'bold', 'FontName', 'Arial');

%% 关于温度的绘图
% 假设 N 已经被定义，t = 1:N，以及所有信号变量都已存在。
% ====== 高级统一绘图风格设置 ======
lw = 2.0;                 % DZF线宽
lw_signal = 1.8;          % 信号线的新线宽 (略微增加，以凸显)
fs = 14;                  % 字体大小
t = 1:N;
cols = lines(4);          % 默认高级配色，用于信号线
% ----------------------------------------------------
% **淡蓝色阴影区域颜色设置**
fill_color = [0.678 0.847 0.902]; % 淡蓝色 (Light Sky Blue)，RGB值
fill_alpha = 0.6;                  % 透明度设置为 60%
% 调整图窗大小，使用较大的尺寸
figure('Color','w','Position',[100 100 1200 800]); 
% 准备填充区域的 X 坐标
X_fill = [t, fliplr(t)]; 
% ================= Subplot 1 : T1 ===================
subplot(2,2,1); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 (最底层) ---
Y_fill_1 = [x_1a_up(1,:), fliplr(x_1a_down(1,:))];
fill(X_fill, Y_fill_1, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
% DZF信号作为背景参考，使用虚线和标记，但不放在最上层
plot(t, x_1a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_1 (原始信号) (最上层，确保不被遮挡) ---
plot(t, x_1(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(a) Signal $T_1$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_1$','$T_1$'}, ...
    'FontSize',fs-2,'Location','best', 'Interpreter', 'latex'); % 注意图例顺序与绘制顺序一致
% ================= Subplot 2 : T2 ===================
subplot(2,2,2); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(1,:), fliplr(x_2a_down(1,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_2a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_2 (最上层) ---
plot(t, x_2(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(b) Signal $T_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_2$','$T_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 3 : T3 ===================
subplot(2,2,3); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_3 = [x_3a_up(1,:), fliplr(x_3a_down(1,:))];
fill(X_fill, Y_fill_3, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_3a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_3 (最上层) ---
plot(t, x_3(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(c) Signal $T_3$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_3$','$T_3$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 4 : T4 ===================
subplot(2,2,4); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_4 = [x_4a_up(1,:), fliplr(x_4a_down(1,:))];
fill(X_fill, Y_fill_4, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制估计/DZF信号 ---
plot(t, x_4a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'LineWidth', lw);
% --- 3. 绘制信号 T_4 (最上层) ---
plot(t, x_4(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', lw_signal); 
xlabel('Time (t)','FontSize',fs);
ylabel('Temperature','FontSize',fs);
title('(d) Signal $T_4$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bounds','DZF of $T_4$','$T_4$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');