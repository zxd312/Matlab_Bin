%% 四弹簧阻尼小车系统在解耦下的胞性估计方法   解耦和不解耦的性能比较
clc
clear
close all;
N=50;   % Time steps
numbers=4; 
d=1;    %init position
v=0.1;  %init velocity
q=16;    %Reduction
%% Overall System
k=2;
c=2;
Ts=0.05;
% car quality
for i = 1:numbers
   m(i) = 10 + 5 * rand;
end
% 定义 A 矩阵
A = [0, 1, 0, 0, 0, 0, 0, 0;
    -k/m(1), -c/m(1), k/m(1), c/m(1), 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0;
    k/m(2), c/m(2), -2*k/m(2), -2*c/m(2), k/m(2), c/m(2), 0, 0;             
    0, 0, 0, 0, 0, 1, 0, 0;
    0, 0, k/m(3), c/m(3), -2*k/m(3), -2*c/m(3), k/m(3), c/m(3);
    0, 0, 0, 0, 0, 0, 0, 1;
    0, 0, 0, 0, k/m(4), c/m(4), -2*k/m(4), -2*c/m(4)];
%% block discretization
%  block
A_1d=A(1:2,1:2);A_12d=A(1:2,3:4);
A_2d=A(3:4,3:4);A_21d=A(3:4,1:2);A_23d=A(3:4,5:6);
A_3d=A(5:6,5:6);A_32d=A(5:6,3:4);A_34d=A(5:6,7:8);
A_4d=A(7:8,7:8);A_43d=A(7:8,5:6);
U_11=[0;1/m(1)];U_22=[0;1/m(2)];
U_33=[0;1/m(3)];U_44=[0;1/m(4)];
% discretization
A_1 = expm(A_1d*Ts);
fun_12 = @(t) expm(A_1d*t) * A_12d;
A_12 = integral(fun_12, 0, Ts, 'ArrayValued', true);
A_2 = expm(A_2d * Ts);
fun_21 = @(t) expm(A_2d*t) * A_21d;
A_21 = integral(fun_21, 0, Ts, 'ArrayValued', true);
fun_23 = @(t) expm(A_2d*t) * A_23d;
A_23 = integral(fun_23, 0, Ts, 'ArrayValued', true);
A_3 = expm(A_3d * Ts);
fun_32 = @(t) expm(A_3d * t) * A_32d;
A_32 = integral(fun_32, 0, Ts, 'ArrayValued', true);
fun_34 = @(t) expm(A_3d * t) * A_34d;
A_34 = integral(fun_34, 0, Ts, 'ArrayValued', true);
A_4 = expm(A_4d * Ts);
fun_43 = @(t) expm(A_4d * t) * A_43d;
A_43 = integral(fun_43, 0, Ts, 'ArrayValued', true);
%% 系统矩阵
C_1=eye(2);C_3=eye(2);C_4=eye(2); C_2=eye(2);
% C_2=[0,1];
%% 噪声的生成
w_1= 0.5*rand(2,N)-0.25;
w_2= 0.5*rand(2,N)-0.25;
w_3= 0.5*rand(2,N)-0.25;
w_4= 0.5*rand(2,N)-0.25;
%% 噪声协方差矩阵调整
Q_1 = diag([0.25, 0.25]); % 过程噪声的协方差矩阵
Q_2 = diag([0.25, 0.25]);
Q_3 = diag([0.25, 0.25]);
Q_4 = diag([0.25, 0.25]);
R_1 = diag([0.15, 0.15]);
R_2 = diag([0.15, 0.15]);
% R_2 = 0.1;
R_3 = diag([0.15, 0.15]);
R_4 = diag([0.15, 0.15]);
v_1= 0.3*rand(2,N)-0.15;
v_2= 0.3*rand(2,N)-0.15;
% v_2= 0.2*rand(1,N)-0.1;
v_3= 0.3*rand(2,N)-0.15;
v_4= 0.3*rand(2,N)-0.15;
%% 初始状态
x_1(:, 1)=[0; v]; x_2(:, 1)=[d; v]; x_3(:, 1)=[2*d; v]; x_4(:, 1)=[3*d; v];
y_1(:,1)=C_1 * x_1(:, 1) + v_1(:, 1);
y_2(:,1)=C_2 * x_2(:, 1) + v_2(:, 1);
y_3(:,1)=C_3 * x_3(:, 1) + v_3(:, 1);
y_4(:,1)=C_4 * x_4(:, 1) + v_4(:, 1);
%% 初始协方差矩阵和状态 A的可以表示为解耦的，B的可以表示为序贯的即不解耦的
R_1a{1,1}=diag([0.01, 0.01]);R_1b{1,1}=diag([0.01, 0.01]);
R_2a{1,1}=diag([0.01, 0.01]);R_2b{1,1}=diag([0.01, 0.01]);
R_3a{1,1}=diag([0.01, 0.01]);R_3b{1,1}=diag([0.01, 0.01]);
R_4a{1,1}=diag([0.01, 0.01]);R_4b{1,1}=diag([0.01, 0.01]);
R_1e{1,1}=diag([0.01, 0.01]);R_1f{1,1}=diag([0.01, 0.01]);
R_2e{1,1}=diag([0.01, 0.01]);R_2f{1,1}=diag([0.01, 0.01]);
R_3e{1,1}=diag([0.01, 0.01]);R_3f{1,1}=diag([0.01, 0.01]);
R_4e{1,1}=diag([0.01, 0.01]);R_4f{1,1}=diag([0.01, 0.01]);
c_1a{1,1}=[0; v]; c_2a{1,1}=[d; v]; c_3a{1,1}=[2*d; v]; c_4a{1,1}=[3*d; v]; 
c_1b{1,1}=[0; v]; c_2b{1,1}=[d; v]; c_3b{1,1}=[2*d; v]; c_4b{1,1}=[3*d; v]; 
J_1(1,1)=trace(R_1a{1,1}*R_1a{1,1}');  J_1b(1,1)=trace(R_1b{1,1}*R_1b{1,1}'); 
J_2(1,1)=trace(R_2a{1,1}*R_2a{1,1}');  J_2b(1,1)=trace(R_2b{1,1}*R_2b{1,1}');
J_3(1,1)=trace(R_3a{1,1}*R_3a{1,1}');  J_3b(1,1)=trace(R_3b{1,1}*R_3b{1,1}');
J_4(1,1)=trace(R_4a{1,1}*R_4a{1,1}');  J_4b(1,1)=trace(R_4b{1,1}*R_4b{1,1}');
x_1a_up(:,1)=c_1a{1,1}+0.01*ones(2,1);  x_1a_down(:,1)=c_1a{1,1}-0.01*ones(2,1);
x_2a_up(:,1)=c_2a{1,1}+0.01*ones(2,1);  x_2a_down(:,1)=c_2a{1,1}-0.01*ones(2,1);
x_3a_up(:,1)=c_3a{1,1}+0.01*ones(2,1);  x_3a_down(:,1)=c_3a{1,1}-0.01*ones(2,1);
x_4a_up(:,1)=c_4a{1,1}+0.01*ones(2,1);  x_4a_down(:,1)=c_4a{1,1}-0.01*ones(2,1);
%% 迭代循环
for t=2:N
 F1(:,t)=5 * rand;  F2(:,t)=5 * rand;
 F3(:,t)=5 * rand;  F4(:,t)=5 * rand;
 u_1(:,t)=F1(:,t)*U_11; u_2(:,t)=F2(:,t)*U_22; u_3(:,t)=F3(:,t)*U_33; u_4(:,t)=F4(:,t)*U_44;
 % 系统的真实状态
 x_1(:, t) = A_1 * x_1(:, t-1) + u_1(:,t) + w_1(:, t) + A_12 * x_2(:, t-1) ;
 x_2(:, t) = A_2 * x_2(:, t-1) + u_2(:,t) + w_2(:, t) + A_21 * x_1(:, t-1) + A_23 * x_3(:, t-1);
 x_3(:, t) = A_3 * x_3(:, t-1) + u_3(:,t) + w_3(:, t) + A_32 * x_2(:, t-1) + A_34 * x_4(:, t-1) ;
 x_4(:, t) = A_4 * x_4(:, t-1) + u_4(:,t) + w_4(:, t) + A_43 * x_3(:, t-1)  ;
 % 观测更新
 y_1(:, t) = C_1 * x_1(:, t) + v_1(:, t);
 y_2(:, t) = C_2 * x_2(:, t) + v_2(:, t);
 y_3(:, t) = C_3 * x_3(:, t) + v_3(:, t);  
 y_4(:, t) = C_4 * x_4(:, t) + v_4(:, t); 
end
%% 解耦增益阵 (假设C是不变的)
C_1K = pinv(C_1'*C_1)*C_1';
C_2K = C_2'*pinv(C_2*C_2');
C_3K = pinv(C_3'*C_3)*C_3';
C_4K = pinv(C_4'*C_4)*C_4';
Ups_1  = A_12*C_2K;             
Ups_21 = A_21*C_1K; 
Ups_23 = A_23*C_3K;
Ups_32 = A_32*C_2K; 
Ups_34 = A_34*C_4K;
Ups_4  = A_43*C_3K; 
Phi_1 =  A_12*(eye(2)-C_2K*C_2); 
Phi_3 =  A_32*(eye(2)-C_2K*C_2); 
%% 估计器设计 带解耦的
for t=2:N
%% DZF1
c_1e{1,t} = A_1*c_1a{1,t-1}+u_1(:,t)+A_12*c_2a{1,t-1};
R_1e{1,t}= [A_1*R_1a{1,t-1},A_12*R_2a{1,t-1},Q_1];
K_1(:,:,t)= (A_1*R_1a{1,t-1}*R_1a{1,t-1}'*A_1'+Q_1*Q_1'+Ups_1*R_2*R_2'*Ups_1')*C_1'...
            *pinv(R_1*R_1'+C_1*A_1*R_1a{1,t-1}*R_1a{1,t-1 }'*A_1'*C_1'+C_1*Q_1*Q_1'*C_1'+C_1*Ups_1*R_2*R_2'*Ups_1'*C_1');
% 当y2只检测一维向量的时候，另外当y2只检测到一维向量的时候，可能不满足可观性，使其效果特别差，所以使用全单位阵和序贯的进行比较
% K_1(:,:,t)= (A_1*R_1a{1,t-1}*R_1a{1,t-1}'*A_1'+Q_1*Q_1'+Ups_1*R_2*R_2'*Ups_1'+Phi_1*R_2a{1,t-1}*R_2a{1,t-1}'*Phi_1')*C_1'...
%             *pinv(R_1*R_1'+C_1*A_1*R_1a{1,t-1}*R_1a{1,t-1 }'*A_1'*C_1'+C_1*Q_1*Q_1'*C_1'+C_1*Ups_1*R_2*R_2'*Ups_1'*C_1'+C_1*Phi_1*R_2a{1,t-1}*R_2a{1,t-1}'*Phi_1'*C_1');
K_12(:,:,t)= (eye(2)-K_1(:,:,t)*C_1)*Ups_1;
c_1a{1,t} = (eye(2)-K_1(:,:,t)*C_1)*c_1e{1,t} + K_1(:,:,t)*y_1(:,t)+K_12(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1});
R_1a{1,t}=[(eye(2)-K_1(:,:,t)*C_1)*A_1*R_1a{1,t-1},(eye(2)-K_1(:,:,t)*C_1)*Q_1,...
          -K_1(:,:,t)*R_1,-K_12(:,:,t)*R_2];

R_1a{1,t}=Reduction(R_1a{1,t},q);
P_1a =sum(abs(R_1a{1,t}), 2);
x_1a_up(:,t)=   c_1a{1,t}+P_1a;
x_1a_down(:,t)= c_1a{1,t}-P_1a;
J_1(:,t)=trace(R_1a{1,t}*R_1a{1,t}');
%% DZF2
c_2e{1,t} = A_2*c_2a{1,t-1}+u_2(:,t)+A_21*c_1a{1,t-1}+A_23*c_3a{1,t-1};
R_2e{1,t}= [A_2*R_2a{1,t-1},A_21*R_1a{1,t-1},A_23*R_3a{1,t-1},Q_2];
K_2(:,:,t)= (A_2*R_2a{1,t-1}*R_2a{1,t-1}'*A_2'+Q_2*Q_2'+Ups_21*R_1*R_1'*Ups_21'+Ups_23*R_3*R_3'*Ups_23')*C_2'...
            *pinv(R_2*R_2'+C_2*A_2*R_2a{1,t-1}*R_2a{1,t-1 }'*A_2'*C_2'+C_2*Q_2*Q_2'*C_2'+C_2*Ups_21*R_1*R_1'*Ups_21'*C_2'+C_2*Ups_23*R_3*R_3'*Ups_23'*C_2');
K_21(:,:,t)= (eye(2)-K_2(:,:,t)*C_2)*Ups_21;
K_23(:,:,t)= (eye(2)-K_2(:,:,t)*C_2)*Ups_23;
c_2a{1,t} = (eye(2)-K_2(:,:,t)*C_2)*c_2e{1,t} + K_2(:,:,t)*y_2(:,t)+K_21(:,:,t)*(y_1(:,t-1)-C_1*c_1a{1,t-1})+K_23(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
R_2a{1,t}=[(eye(2)-K_2(:,:,t)*C_2)*A_2*R_2a{1,t-1},(eye(2)-K_2(:,:,t)*C_2)*Q_2,...
          -K_2(:,:,t)*R_2,-K_21(:,:,t)*R_1,-K_23(:,:,t)*R_3];

R_2a{1,t}=Reduction(R_2a{1,t},q);
P_2a =sum(abs(R_2a{1,t}), 2);
x_2a_up(:,t)=   c_2a{1,t}+P_2a;
x_2a_down(:,t)= c_2a{1,t}-P_2a;
J_2(:,t)=trace(R_2a{1,t}*R_2a{1,t}');
%% DZF3
c_3e{1,t} = A_3*c_3a{1,t-1}+u_3(:,t)+A_32*c_2a{1,t-1}+A_34*c_4a{1,t-1};
R_3e{1,t}= [A_3*R_3a{1,t-1},A_32*R_2a{1,t-1},A_34*R_4a{1,t-1},Q_3];
K_3(:,:,t)= (A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'+Q_3*Q_3'+Ups_32*R_2*R_2'*Ups_32'+Ups_34*R_4*R_4'*Ups_34')*C_3'...
            *pinv(R_3*R_3'+C_3*A_3*R_3a{1,t-1}*R_3a{1,t-1 }'*A_3'*C_3'+C_3*Q_3*Q_3'*C_3'+C_3*Ups_32*R_2*R_2'*Ups_32'*C_3'+C_3*Ups_34*R_4*R_4'*Ups_34'*C_3');

% K_3(:,:,t)= (A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'+Q_3*Q_3'+Ups_32*R_2*R_2'*Ups_32'+Ups_34*R_4*R_4'*Ups_34'+Phi_3*R_2a{1,t-1}*R_2a{1,t-1}'*Phi_3')*C_3'...
%             *pinv(R_3*R_3'+C_3*A_3*R_3a{1,t-1}*R_3a{1,t-1 }'*A_3'*C_3'+C_3*Q_3*Q_3'*C_3'+C_3*Ups_32*R_2*R_2'*Ups_32'*C_3'+C_3*Ups_34*R_4*R_4'*Ups_34'*C_3+C_3*Phi_3*R_2a{1,t-1}*R_2a{1,t-1}'*Phi_3'*C_3');
K_32(:,:,t)= (eye(2)-K_3(:,:,t)*C_3)*Ups_32;
K_34(:,:,t)= (eye(2)-K_3(:,:,t)*C_3)*Ups_34;
c_3a{1,t} = (eye(2)-K_3(:,:,t)*C_3)*c_3e{1,t} + K_3(:,:,t)*y_3(:,t)+K_32(:,:,t)*(y_2(:,t-1)-C_2*c_2a{1,t-1})+K_34(:,:,t)*(y_4(:,t-1)-C_4*c_4a{1,t-1});
R_3a{1,t}=[(eye(2)-K_3(:,:,t)*C_3)*A_3*R_3a{1,t-1},(eye(2)-K_3(:,:,t)*C_3)*Q_3,...
          -K_3(:,:,t)*R_3,-K_32(:,:,t)*R_2,-K_34(:,:,t)*R_4];

R_3a{1,t}=Reduction(R_3a{1,t},q);
P_3a =sum(abs(R_3a{1,t}), 2);
x_3a_up(:,t)=   c_3a{1,t}+P_3a;
x_3a_down(:,t)= c_3a{1,t}-P_3a;
J_3(:,t)=trace(R_3a{1,t}*R_3a{1,t}');
%% DZF4
c_4e{1,t} = A_4*c_4a{1,t-1}+u_4(:,t)+A_43*c_3a{1,t-1};
R_4e{1,t}= [A_4*R_4a{1,t-1},A_43*R_3a{1,t-1},Q_4];
K_4(:,:,t)= (A_4*R_4a{1,t-1}*R_4a{1,t-1}'*A_4'+Q_4*Q_4'+Ups_4*R_3*R_3'*Ups_4')*C_4'...
            *pinv(R_4*R_4'+C_4*A_4*R_4a{1,t-1}*R_4a{1,t-1 }'*A_4'*C_4'+C_4*Q_4*Q_4'*C_4'+C_4*Ups_4*R_3*R_3'*Ups_4'*C_4');
K_43(:,:,t)= (eye(2)-K_4(:,:,t)*C_4)*Ups_4;
c_4a{1,t} = (eye(2)-K_4(:,:,t)*C_4)*c_4e{1,t} + K_4(:,:,t)*y_4(:,t)+K_43(:,:,t)*(y_3(:,t-1)-C_3*c_3a{1,t-1});
R_4a{1,t}=[(eye(2)-K_4(:,:,t)*C_4)*A_4*R_4a{1,t-1},(eye(2)-K_4(:,:,t)*C_4)*Q_4,...
          -K_4(:,:,t)*R_4,-K_43(:,:,t)*R_3];

R_4a{1,t}=Reduction(R_4a{1,t},q);
P_4a =sum(abs(R_4a{1,t}), 2);
x_4a_up(:,t)=   c_4a{1,t}+P_4a;
x_4a_down(:,t)= c_4a{1,t}-P_4a;
J_4(:,t)=trace(R_4a{1,t}*R_4a{1,t}');
end

%% 估计器设计 不带解耦的
for t=2:N
%% DZF1
c_1f{1,t} = A_1*c_1b{1,t-1}+u_1(:,t)+A_12*c_2b{1,t-1};
R_1f{1,t}= [A_1*R_1b{1,t-1},A_12*R_2b{1,t-1},Q_1];
K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1'+R_1*R_1');
c_1b{1,t} = (eye(2)-K_1b(:,:,t)*C_1)*c_1f{1,t} + K_1b(:,:,t)*y_1(:,t);
R_1b{1,t} = [(eye(2)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*R_1];
R_1b{1,t}=Reduction(R_1b{1,t},q);
P_1b =sum(abs(R_1b{1,t}), 2);
x_1b_up(:,t)=   c_1b{1,t}+P_1b;
x_1b_down(:,t)= c_1b{1,t}-P_1b;
J_1b(:,t)=trace(R_1b{1,t}*R_1b{1,t}');
%% DZF2
c_2f{1,t} = A_2*c_2b{1,t-1}+u_2(:,t)+A_21*c_1b{1,t-1}+A_23*c_3b{1,t-1};
R_2f{1,t}= [A_2*R_2b{1,t-1},A_21*R_1b{1,t-1},A_23*R_3b{1,t-1},Q_2];
K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2'+R_2*R_2');
c_2b{1,t} = (eye(2)-K_2b(:,:,t)*C_2)*c_2f{1,t} + K_2b(:,:,t)*y_2(:,t);
R_2b{1,t} = [(eye(2)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*R_2];
R_2b{1,t}=Reduction(R_2b{1,t},q);
P_2b =sum(abs(R_2b{1,t}), 2);
x_2b_up(:,t)=   c_2b{1,t}+P_2b;
x_2b_down(:,t)= c_2b{1,t}-P_2b;
J_2b(:,t)=trace(R_2b{1,t}*R_2b{1,t}');
%% DZF3
c_3f{1,t} = A_3*c_3b{1,t-1}+u_3(:,t)+A_32*c_2b{1,t-1}+A_34*c_4b{1,t-1};
R_3f{1,t}= [A_3*R_3b{1,t-1},A_32*R_2b{1,t-1},A_34*R_4b{1,t-1},Q_3];
K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3'+R_3*R_3');
c_3b{1,t} = (eye(2)-K_3b(:,:,t)*C_3)*c_3f{1,t} + K_3b(:,:,t)*y_3(:,t);
R_3b{1,t} = [(eye(2)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*R_3];
R_3b{1,t}=Reduction(R_3b{1,t},q);
P_3b =sum(abs(R_3b{1,t}), 2);
x_3b_up(:,t)=   c_3b{1,t}+P_3b;
x_3b_down(:,t)= c_3b{1,t}-P_3b;
J_3b(:,t)=trace(R_3b{1,t}*R_3b{1,t}');
%% DZF4
c_4f{1,t} = A_4*c_4b{1,t-1}+u_4(:,t)+A_43*c_3b{1,t-1};
R_4f{1,t}= [A_4*R_4b{1,t-1},A_43*R_3b{1,t-1},Q_4];
K_4b(:,:,t)=R_4f{1,t}*R_4f{1,t}'*C_4'*inv(C_4*R_4f{1,t}*R_4f{1,t}'*C_4'+R_4*R_4');
c_4b{1,t} = (eye(2)-K_4b(:,:,t)*C_4)*c_4f{1,t} + K_4b(:,:,t)*y_4(:,t);
R_4b{1,t} = [(eye(2)-K_4b(:,:,t)*C_4)*R_4f{1,t},-K_4b(:,:,t)*R_4];
R_4b{1,t}=Reduction(R_4b{1,t},q);
P_4b =sum(abs(R_4b{1,t}), 2);
x_4b_up(:,t)=   c_4b{1,t}+P_4b;
x_4b_down(:,t)= c_4b{1,t}-P_4b;
J_4b(:,t)=trace(R_4b{1,t}*R_4b{1,t}');
end
%% 从Cell中提取每个矩阵的信息
x_1a = zeros(2, N); x_2a = zeros(2, N); x_3a = zeros(2, N); x_4a = zeros(2, N);
x_1b = zeros(2, N); x_2b = zeros(2, N); x_3b = zeros(2, N); x_4b = zeros(2, N);
for i=1:N 
    x_1a(:,i)=c_1a{1,i};
    x_2a(:,i)=c_2a{1,i};
    x_3a(:,i)=c_3a{1,i};
    x_4a(:,i)=c_4a{1,i};
    x_1b(:,i)=c_1b{1,i};
    x_2b(:,i)=c_2b{1,i};
    x_3b(:,i)=c_3b{1,i};
    x_4b(:,i)=c_4b{1,i};
end
%% 边界使用阴影区域来进行绘制 位置的
% 假设 N 已经被定义，t = 1:N，以及所有信号变量都已存在。
% ====== 高级统一绘图风格设置 ======
lw = 2.0;                 % line width
fs = 14;                  % 字体大小
t = 1:N;
cols = lines(4);          % 默认高级配色，用于信号线
% ----------------------------------------------------
% **淡蓝色阴影区域颜色设置**
fill_color = [0.678 0.847 0.902]; % 淡蓝色 (Light Sky Blue)，RGB值
fill_alpha = 0.6;                  % 透明度设置为 50%
% 调整图窗大小，使用较大的尺寸
figure('Color','w','Position',[100 100 1200 800]); 
% 准备填充区域的 X 坐标
X_fill = [t, fliplr(t)]; 
% ================= Subplot 1 : d1 ===================
subplot(2,2,1); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_1 = [x_1a_up(1,:), fliplr(x_1a_down(1,:))];
fill(X_fill, Y_fill_1, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_1 (原始信号) ---
plot(t, x_1(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_1a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(a) Signal $d_1$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ','$d_1$','DZF of $d_1$'}, ...
    'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 2 : d2 ===================
subplot(2,2,2); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(1,:), fliplr(x_2a_down(1,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_2 ---
plot(t, x_2(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_2a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(b) Signal $d_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_2$','DZF of $d_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 3 : d3 ===================
subplot(2,2,3); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_3 = [x_3a_up(1,:), fliplr(x_3a_down(1,:))];
fill(X_fill, Y_fill_3, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_3 ---
plot(t, x_3(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_3a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(c) Signal $d_3$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_3$','DZF of $d_3$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 4 : d4 ===================
subplot(2,2,4); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_4 = [x_4a_up(1,:), fliplr(x_4a_down(1,:))];
fill(X_fill, Y_fill_4, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_4 ---
plot(t, x_4(1,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_4a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(d) Signal $d_4$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ','$d_4$','DZF of $d_4$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
%%  关于速度的估计图
lw = 2.0;                 % line width
fs = 14;                  % 字体大小
t = 1:N;
cols = lines(4);          % 默认高级配色，用于信号线
% ----------------------------------------------------
% **淡蓝色阴影区域颜色设置**
fill_color = [0.678 0.847 0.902]; % 淡蓝色 (Light Sky Blue)，RGB值
fill_alpha = 0.6;                  % 透明度设置为 50%
% 调整图窗大小，使用较大的尺寸
figure('Color','w','Position',[100 100 1200 800]); 
subplot(2,2,1); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_1 = [x_1a_up(2,:), fliplr(x_1a_down(2,:))];
fill(X_fill, Y_fill_1, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 v_1 (原始信号) ---
plot(t, x_1(2,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_1a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('(a) Signal $v_1$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound','$v_1$','DZF of $v_1$'}, ...
    'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 2 : d2 ===================
subplot(2,2,2); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(2,:), fliplr(x_2a_down(2,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 v_2 ---
plot(t, x_2(2,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_2a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('(b) Signal $v_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound','$v_2$','DZF of $v_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 3 : d3 ===================
subplot(2,2,3); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_3 = [x_3a_up(2,:), fliplr(x_3a_down(2,:))];
fill(X_fill, Y_fill_3, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 v_3 ---
plot(t, x_3(2,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_3a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('(c) Signal $v_3$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound','$v_3$','DZF of $v_3$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');
% ================= Subplot 4 : d4 ===================
subplot(2,2,4); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_4 = [x_4a_up(2,:), fliplr(x_4a_down(2,:))];
fill(X_fill, Y_fill_4, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_4 ---
plot(t, x_4(2,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_4a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('(d) Signal $v_4$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound','$v_4$','DZF of $v_4$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');

%%  高级感绘图 估计图
% ====== 高级统一绘图风格设置 ======
lw = 2.0;                 % line width
fs = 12;                  % font size
cols = lines(4);          % 高级配色
t = 1:N;
figure('Color','w','Position',[100 100 900 700]);
% ================= Subplot 1 : d1 ===================
subplot(2,2,1); hold on; box on;
plot(t, x_1(1,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_1a(1,:), 'Color', cols(2,:), 'LineStyle','-', 'Marker','x', 'LineWidth', lw);
plot(t, x_1a_up(1,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_1a_down(1,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('Signal d_1','FontSize',fs);
legend({'d_1','DZF of d_1','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 2 : d2 ===================
subplot(2,2,2); hold on; box on;
plot(t, x_2(1,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_2a(1,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_2a_up(1,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_2a_down(1,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('Signal d_2','FontSize',fs);
legend({'d_2','DZF of d_2','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 3 : d3 ===================
subplot(2,2,3); hold on; box on;
plot(t, x_3(1,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_3a(1,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_3a_up(1,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_3a_down(1,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('Signal d_3','FontSize',fs);
legend({'d_3','DZF of d_3','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 4 : v4 ===================
subplot(2,2,4); hold on; box on;
plot(t, x_4(1,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_4a(1,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_4a_up(1,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_4a_down(1,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('Signal d_4','FontSize',fs);
legend({'d_4','DZF of d_4','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');

figure('Color','w','Position',[100 100 900 700]);
% ================= Subplot 1 : v1 ===================
subplot(2,2,1); hold on; box on;
plot(t, x_1(2,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_1a(2,:), 'Color', cols(2,:), 'LineStyle','-', 'Marker','x', 'LineWidth', lw);
plot(t, x_1a_up(2,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_1a_down(2,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('Signal v_1','FontSize',fs);
legend({'v_1','DZF of v_1','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 2 : v2 ===================
subplot(2,2,2); hold on; box on;
plot(t, x_2(2,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_2a(2,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_2a_up(2,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_2a_down(2,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('Signal v_2','FontSize',fs);
legend({'v_2','DZF of v_2','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 3 : v3 ===================
subplot(2,2,3); hold on; box on;
plot(t, x_3(2,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_3a(2,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_3a_up(2,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_3a_down(2,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('Signal v_3','FontSize',fs);
legend({'d_3','DZF of d_3','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
% ================= Subplot 4 : v4 ===================
subplot(2,2,4); hold on; box on;
plot(t, x_4(2,:), 'Color', cols(1,:), 'LineStyle','-.', 'LineWidth', lw);
plot(t, x_4a(2,:), 'Color', cols(2,:), 'Marker','x', 'LineWidth', lw);
plot(t, x_4a_up(2,:), 'Color', cols(3,:), 'LineWidth', lw);
plot(t, x_4a_down(2,:), 'Color', cols(3,:), 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Velocity(m/s)','FontSize',fs);
title('Signal v_4','FontSize',fs);
legend({'v_4','DZF of v_4','Upper bound','Lower bound'}, ...
    'FontSize',fs,'Location','best');
%%
% 设置图形整体属性
figure('Color', [1 1 1]); % 白色背景，简约高级
set(gcf, 'Units', 'normalized', 'Position', [0.1 0.1 0.8 0.4]); % 调整图窗大小，使其更宽
% 绘制子图 1: J_1/J_1b
subplot(1, 3, 1);
% DZF with decoupling: 蓝色线条，实线，加圆圈标记
plot(1:N, J_1(1,:), 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 橙色线条，虚线
plot(1:N, J_1b(1,:), 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.5, 'LineStyle', '--');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on; % 添加网格，增加专业感
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 2: J_2/J_2b
subplot(1, 3, 2);
% DZF with decoupling: 绿色线条，实线，加方块标记
plot(1:N, J_2(1,:), 'Color', [0.4660 0.6740 0.1880], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', 's', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 紫色线条，点划线
plot(1:N, J_2b(1,:), 'Color', [0.4940 0.1840 0.5560], 'LineWidth', 1.5, 'LineStyle', '-.');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% 绘制子图 3: J_3/J_3b
subplot(1, 3, 3);
% DZF with decoupling: 青色线条，实线
plot(1:N, J_3(1,:), 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1.5, 'LineStyle', '-', 'Marker', '^', 'MarkerSize', 3);
hold on;
% DZF without decoupling: 红色线条，双虚线
plot(1:N, J_3b(1,:), 'Color', [0.6350 0.0780 0.1840], 'LineWidth', 1.5, 'LineStyle', ':');
xlabel('Time (t)', 'FontSize', 10, 'FontName', 'Arial');
grid on;
legend({'DZF with decoupling','DZF without decoupling'}, 'FontSize', 8, 'Location', 'best');
box on;
% ----------------------------------------------------
% 增加一个总标题（可选）
sgtitle('DZF Performance Comparison Over Time', 'FontSize', 14, 'FontWeight', 'bold', 'FontName', 'Arial');
%% 性能指标的比较
figure(1)
plot(1:N,J_1(1,:),'r-.','LineWidth',2);
hold on
plot(1:N,J_1b(1,:),'r-.','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'DZF with decoupling','DZF without decoupling'},'FontSize',12);
figure(2)
plot(1:N,J_2(1,:),'r-.','LineWidth',2);
hold on
plot(1:N,J_2b(1,:),'r-.','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'DZF with decoupling','DZF without decoupling'},'FontSize',12);
figure(3)
plot(1:N,J_3(1,:),'r-.','LineWidth',2);
hold on
plot(1:N,J_3b(1,:),'r-.','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'DZF with decoupling','DZF without decoupling'},'FontSize',12);

%% 估计图
figure(1)
plot(1:N,x_1(1,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_1a(1,:),'r-x','LineWidth',2);
plot(1:N,x_1a_up(1,:),'b','LineWidth',2);
plot(1:N,x_1a_down(1,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
ylabel('Position(m)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'d_1','DZF of d_1'},'FontSize',12);

figure(2)
plot(1:N,x_1(2,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_1a(2,:),'r-x','LineWidth',2);
plot(1:N,x_1a_up(2,:),'b','LineWidth',2);
plot(1:N,x_1a_down(2,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Position(m)','FontSize',12);
ylabel('Velocity(m/s)','FontSize',12);
legend({'v_1','DZF of v_1'},'FontSize',12);


figure(3)
plot(1:N,x_2(1,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_2a(1,:),'r-x','LineWidth',2);
plot(1:N,x_2a_up(1,:),'b','LineWidth',2);
plot(1:N,x_2a_down(1,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
ylabel('Position(m)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'d_2','DZF of d_2'},'FontSize',12);


figure(4)
plot(1:N,x_2(2,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_2a(2,:),'r-x','LineWidth',2);
plot(1:N,x_2a_up(2,:),'b','LineWidth',2);
plot(1:N,x_2a_down(2,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Position(m)','FontSize',12);
ylabel('Velocity(m/s)','FontSize',12);
legend({'v_2','DZF of v_2'},'FontSize',12);


figure(5)
plot(1:N,x_3(1,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_3a(1,:),'r-x','LineWidth',2);
plot(1:N,x_3a_up(1,:),'b','LineWidth',2);
plot(1:N,x_3a_down(1,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
ylabel('Position(m)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'d_3','DZF of d_3'},'FontSize',12);


figure(6)
plot(1:N,x_3(2,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_3a(2,:),'r-x','LineWidth',2);
plot(1:N,x_3a_up(2,:),'b','LineWidth',2);
plot(1:N,x_3a_down(2,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Position(m)','FontSize',12);
ylabel('Velocity(m/s)','FontSize',12);
legend({'v_3','DZF of v_3'},'FontSize',12);



figure(7)
plot(1:N,x_4(1,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_4a(1,:),'r-x','LineWidth',2);
plot(1:N,x_4a_up(1,:),'b','LineWidth',2);
plot(1:N,x_4a_down(1,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
ylabel('Position(m)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'d_4','DZF of d_4'},'FontSize',12);


figure(8)
plot(1:N,x_4(2,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_4a(2,:),'r-x','LineWidth',2);
plot(1:N,x_4a_up(2,:),'b','LineWidth',2);
plot(1:N,x_4a_down(2,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Position(m)','FontSize',12);
ylabel('Velocity(m/s)','FontSize',12);
legend({'v_4','DZF of v_4'},'FontSize',12);
