%% 卡车下解耦的胞性估计方法，因为他在那个时刻进行了突变所以会导致包含性质被打破
clc;
clear;
N=200;  %仿真步长
q_1=12; % 降维参数
q_2=16; % 降维参数
q_3=12; % 降维参数
%% System Parameters
Theta_1=0.9999;
Theta_2=0.9999;
Theta_3=0.9999;
gamma_2=0.1476;
gamma_3=0.1476;
delta_2=0.1476;
delta_3=0.1476;
k_u1=1.48;
k_u2=1.48;
k_u3=1.48;
xi_tau=10;
xi_delta_v=10;
xi_ui=100;
xi_d=0.001;
xi_v=0.001;
xi_v0=10;
tau=0.25;
%% Subsystems
A_1=[0.99999999 0;
     0 Theta_1];
A_12=[0 0;
      gamma_2 0];
A_2=[1 -1;
     delta_2 Theta_2];
A_21=[0 1;
      0 0];
A_23=[0 0;
      gamma_3 0];
A_3=[1 -1;
     delta_3 Theta_3];
A_32=[0 1;
      0 0];
B_1=[0;
     k_u1];
B_2=[0;
     k_u2];
B_3=[0;
     k_u3];
C_1 = [1 0;
       0 1];
C_2 = [1 0;
       0 1];
C_3 = [1 0];
%% 噪声后面考虑换为有界噪声
Q_1 = diag([0.000000000001,0.001]);
Q_2 = diag([0.001,0.001]);
Q_3 = diag([0.001,0.001]);
R_1 = diag([0.001,0.01]);
R_2 = diag([0.01,0.01]);
R_3 = 0.01;
v_1= [-0.001 + 0.002*rand(1,N);-0.01 + 0.02*rand(1,N)]; % v_1 = gauss_ns(R_1,N);
v_2= [-0.01 + 0.02*rand(1,N);-0.01 + 0.02*rand(1,N)]; % v_2 = gauss_ns(R_2,N);
v_3= -0.01 + 0.02*rand(1,N); % v_3 = gauss_ns(R_3,N);
%% Overall System
A= [A_1 A_12 zeros(2,2);
    A_21 A_2 A_23;
    zeros(2,2) A_32 A_3];
B= [B_1 zeros(2,1) zeros(2,1);
    zeros(2,1) B_2 zeros(2,1);
    zeros(2,1) zeros(2,1) B_3];
C= [C_1 zeros(2,2) zeros(2,2);
    zeros(2,2) C_2 zeros(2,2);
    0 0 0 0 C_3];
w = [zeros(1,N); -0.001 + 0.002*rand(5,N)];
% w = gauss_ns(mdiag(Q_1,Q_2,Q_3),N);
%% LQG
Q= [xi_v0 -xi_v0 0 0 0 0;
    -xi_v0 xi_delta_v+xi_v+xi_v0 0 -xi_delta_v 0 0;
    0 0 xi_d+xi_tau -tau*xi_tau 0 0;
    0 -xi_delta_v -tau*xi_tau tau^2*xi_tau+xi_delta_v+xi_v+xi_delta_v 0 -xi_delta_v;
    0 0 0 0 xi_d+xi_tau -tau*xi_tau;
    0 0 0 -xi_delta_v -tau*xi_tau tau^2*xi_tau+xi_delta_v+xi_v];
R= [xi_ui 0 0;
    0 xi_ui 0;
    0 0 xi_ui];
[k,p,r]=dlqr(A,B,Q,R);
Ac=A-B*k;
%% System Initial
x(:,1)=[19.44;
        19.44;
        4.86;
        19.44;
        4.86;
        19.44];
y_1(:,1)=C(1:2,:)*x(:,1)+v_1(:,1);
y_2(:,1)=C(3:4,:)*x(:,1)+v_2(:,1);
%% Estimator Initial
x_1a(:,1)=[19.44;19.44];
x_2a(:,1)=[4.86;19.44];
x_3a(:,1)=[4.86;19.44];
x_1a_up(:,1)=x_1a(:,1)+0.02*ones(2,1);
x_2a_up(:,1)=x_2a(:,1)+0.02*ones(2,1);
x_3a_up(:,1)=x_3a(:,1)+0.02*ones(2,1);
R_1a{1,1}=diag([0.02,0.02]);   R_1e{1,1}=diag([0.02,0.02]);
R_2a{1,1}=diag([0.02,0.02]);   R_2e{1,1}=diag([0.02,0.02]);
R_3a{1,1}=diag([0.02,0.02]);   R_3e{1,1}=diag([0.02,0.02]);
J_1(:,1)=trace(R_1a{1,1}*R_1a{1,1}');
J_2(:,1)=trace(R_2a{1,1}*R_2a{1,1}');
J_3(:,1)=trace(R_3a{1,1}*R_3a{1,1}');
%% 解耦增益阵 (假设C是不变的)
C_1K = pinv(C_1'*C_1)*C_1';
C_2K = pinv(C_2'*C_2)*C_2';
C_3K = C_3'*pinv(C_3*C_3');
Ups_1  = A_12*C_2K;             
Ups_21 = A_21*C_1K; 
Ups_23 = A_23*C_3K;
Phi_2 =  A_23*(eye(2)-C_3K*C_3); 
Ups_3 =  A_32*C_2K;
%% 整体的大循环
for t=2:N
%% System State Iteration
u(:,t)=-B*k*x(:,t-1);
x(:,t)=A*x(:,t-1) +u(:,t) + w(:,t);
%% 这部分在t的时刻突变会导致原本的包含关系不存在的。
if(t==50)
x(1,t)=x(1,t)+2;
end
if(t==100)
x(1,t)=x(1,t)+2;
end
if(t==150)
x(1,t)=x(1,t)-6;
end
y_1(:,t)=C(1:2,:)*x(:,t)+v_1(:,t);
y_2(:,t)=C(3:4,:)*x(:,t)+v_2(:,t);
y_3(:,t)=C(5,:)*x(:,t)+v_3(:,t);
end
%% 耦合的DZF
for t=2:N
%% DZF1 with decoupling
x_1e(:,t)=  A_1*x_1a(:,t-1)+A_12*x_2a(:,t-1)+u(1:2,t);
R_1e{1,t}=  [A_1*R_1a{1,t-1},A_12*R_2a{1,t-1},Q_1];
K_1(:,:,t)= (A_1*R_1a{1,t-1}*R_1a{1,t-1}'*A_1'+Q_1*Q_1'+Ups_1*R_2*R_2'*Ups_1')*C_1'...
            *pinv(R_1*R_1'+C_1*A_1*R_1a{1,t-1}*R_1a{1,t-1 }'*A_1'*C_1'+C_1*Q_1*Q_1'*C_1'+C_1*Ups_1*R_2*R_2'*Ups_1'*C_1');
K_12(:,:,t)= (eye(2)-K_1(:,:,t)*C_1)*Ups_1;
x_1a(:,t)= x_1e(:,t)+K_1(:,:,t)*(y_1(:,t)-C_1*x_1e(:,t)) ...
           +K_12(:,:,t)*(y_2(:,t-1)-C_2*x_2a(:,t-1));
R_1a{1,t}=[(eye(2)-K_1(:,:,t)*C_1)*A_1*R_1a{1,t-1},(eye(2)-K_1(:,:,t)*C_1)*Q_1,...
          -K_1(:,:,t)*R_1,-K_12(:,:,t)*R_2];
R_1a{1,t}=Reduction(R_1a{1,t},q_1);

P_1a =sum(abs(R_1a{1,t}), 2);
x_1a_up(:,t)=   x_1a(:,t)+P_1a;
x_1a_down(:,t)= x_1a(:,t)-P_1a;
J_1(:,t)=trace(R_1a{1,t}*R_1a{1,t}');
%% DZF2 with decoupling
x_2e(:,t)=A_2*x_2a(:,t-1)+A_21*x_1a(:,t-1)+A_23*x_3a(:,t-1)+u(3:4,t);
K_2(:,:,t)= (A_2*R_2a{1,t-1}*R_2a{1,t-1}'*A_2'+Q_2*Q_2'+Ups_21*R_1*R_1'*Ups_21'+Ups_23*R_3*R_3'*Ups_23'+Phi_2*R_3a{1,t-1}*R_3a{1,t-1}'*Phi_2')*C_2'...
            *pinv(R_2*R_2'+C_2*A_2*R_2a{1,t-1}*R_2a{1,t-1}'*A_2'*C_2'+C_2*Q_2*Q_2'*C_2'+C_2*Ups_21*R_1*R_1'*Ups_21'*C_2'+C_2*Ups_23*R_3*R_3'*Ups_23'*C_2'+C_2*Phi_2*R_3a{1,t-1}*R_3a{1,t-1}'*Phi_2'*C_2');
K_21(:,:,t)= (eye(2)-K_2(:,:,t)*C_2)*Ups_21;
K_23(:,:,t)= (eye(2)-K_2(:,:,t)*C_2)*Ups_23;
x_2a(:,t)= x_2e(:,t)+K_2(:,:,t)*(y_2(:,t)-C_2*x_2e(:,t)) ...
           +K_21(:,:,t)*(y_1(:,t-1)-C_1*x_1a(:,t-1))+K_23(:,:,t)*(y_3(:,t-1)-C_3*x_3a(:,t-1));
R_2a{1,t}=[(eye(2)-K_2(:,:,t)*C_2)*A_2*R_2a{1,t-1},(eye(2)-K_2(:,:,t)*C_2)*Q_2,...
          -K_2(:,:,t)*R_2,-K_21(:,:,t)*R_1,-K_23(:,:,t)*R_3,(eye(2)-K_2(:,:,t)*C_2)*Phi_2*R_3a{1,t-1}];
R_2a{1,t}=Reduction(R_2a{1,t},q_2);

P_2a =sum(abs(R_2a{1,t}), 2);
x_2a_up(:,t)=   x_2a(:,t)+P_2a;
x_2a_down(:,t)= x_2a(:,t)-P_2a;
J_2(:,t)=trace(R_2a{1,t}*R_2a{1,t}');
%% DZF3 with decoupling
x_3e(:,t)=A_3*x_3a(:,t-1)+A_32*x_2a(:,t-1)+u(5:6,t);
K_3(:,:,t)=(A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'+Q_3*Q_3'+Ups_3*R_2*R_2'*Ups_3')*C_3'...
           *pinv(R_3*R_3'+C_3*A_3*R_3a{1,t-1}*R_3a{1,t-1}'*A_3'*C_3'+C_3*Q_3*Q_3'*C_3'+R_3*R_3'+C_3*Ups_3*R_2*R_2'*Ups_3'*C_3');
K_32(:,:,t)= (eye(2)-K_3(:,:,t)*C_3)*Ups_3;
x_3a(:,t)= x_3e(:,t)+K_3(:,:,t)*(y_3(:,t)-C_3*x_3e(:,t)) ...
           +K_32(:,:,t)*(y_2(:,t-1)-C_2*x_2a(:,t-1));   
R_3a{1,t}=[(eye(2)-K_3(:,:,t)*C_3)*A_3*R_3a{1,t-1},(eye(2)-K_3(:,:,t)*C_3)*Q_3,...
          -K_3(:,:,t)*R_3,-K_32(:,:,t)*R_3];
R_3a{1,t}=Reduction(R_3a{1,t},q_3);

P_3a =sum(abs(R_3a{1,t}), 2);
x_3a_up(:,t)=   x_3a(:,t)+P_3a;
x_3a_down(:,t)= x_3a(:,t)-P_3a;
J_3(:,t)=trace(R_3a{1,t}*R_3a{1,t}');
end
%% Estimator Initial
x_1b(:,1)=[19.44;19.44];
x_2b(:,1)=[4.86;19.44];
x_3b(:,1)=[4.86;19.44];
x_1b_up(:,1)=x_1b(:,1)+0.02*ones(2,1);
x_2b_up(:,1)=x_2b(:,1)+0.02*ones(2,1);
x_3b_up(:,1)=x_3b(:,1)+0.02*ones(2,1);
R_1b{1,1}=diag([0.02,0.02]);   R_1f{1,1}=diag([0.02,0.02]);
R_2b{1,1}=diag([0.02,0.02]);   R_2f{1,1}=diag([0.02,0.02]);
R_3b{1,1}=diag([0.02,0.02]);   R_3f{1,1}=diag([0.02,0.02]);
J_1b(:,1)=trace(R_1b{1,1}*R_1b{1,1}');
J_2b(:,1)=trace(R_2b{1,1}*R_2b{1,1}');
J_3b(:,1)=trace(R_3b{1,1}*R_3b{1,1}');
%% 不耦合的DZF
for t=2:N
%% DZF1 without decoupling
x_1f(:,t)=  A_1*x_1b(:,t-1)+A_12*x_2b(:,t-1)+u(1:2,t);
R_1f{1,t}=  [A_1*R_1b{1,t-1},A_12*R_2b{1,t-1},Q_1];
K_1b(:,:,t)=R_1f{1,t}*R_1f{1,t}'*C_1'*inv(C_1*R_1f{1,t}*R_1f{1,t}'*C_1'+R_1*R_1');
x_1b(:,t)= x_1f(:,t)+K_1b(:,:,t)*(y_1(:,t)-C_1*x_1f(:,t));
R_1b{1,t} = [(eye(2)-K_1b(:,:,t)*C_1)*R_1f{1,t},-K_1b(:,:,t)*R_1];
R_1b{1,t}=Reduction(R_1b{1,t},q_1);
P_1b =sum(abs(R_1b{1,t}), 2);
x_1b_up(:,t)=   x_1b(:,t)+P_1b;
x_1b_down(:,t)= x_1b(:,t)-P_1b;
J_1b(:,t)=trace(R_1b{1,t}*R_1b{1,t}');
%% DZF2 without decoupling
x_2f(:,t)=A_2*x_2b(:,t-1)+A_21*x_1b(:,t-1)+A_23*x_3b(:,t-1)+u(3:4,t);
R_2f{1,t}= [A_2*R_2b{1,t-1},A_21*R_1b{1,t-1},A_23*R_3b{1,t-1},Q_2];
K_2b(:,:,t)=R_2f{1,t}*R_2f{1,t}'*C_2'*inv(C_2*R_2f{1,t}*R_2f{1,t}'*C_2'+R_2*R_2');
x_2b(:,t)= (eye(2)-K_2b(:,:,t)*C_2)*x_2f(:,t) + K_2b(:,:,t)*y_2(:,t);
R_2b{1,t}=[(eye(2)-K_2b(:,:,t)*C_2)*R_2f{1,t},-K_2b(:,:,t)*R_2];
R_2b{1,t}=Reduction(R_2b{1,t},q_2);
P_2b =sum(abs(R_2b{1,t}), 2);
x_2b_up(:,t)=   x_2b(:,t)+P_2b;
x_2b_down(:,t)= x_2b(:,t)-P_2b;
J_2b(:,t)=trace(R_2b{1,t}*R_2b{1,t}');
%% DZF3 without decoupling
x_3f(:,t)=A_3*x_3b(:,t-1)+A_32*x_2b(:,t-1)+u(5:6,t);
R_3f{1,t}= [A_3*R_3b{1,t-1},A_32*R_2b{1,t-1},Q_3];
K_3b(:,:,t)=R_3f{1,t}*R_3f{1,t}'*C_3'*inv(C_3*R_3f{1,t}*R_3f{1,t}'*C_3'+R_3*R_3');
x_3b(:,t)= (eye(2)-K_3b(:,:,t)*C_3)*x_3f(:,t) + K_3b(:,:,t)*y_3(:,t);
R_3b{1,t}=[(eye(2)-K_3b(:,:,t)*C_3)*R_3f{1,t},-K_3b(:,:,t)*R_3];
R_3b{1,t}=Reduction(R_3b{1,t},q_3);
P_3b =sum(abs(R_3b{1,t}), 2);
x_3b_up(:,t)=   x_3b(:,t)+P_3b;
x_3b_down(:,t)= x_3b(:,t)-P_3b;
J_3b(:,t)=trace(R_3b{1,t}*R_3b{1,t}');
end

%% 性能指标的绘图
lw = 2.0;                 % 线宽
fs = 12;                  % 字体大小
color_decoupling = [0.0 0.447 0.741]; % 蓝色，代表 'with decoupling'
color_nodecoupling = [0.850 0.325 0.098]; % 橙色，代表 'without decoupling'
% ---------------------------------
% 创建一个新的图窗，并设置一个适合 1x3 布局的宽幅尺寸
figure('Color', 'w', 'Position', [100 100 1200 400]); % [X, Y, 宽度, 高度]
% ================= Subplot 1: J_1 ===================
subplot(1, 3, 1);
hold on;
box on; % 添加边框
grid on; % 添加网格线，增强可读性
% Performance with decoupling (蓝色，实线)
plot(1:N, J_1(1,:), 'Color', color_decoupling, 'LineStyle','-', 'LineWidth', lw);
% Performance without decoupling (橙色，虚线)
plot(1:N, J_1b(1,:), 'Color', color_nodecoupling, 'LineStyle','--', 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Value J_1','FontSize',fs); % 明确 Y 轴标签
title('(a) Performance Index J_1', 'FontSize',fs, 'FontWeight', 'bold');
% 注意：图例中移除了原代码中的 'F3'，因为图中只绘制了两条线。
legend({'with decoupling','without decoupling'}, 'FontSize',fs-2,'Location','best');
% ================= Subplot 2: J_2 ===================
subplot(1, 3, 2);
hold on;
box on;
grid on;
% Performance with decoupling (蓝色，实线)
plot(1:N, J_2(1,:), 'Color', color_decoupling, 'LineStyle','-', 'LineWidth', lw);
% Performance without decoupling (橙色，虚线)
plot(1:N, J_2b(1,:), 'Color', color_nodecoupling, 'LineStyle','--', 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Value J_2','FontSize',fs); % 明确 Y 轴标签
title('(b) Performance Index J_2', 'FontSize',fs, 'FontWeight', 'bold');
legend({'with decoupling','without decoupling'}, 'FontSize',fs-2,'Location','best');
% ================= Subplot 3: J_3 ===================
subplot(1, 3, 3);
hold on;
box on;
grid on;
% Performance with decoupling (蓝色，实线)
plot(1:N, J_3(1,:), 'Color', color_decoupling, 'LineStyle','-', 'LineWidth', lw);
% Performance without decoupling (橙色，虚线)
plot(1:N, J_3b(1,:), 'Color', color_nodecoupling, 'LineStyle','--', 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Value J_3','FontSize',fs); % 明确 Y 轴标签
title('(c) Performance Index J_3', 'FontSize',fs, 'FontWeight', 'bold');
legend({'with decoupling','without decoupling'}, 'FontSize',fs-2,'Location','best');
% ---------------------------------
% 可选：添加一个总标题
sgtitle('Performance Comparison of Decoupling Strategies Over Time', 'FontSize', 14, 'FontWeight', 'bold');

%% 注1：对于C=[1 0]的系统而言，第二个状态的估计需要保证准确的初始估计值。
%% 使用阴影来描述估计的图像
lw = 2.0;                 % line width
fs = 14;                  % 字体大小
t = 1:N;
cols = lines(4);          % 默认高级配色，用于信号线
% ----------------------------------------------------
% **淡蓝色阴影区域颜色设置**
fill_color = [0.678 0.847 0.902]; % 淡蓝色 (Light Sky Blue)，RGB值
fill_alpha = 0.6;                  % 透明度设置为 50%
% 调整图窗大小，使用较大的尺寸
figure('Color','w','Position',[100 100 1200 800]); 
% 准备填充区域的 X 坐标
X_fill = [t, fliplr(t)]; 
% ================= Subplot 1 : d1 ===================
subplot(2,3,1); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_1 = [x_1a_up(2,:), fliplr(x_1a_down(2,:))];
fill(X_fill, Y_fill_1, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_1 (原始信号) ---
plot(t, x(2,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_1a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
% ylabel('Position (m)','FontSize',fs);
title('(a) Signal $d_1$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ','$d_1$','DZF of $d_1$'}, ...
    'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');

subplot(2,3,2); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(1,:), fliplr(x_2a_down(1,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_2 ---
plot(t, x(3,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_2a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(b) Signal $d_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_2$','DZF of $d_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');


subplot(2,3,3); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_2a_up(2,:), fliplr(x_2a_down(2,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_2 ---
plot(t, x(4,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_2a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(b) Signal $d_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_2$','DZF of $d_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');

subplot(2,3,4); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_3a_up(1,:), fliplr(x_3a_down(1,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_2 ---
plot(t, x(5,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_3a(1,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(b) Signal $d_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_2$','DZF of $d_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');

subplot(2,3,5); hold on; box on;
% --- 1. 绘制淡蓝色阴影区域 ---
Y_fill_2 = [x_3a_up(2,:), fliplr(x_3a_down(2,:))];
fill(X_fill, Y_fill_2, fill_color, 'FaceAlpha', fill_alpha, 'EdgeColor', 'none');
% --- 2. 绘制信号 d_2 ---
plot(t, x(6,:), 'Color', cols(1,:), 'LineStyle','-', 'LineWidth', 1.5);
% --- 3. 绘制估计/DZF信号 ---
plot(t, x_3a(2,:), 'Color', cols(2,:), 'LineStyle','--', 'Marker','o', 'MarkerSize', 4, 'LineWidth', lw);
xlabel('Time (t)','FontSize',fs);
ylabel('Position (m)','FontSize',fs);
title('(b) Signal $d_2$ and DZF', 'FontSize',fs, 'Interpreter', 'latex');
legend({'Bound ',' $d_2$','DZF of $d_2$'}, 'FontSize',fs-2,'Location','best', 'Interpreter', 'latex');

%% 作图估计图
figure(1)
plot(1:N,x(1,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_1a(1,:),'r-x','LineWidth',2);
% plot(1:N,x_1a_up(1,:),'b','LineWidth',2);
% plot(1:N,x_1a_down(1,:),'b','LineWidth',2);
xlabel('Time(t)','FontSize',12);
ylabel('Velocity(m/s)','FontSize',12);
legend({'v_0','DKF of v_0'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);

figure(2)
plot(1:N,x(2,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_1a(2,:),'r-x','LineWidth',2);
plot(1:N,x_1a_up(2,:),'b','LineWidth',2);
plot(1:N,x_1a_down(2,:),'b','LineWidth',2);
% plot(1:N,y_1(1,:),'g-.','LineWidth',2);
xlabel('Time (t)','FontSize',12);
ylabel('Velocity (m/s)','FontSize',12);
legend({'v_1','DKF of v_1'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);

figure(3)
plot(1:N,x(3,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_2a(1,:),'r-x','LineWidth',2);
% plot(1:N,x_2a_up(1,:),'b','LineWidth',2);
% plot(1:N,x_2a_down(1,:),'b','LineWidth',2);
% plot(1:N,y_2(1,:),'g-.','LineWidth',2);
xlabel('Time (t)','FontSize',12);
ylabel('Relative Distance (m)','FontSize',12);
legend({'d_{12}','DKF of d_{12}'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);

figure(4)
plot(1:N,x(4,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_2a(2,:),'r-x','LineWidth',2);
% plot(1:N,x_2a_up(2,:),'b','LineWidth',2);
% plot(1:N,x_2a_down(2,:),'b','LineWidth',2);
xlabel('Time (t)','FontSize',12);
ylabel('Velocity (m/s)','FontSize',12);
legend({'v_2','DKF of v_2'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);

figure(5)
plot(1:N,x(5,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_3a(1,:),'r-x','LineWidth',2);
% plot(1:N,x_3a_up(1,:),'b','LineWidth',2);
% plot(1:N,x_3a_down(1,:),'b','LineWidth',2);
% plot(1:N,y_3(1,:),'g-.','LineWidth',2);
xlabel('Time (t)','FontSize',12);
ylabel('Relative Distance (m)','FontSize',12);
legend({'d_{23}','DKF of d_{23}'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);

figure(6)
plot(1:N,x(6,:),'k-.','LineWidth',2);
hold on
plot(1:N,x_3a(2,:),'r-x','LineWidth',2);
% plot(1:N,x_3a_up(2,:),'b','LineWidth',2);
% plot(1:N,x_3a_down(2,:),'b','LineWidth',2);
xlabel('Time (t)','FontSize',12);
ylabel('Velocity (m/s)','FontSize',12);
legend({'v_3','DKF of v_3'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);
%% 性能指标的比较
figure(1)
plot(1:N,J_1(1,:),'r-.','LineWidth',2);
hold on
plot(1:N,J_2(1,:),'g-.','LineWidth',2);
plot(1:N,J_3(1,:),'b-.','LineWidth',2);
xlabel('Time(t)','FontSize',12);
% ylabel('Velocity(m/s)','FontSize',12);
legend({'F1','F2','F3'},'FontSize',12);
set(gcf,'Pos',[300,140,950,350]);


